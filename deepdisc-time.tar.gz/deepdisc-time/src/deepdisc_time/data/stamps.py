"""On-the-fly cutout extraction from stored visit imagery.

The storage arithmetic drives this module's whole design, so it is worth
spelling out.  Materialising per-scene epoch stacks is not an option: a few
thousand scenes across a few hundred epochs each, with image, variance and mask
planes, reaches petabyte scale.  A few thousand scenes x 500 epochs x
256x256 float32 x 3 planes is already of order 2 PB.

So nothing is materialised.  Visit imagery is stored once, bounded at the visit
level (order 10 TB for the DP2 DDF footprints), and stamps are cut at training
time.  That shifts cost from storage onto IO and CPU, which is why the Delta
CPU allocation is large relative to the GPU one, and why the shared filesystem
between Delta and DeltaAI matters: the ingestion tier and the training tier
work the same store continuously, not as a one-time handoff.

Two backends:

:class:`ButlerStampService`
    Production.  Reads DP2 ``calexp`` / ``preliminary_visit_image`` datasets
    through the LSST Butler, with the real PSF model, photometric calibration
    and variance plane.

:class:`FitsStampService`
    A plain-FITS fallback for exported cutouts, for sites without the Rubin
    stack, and for tests.
"""

from __future__ import annotations

import glob
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence as TSequence, Tuple

import numpy as np

from ..core.schema import EpochMeta, Sequence

__all__ = [
    "VisitRecord",
    "StampService",
    "FitsStampService",
    "ButlerStampService",
    "gaussian_psf_kernel",
]


def gaussian_psf_kernel(sigma: float, size: int = 25) -> np.ndarray:
    """Gaussian kernel, used only when a real PSF model is unavailable."""
    size = size if size % 2 == 1 else size + 1
    c = (size - 1) / 2.0
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)
    g = np.exp(-((xx - c) ** 2 + (yy - c) ** 2) / (2 * max(sigma, 1e-3) ** 2))
    return (g / g.sum()).astype(np.float32)


@dataclass
class VisitRecord:
    """One row of the visit index.

    Building this index once and reusing it is the single biggest IO win
    available: without it, every stamp request has to ask the Butler which
    visits overlap a position, which is a registry query per scene per epoch.
    """

    visit_id: int
    detector: int
    band: str
    mjd: float
    zeropoint: float = 31.4
    psf_sigma: float = 2.0
    sky_level: float = 0.0
    noise_sigma: float = 1.0
    airmass: float = 1.0
    quality_flag: int = 0
    path: Optional[str] = None
    ra_range: Tuple[float, float] = (0.0, 360.0)
    dec_range: Tuple[float, float] = (-90.0, 90.0)

    def covers(self, ra: float, dec: float) -> bool:
        return (
            self.ra_range[0] <= ra <= self.ra_range[1]
            and self.dec_range[0] <= dec <= self.dec_range[1]
        )


class StampService:
    """Base class: turn a sky position into a :class:`Sequence`.

    Parameters
    ----------
    stamp_size : int
        Side length in pixels.  At the DP2 scale of 0.2"/pixel, 64 px is 12.8",
        which comfortably contains a low-redshift host and its near neighbours.
        Larger stamps cost quadratically in both IO and activation memory.
    max_epochs : int, optional
        Cap applied at read time.  Applying it here rather than after reading
        is the difference between reading 32 frames and reading 539.
    band_filter : sequence of str, optional
    quality_max : int
        Maximum ``quality_flag`` to include.  1 keeps the roughly 4000 DP2
        visits that fail coadd thresholds and are released as single-visit
        products only; the model conditions on their measured noise and can
        down-weight them, which a coadd cannot.
    """

    def __init__(
        self,
        stamp_size: int = 64,
        max_epochs: Optional[int] = None,
        band_filter: Optional[TSequence[str]] = None,
        quality_max: int = 1,
    ) -> None:
        self.stamp_size = stamp_size
        self.max_epochs = max_epochs
        self.band_filter = set(band_filter) if band_filter else None
        self.quality_max = quality_max
        self.index: List[VisitRecord] = []

    def select_visits(self, ra: float, dec: float) -> List[VisitRecord]:
        """Visits covering a position, filtered and capped, in time order."""
        recs = [
            r
            for r in self.index
            if r.covers(ra, dec)
            and r.quality_flag <= self.quality_max
            and (self.band_filter is None or r.band in self.band_filter)
        ]
        recs.sort(key=lambda r: r.mjd)
        if self.max_epochs is not None and len(recs) > self.max_epochs:
            # Even thinning in time, not truncation: truncating would silently
            # shorten the baseline and bias any timescale measurement.
            idx = np.unique(np.linspace(0, len(recs) - 1, self.max_epochs).round().astype(int))
            recs = [recs[i] for i in idx]
        return recs

    def _read_stamp(
        self, record: VisitRecord, ra: float, dec: float
    ) -> Optional[Tuple[np.ndarray, np.ndarray, np.ndarray]]:  # pragma: no cover - abstract
        """Return ``(image, variance, psf)`` or ``None`` if unavailable."""
        raise NotImplementedError

    def get_sequence(self, ra: float, dec: float, scene_id: str = "") -> Sequence:
        """Assemble a :class:`Sequence` at a sky position.

        Frames that fail to read are dropped rather than zero-filled.  A
        zero-filled frame with a plausible variance would be read by the model
        as a real non-detection, which is a much worse error than a missing
        epoch.
        """
        records = self.select_visits(ra, dec)
        images, variances, epochs = [], [], []
        for rec in records:
            got = self._read_stamp(rec, ra, dec)
            if got is None:
                continue
            img, var, psf = got
            if img.shape != (self.stamp_size, self.stamp_size):
                continue
            images.append(img)
            variances.append(np.maximum(var, 1e-8))
            epochs.append(
                EpochMeta(
                    mjd=rec.mjd,
                    band=rec.band,
                    psf=psf,
                    zeropoint=rec.zeropoint,
                    sky_level=rec.sky_level,
                    noise_sigma=rec.noise_sigma,
                    airmass=rec.airmass,
                    visit_id=rec.visit_id,
                    quality_flag=rec.quality_flag,
                )
            )
        if not images:
            raise ValueError(f"no usable visits at ra={ra}, dec={dec}")
        return Sequence(
            images=np.stack(images),
            variances=np.stack(variances),
            epochs=epochs,
            scene_id=scene_id or f"{ra:.6f}{dec:+.6f}",
            ra=ra,
            dec=dec,
        )

    def factory(self, positions: TSequence[Tuple[float, float]]):
        """Return an index-to-Sequence callable for :class:`SequenceDataset`."""

        def _make(i: int) -> Sequence:
            ra, dec = positions[i]
            return self.get_sequence(ra, dec, scene_id=f"scene_{i:07d}")

        return _make


class FitsStampService(StampService):
    """Read stamps from plain FITS visit images.

    Expects each visit as a multi-extension FITS file with an image HDU and a
    variance HDU, plus a WCS.  Suitable for exported cutouts and for sites
    without the Rubin stack.
    """

    def __init__(self, image_hdu: int = 1, variance_hdu: int = 2, **kwargs) -> None:
        super().__init__(**kwargs)
        self.image_hdu = image_hdu
        self.variance_hdu = variance_hdu

    def build_index(self, pattern: str, header_map: Optional[Dict[str, str]] = None) -> int:
        """Scan files matching a glob and populate the visit index.

        Reads headers only, never pixels, so indexing thousands of visits is
        cheap.  ``header_map`` overrides the default keyword names.
        """
        from astropy.io import fits
        from astropy.wcs import WCS

        km = {
            "mjd": "MJD-OBS",
            "band": "FILTER",
            "visit": "VISIT",
            "detector": "DETECTOR",
            "zeropoint": "MAGZERO",
            "seeing": "SEEING",
            "airmass": "AIRMASS",
        }
        km.update(header_map or {})

        self.index = []
        for path in sorted(glob.glob(pattern)):
            try:
                with fits.open(path, memmap=True) as hdul:
                    hdr = hdul[self.image_hdu].header
                    wcs = WCS(hdr)
                    ny, nx = hdul[self.image_hdu].data.shape
                    corners = wcs.pixel_to_world_values([0, nx - 1, 0, nx - 1], [0, 0, ny - 1, ny - 1])
                    ra_c, dec_c = np.asarray(corners[0]), np.asarray(corners[1])
                    band = str(hdr.get(km["band"], "r")).strip().lower()[:1]
                    self.index.append(
                        VisitRecord(
                            visit_id=int(hdr.get(km["visit"], -1)),
                            detector=int(hdr.get(km["detector"], 0)),
                            band=band if band in "ugrizy" else "r",
                            mjd=float(hdr.get(km["mjd"], 0.0)),
                            zeropoint=float(hdr.get(km["zeropoint"], 31.4)),
                            psf_sigma=float(hdr.get(km["seeing"], 2.0)),
                            airmass=float(hdr.get(km["airmass"], 1.0)),
                            path=path,
                            ra_range=(float(ra_c.min()), float(ra_c.max())),
                            dec_range=(float(dec_c.min()), float(dec_c.max())),
                        )
                    )
            except Exception:  # noqa: BLE001 - a bad file should not stop indexing
                continue
        return len(self.index)

    def _read_stamp(self, record: VisitRecord, ra: float, dec: float):
        from astropy.io import fits
        from astropy.wcs import WCS

        half = self.stamp_size // 2
        try:
            with fits.open(record.path, memmap=True) as hdul:
                wcs = WCS(hdul[self.image_hdu].header)
                x, y = wcs.world_to_pixel_values(ra, dec)
                x0, y0 = int(round(float(x))) - half, int(round(float(y))) - half
                sl = (slice(y0, y0 + self.stamp_size), slice(x0, x0 + self.stamp_size))
                if x0 < 0 or y0 < 0:
                    return None
                img = np.asarray(hdul[self.image_hdu].data[sl], dtype=np.float32)
                var = np.asarray(hdul[self.variance_hdu].data[sl], dtype=np.float32)
        except Exception:  # noqa: BLE001
            return None
        if img.shape != (self.stamp_size, self.stamp_size):
            return None
        return img, var, gaussian_psf_kernel(record.psf_sigma)


class ButlerStampService(StampService):  # pragma: no cover - requires the Rubin stack
    """Read stamps from a Rubin Butler repository.

    Parameters
    ----------
    repo : str
        Butler repo, e.g. the DP2 collection on the Rubin Science Platform.
    collections : sequence of str
    dataset_type : str
        ``"calexp"`` for processed visit images.  DP2 also exposes
        ``"preliminary_visit_image"``; check ``butler.registry`` for what your
        collection actually contains rather than assuming, since the dataset
        type names moved between DP1 and DP2.
    """

    def __init__(
        self,
        repo: str,
        collections: TSequence[str],
        dataset_type: str = "calexp",
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.repo = repo
        self.collections = list(collections)
        self.dataset_type = dataset_type
        self._butler = None

    @property
    def butler(self):
        if self._butler is None:
            try:
                from lsst.daf.butler import Butler
            except ImportError as exc:
                raise ImportError(
                    "the LSST science pipelines are required for ButlerStampService.\n"
                    "Run on the Rubin Science Platform, or use FitsStampService on "
                    "exported cutouts."
                ) from exc
            self._butler = Butler(self.repo, collections=self.collections)
        return self._butler

    def build_index(self, where: str = "", limit: Optional[int] = None) -> int:
        """Query the registry once and cache visit metadata.

        Example ``where`` for the ECDFS DDF::

            "instrument='LSSTCam' AND visit.target_name='ECDFS'"
        """
        refs = self.butler.registry.queryDatasets(
            self.dataset_type, collections=self.collections, where=where or None
        )
        self.index = []
        for i, ref in enumerate(refs):
            if limit is not None and i >= limit:
                break
            d = ref.dataId
            self.index.append(
                VisitRecord(
                    visit_id=int(d.get("visit", -1)),
                    detector=int(d.get("detector", 0)),
                    band=str(d.get("band", "r")),
                    mjd=0.0,  # filled from the exposure record below
                    path=None,
                )
            )
        # Attach exposure metadata in one pass; per-visit registry lookups are
        # what make naive implementations of this unusably slow.
        for rec in self.index:
            try:
                info = list(
                    self.butler.registry.queryDimensionRecords("visit", visit=rec.visit_id)
                )[0]
                rec.mjd = float(info.timespan.begin.mjd)
                rec.airmass = float(getattr(info, "azimuth", 0.0) or 1.0)
            except Exception:  # noqa: BLE001
                continue
        return len(self.index)

    def _read_stamp(self, record: VisitRecord, ra: float, dec: float):
        import lsst.geom as geom
        from lsst.afw.image import ExposureF  # noqa: F401

        try:
            exp = self.butler.get(
                self.dataset_type, visit=record.visit_id, detector=record.detector
            )
            wcs = exp.getWcs()
            centre = wcs.skyToPixel(geom.SpherePoint(ra, dec, geom.degrees))
            half = self.stamp_size // 2
            bbox = geom.Box2I(
                geom.Point2I(int(centre.getX()) - half, int(centre.getY()) - half),
                geom.Extent2I(self.stamp_size, self.stamp_size),
            )
            bbox.clip(exp.getBBox())
            if bbox.getWidth() != self.stamp_size or bbox.getHeight() != self.stamp_size:
                return None
            cut = exp[bbox]

            # Calibrate to nJy so that photometry is comparable across visits
            # with different zeropoints.  Skipping this and conditioning on the
            # zeropoint instead would work in principle but makes the flux head
            # learn the survey's calibration history, which will not transfer.
            calib = exp.getPhotoCalib()
            img = np.asarray(calib.calibrateImage(cut.getMaskedImage()).getImage().getArray())
            var = np.asarray(
                calib.calibrateImage(cut.getMaskedImage()).getVariance().getArray()
            )

            psf_img = exp.getPsf().computeKernelImage(centre).getArray()
            psf = np.asarray(psf_img, dtype=np.float32)
            if psf.shape[0] % 2 == 0:  # Butler kernels are usually odd, but check
                psf = psf[:-1, :-1]
            return img.astype(np.float32), var.astype(np.float32), psf / psf.sum()
        except Exception:  # noqa: BLE001
            return None
