"""Damped random walk light curves and their diagnostics.

AGN optical variability is conventionally described by a damped random walk
(an Ornstein-Uhlenbeck process).  We need it in three places:

1. to inject variable sources with exact known truth (Experiment A/C);
2. to fit recovered light curves and ask whether the *physical* parameters
   survive, which is a much sharper test than per-epoch flux scatter;
3. to compare against published structure functions on real DDF AGN.

The exact-update sampler below is important: naive Euler stepping of an OU
process on Rubin's irregular cadence introduces a timescale bias that is easily
comparable to the effect we are trying to measure.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np

__all__ = ["DRWParams", "simulate_drw", "structure_function", "fit_drw_map"]


@dataclass
class DRWParams:
    """Damped random walk parameters.

    Parameters
    ----------
    tau : float
        Damping timescale in days.
    sf_inf : float
        Asymptotic structure function, in magnitudes.  Related to the OU
        stationary standard deviation by ``sigma = sf_inf / sqrt(2)``.
    mean_mag : float
        Long-term mean magnitude of the variable component.
    """

    tau: float = 200.0
    sf_inf: float = 0.2
    mean_mag: float = 21.0

    @property
    def sigma(self) -> float:
        return self.sf_inf / np.sqrt(2.0)


def simulate_drw(
    mjds: np.ndarray,
    params: DRWParams,
    rng: Optional[np.random.Generator] = None,
) -> np.ndarray:
    """Sample a DRW at arbitrary (irregular, unsorted) times.

    Uses the exact conditional update for an OU process,

    .. math::
        x_{i+1} \\mid x_i \\sim \\mathcal{N}\\left(
            \\mu + (x_i - \\mu) e^{-\\Delta t/\\tau},\\;
            \\sigma^2 (1 - e^{-2\\Delta t/\\tau})\\right)

    which is unbiased for any cadence, unlike an Euler-Maruyama step.

    Returns
    -------
    np.ndarray
        Magnitudes at ``mjds``, in the original (unsorted) order.
    """
    rng = np.random.default_rng() if rng is None else rng
    mjds = np.asarray(mjds, dtype=np.float64)
    order = np.argsort(mjds)
    t = mjds[order]

    n = t.size
    x = np.empty(n, dtype=np.float64)
    sigma = params.sigma
    x[0] = rng.normal(params.mean_mag, sigma)
    if n > 1:
        dt = np.diff(t)
        decay = np.exp(-dt / params.tau)
        var = sigma**2 * (1.0 - decay**2)
        noise = rng.normal(0.0, 1.0, size=n - 1) * np.sqrt(var)
        for i in range(1, n):
            x[i] = params.mean_mag + (x[i - 1] - params.mean_mag) * decay[i - 1] + noise[i - 1]

    out = np.empty(n, dtype=np.float64)
    out[order] = x
    return out


def mag_to_njy(mag: np.ndarray) -> np.ndarray:
    """AB magnitude to nJy."""
    return 10.0 ** ((np.asarray(mag, dtype=np.float64) - 31.4) / -2.5)


def njy_to_mag(flux: np.ndarray) -> np.ndarray:
    """nJy to AB magnitude.  Non-positive fluxes map to NaN."""
    flux = np.asarray(flux, dtype=np.float64)
    out = np.full(flux.shape, np.nan)
    good = flux > 0
    out[good] = -2.5 * np.log10(flux[good]) + 31.4
    return out


def structure_function(
    mjds: np.ndarray,
    mags: np.ndarray,
    bins: Optional[np.ndarray] = None,
    errors: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Empirical structure function.

    Computes ``SF(dt) = sqrt(<(m_i - m_j)^2> - 2 <sigma^2>)`` over pairs binned
    in lag.  The noise subtraction matters: without it, a noisier light curve
    looks more variable, which would systematically favour whichever method
    produces larger error bars.

    Returns
    -------
    lag_centres, sf, n_pairs
    """
    mjds = np.asarray(mjds, dtype=np.float64)
    mags = np.asarray(mags, dtype=np.float64)
    good = np.isfinite(mags)
    mjds, mags = mjds[good], mags[good]
    if errors is not None:
        errors = np.asarray(errors, dtype=np.float64)[good]

    if mjds.size < 2:
        empty = np.zeros(0)
        return empty, empty, empty

    i, j = np.triu_indices(mjds.size, k=1)
    lags = np.abs(mjds[i] - mjds[j])
    dmag2 = (mags[i] - mags[j]) ** 2
    noise2 = np.zeros_like(dmag2) if errors is None else errors[i] ** 2 + errors[j] ** 2

    if bins is None:
        lo = max(np.min(lags[lags > 0]) if np.any(lags > 0) else 1.0, 1e-3)
        bins = np.logspace(np.log10(lo), np.log10(max(lags.max(), lo * 10)), 12)

    idx = np.digitize(lags, bins) - 1
    centres, sf, counts = [], [], []
    for b in range(len(bins) - 1):
        sel = idx == b
        n = int(sel.sum())
        if n < 3:
            continue
        var = dmag2[sel].mean() - noise2[sel].mean()
        centres.append(np.sqrt(bins[b] * bins[b + 1]))
        sf.append(np.sqrt(var) if var > 0 else 0.0)
        counts.append(n)
    return np.array(centres), np.array(sf), np.array(counts, dtype=int)


def drw_log_likelihood(
    mjds: np.ndarray,
    mags: np.ndarray,
    errors: np.ndarray,
    params: DRWParams,
) -> float:
    """Exact DRW likelihood via the Kalman filter (Kelly et al. 2009 form).

    O(N) rather than O(N^3), which matters because we fit of order 10^4 light
    curves per experiment configuration.
    """
    mjds = np.asarray(mjds, dtype=np.float64)
    order = np.argsort(mjds)
    t = mjds[order]
    y = np.asarray(mags, dtype=np.float64)[order] - params.mean_mag
    e2 = np.asarray(errors, dtype=np.float64)[order] ** 2

    if not np.all(np.isfinite(y)):
        return -np.inf

    sig2 = params.sigma**2
    xhat, omega = 0.0, sig2
    loglike = 0.0
    for i in range(t.size):
        if i > 0:
            a = np.exp(-(t[i] - t[i - 1]) / params.tau)
            xhat = a * xhat + a * omega / (omega + e2[i - 1]) * (y[i - 1] - xhat)
            omega = sig2 * (1 - a**2) + a**2 * omega * (1 - omega / (omega + e2[i - 1]))
        resid = y[i] - xhat
        var = omega + e2[i]
        loglike += -0.5 * (np.log(2 * np.pi * var) + resid**2 / var)
    return float(loglike)


def fit_drw_map(
    mjds: np.ndarray,
    mags: np.ndarray,
    errors: np.ndarray,
    tau_grid: Optional[np.ndarray] = None,
    sf_grid: Optional[np.ndarray] = None,
) -> DRWParams:
    """Grid-search MAP estimate of DRW parameters.

    A grid rather than an optimiser because the DRW likelihood is notoriously
    multimodal in ``tau`` when the baseline is short relative to ``tau`` -- which
    is exactly the DP2 DDF regime (55-84 day baselines against AGN timescales of
    hundreds of days).  A grid at least fails visibly rather than silently
    converging to a local mode.

    Note that ``tau`` is only weakly constrained when ``tau`` exceeds the
    baseline; downstream analyses should treat the returned ``tau`` as a lower
    bound in that regime rather than a measurement.
    """
    mjds = np.asarray(mjds, dtype=np.float64)
    good = np.isfinite(mags)
    if good.sum() < 4:
        return DRWParams(tau=np.nan, sf_inf=np.nan, mean_mag=np.nan)

    mjds, mags, errors = mjds[good], np.asarray(mags)[good], np.asarray(errors)[good]
    if tau_grid is None:
        tau_grid = np.logspace(0.5, 3.5, 25)
    if sf_grid is None:
        sf_grid = np.logspace(-2.5, 0.3, 25)

    mean_mag = float(np.average(mags, weights=1.0 / np.maximum(errors, 1e-6) ** 2))
    best, best_ll = None, -np.inf
    for tau in tau_grid:
        for sf in sf_grid:
            p = DRWParams(tau=float(tau), sf_inf=float(sf), mean_mag=mean_mag)
            ll = drw_log_likelihood(mjds, mags, errors, p)
            if ll > best_ll:
                best_ll, best = ll, p
    return best
