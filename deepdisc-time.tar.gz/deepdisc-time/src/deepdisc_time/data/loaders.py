"""Turning :class:`~deepdisc_time.core.schema.Sequence` objects into model batches.

Two things here are not cosmetic.

**Variable sequence length.**  Scenes from ELAISS1 (539 visits over 84 days) and
ECDFS (159 visits over 57 days) do not have the same length, and a batch will
routinely mix them.  Everything downstream therefore carries a ``pad_mask``, and
padded epochs are excluded from attention, from the rendering loss, and from the
metrics.  Silently zero-padding instead would bias the light-curve likelihood
towards zero flux.

**Epoch subsampling as a first-class operation.**  ``max_epochs`` and the
sampling strategy are dataset-level knobs rather than preprocessing done
offline, because Experiment C (the epoch ablation) sweeps them.  Making that a
config knob rather than a script rewrite is the difference between running the
ablation and talking about it.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence as TSequence

import numpy as np
import torch
from torch.utils.data import Dataset

from ..core.schema import Sequence, meta_to_array

__all__ = [
    "EpochSampler",
    "sequences_to_batch",
    "SequenceDataset",
    "collate_sequences",
    "make_center_heatmap",
    "MultiEpochDictMapper",
]


@dataclass
class EpochSampler:
    """Select which epochs of a sequence are visible to the model.

    Parameters
    ----------
    max_epochs : int, optional
        Cap on sequence length.  ``None`` keeps everything.
    strategy : str
        ``"first"`` -- earliest N epochs, preserving the real cadence of the
        start of the season.  ``"uniform"`` -- evenly spaced in index, which
        thins the cadence without shortening the baseline.  ``"random"`` --
        random subset, used for training augmentation.  ``"contiguous"`` --
        a random contiguous window, which shortens the baseline and is the
        relevant degradation for DRW timescale recovery.
    seed : int
    """

    max_epochs: Optional[int] = None
    strategy: str = "uniform"
    seed: int = 0

    def __call__(self, seq: Sequence, rng: Optional[np.random.Generator] = None) -> Sequence:
        n = seq.n_epochs
        if self.max_epochs is None or self.max_epochs >= n:
            return seq
        k = self.max_epochs
        rng = rng or np.random.default_rng(self.seed)
        if self.strategy == "first":
            idx = np.arange(k)
        elif self.strategy == "uniform":
            idx = np.unique(np.linspace(0, n - 1, k).round().astype(int))
        elif self.strategy == "random":
            idx = np.sort(rng.choice(n, size=k, replace=False))
        elif self.strategy == "contiguous":
            start = int(rng.integers(0, n - k + 1))
            idx = np.arange(start, start + k)
        else:
            raise ValueError(f"unknown strategy {self.strategy!r}")
        return seq.subsample(idx.tolist())


def make_center_heatmap(
    shape, positions: np.ndarray, sigma: float = 2.0
) -> np.ndarray:
    """Gaussian centre heatmap target for the anchor-free detection head.

    Peaks are exactly 1 at the true centre and decay with ``sigma``; the focal
    loss treats near-peak pixels as partially correct rather than as hard
    negatives, which matters because source centroids are not integer-valued.
    """
    h, w = shape
    hm = np.zeros((h, w), dtype=np.float32)
    if len(positions) == 0:
        return hm
    yy, xx = np.mgrid[0:h, 0:w]
    for x, y in positions:
        g = np.exp(-((xx - x) ** 2 + (yy - y) ** 2) / (2 * sigma**2))
        hm = np.maximum(hm, g.astype(np.float32))
    return hm


def sequences_to_batch(
    seqs: TSequence[Sequence],
    device: Optional[torch.device] = None,
    with_truth: bool = True,
    heatmap_sigma: float = 2.0,
    variable_only_positions: bool = False,
) -> Dict[str, torch.Tensor]:
    """Collate a list of sequences into the dict consumed by the model.

    Sequences are padded to the longest in the batch and to the largest PSF
    kernel.  Padded PSFs are set to a unit impulse rather than zeros so that
    convolution with them is well defined even though the corresponding epochs
    are masked out; a zero kernel would produce NaNs in normalised code paths.
    """
    b = len(seqs)
    t_max = max(s.n_epochs for s in seqs)
    h, w = seqs[0].shape
    if any(s.shape != (h, w) for s in seqs):
        raise ValueError("all sequences in a batch must share stamp dimensions")
    k_max = max(max(e.psf.shape[0] for e in s.epochs) for s in seqs)

    images = np.zeros((b, t_max, h, w), dtype=np.float32)
    variances = np.ones((b, t_max, h, w), dtype=np.float32)
    psfs = np.zeros((b, t_max, k_max, k_max), dtype=np.float32)
    psfs[:, :, k_max // 2, k_max // 2] = 1.0  # unit impulse for padded epochs
    n_meta = len(meta_to_array(seqs[0].epochs)[0])
    meta = np.zeros((b, t_max, n_meta), dtype=np.float32)
    band_idx = np.zeros((b, t_max), dtype=np.int64)
    t_days = np.zeros((b, t_max), dtype=np.float32)
    pad_mask = np.ones((b, t_max), dtype=bool)

    for i, s in enumerate(seqs):
        n = s.n_epochs
        images[i, :n] = s.images
        variances[i, :n] = s.variances
        stack = s.psf_stack()
        lo = (k_max - stack.shape[-1]) // 2
        psfs[i, :n] = 0.0
        psfs[i, :n, lo : lo + stack.shape[-1], lo : lo + stack.shape[-1]] = stack
        meta[i, :n] = meta_to_array(s.epochs)
        band_idx[i, :n] = s.band_indices
        t_days[i, :n] = s.mjds - s.mjds[0]
        pad_mask[i, :n] = False

    batch = {
        "images": torch.from_numpy(images),
        "variances": torch.from_numpy(variances),
        "psfs": torch.from_numpy(psfs),
        "meta": torch.from_numpy(meta),
        "band_idx": torch.from_numpy(band_idx),
        "t_days": torch.from_numpy(t_days),
        "pad_mask": torch.from_numpy(pad_mask),
    }

    if with_truth and all(s.truth is not None for s in seqs):
        n_src = max(len(s.truth.sources) for s in seqs)
        positions = np.zeros((b, n_src, 2), dtype=np.float32)
        gt_lc = np.zeros((b, n_src, t_max), dtype=np.float32)
        lc_mask = np.zeros((b, n_src, t_max), dtype=bool)
        gt_var = np.zeros((b, n_src), dtype=np.float32)
        heatmaps = np.zeros((b, 1, h, w), dtype=np.float32)

        for i, s in enumerate(seqs):
            srcs = [x for x in s.truth.sources if (x.is_variable or not variable_only_positions)]
            for j, src in enumerate(srcs):
                positions[i, j] = (src.x, src.y)
                gt_var[i, j] = float(src.is_variable)
                if src.variable_flux is not None:
                    n = min(len(src.variable_flux), t_max)
                    gt_lc[i, j, :n] = src.variable_flux[:n]
                    lc_mask[i, j, :n] = True
            heatmaps[i, 0] = make_center_heatmap((h, w), positions[i, : len(srcs)], heatmap_sigma)

        batch.update(
            {
                "positions": torch.from_numpy(positions),
                "gt_lightcurve": torch.from_numpy(gt_lc).reshape(b * n_src, t_max),
                "gt_lightcurve_mask": torch.from_numpy(lc_mask).reshape(b * n_src, t_max),
                "gt_variable": torch.from_numpy(gt_var).reshape(b * n_src),
                "gt_heatmap": torch.from_numpy(heatmaps),
            }
        )

    if device is not None:
        batch = {k: v.to(device) for k, v in batch.items()}
    return batch


class SequenceDataset(Dataset):
    """Dataset over sequences, materialised eagerly or produced by a factory.

    Parameters
    ----------
    sequences : list of Sequence, optional
        In-memory sequences.  Fine for tests and small experiments.
    factory : callable, optional
        ``factory(index) -> Sequence``.  This is the production path: it lets
        the stamp service cut cutouts on the fly from stored visit imagery.
        Materialising per-scene epoch stacks is not an option at DDF scale --
        a few thousand scenes across a few hundred epochs each, with image,
        variance and mask planes, reaches petabyte scale.
    """

    def __init__(
        self,
        sequences: Optional[List[Sequence]] = None,
        factory: Optional[Callable[[int], Sequence]] = None,
        length: Optional[int] = None,
        sampler: Optional[EpochSampler] = None,
        transform: Optional[Callable[[Sequence], Sequence]] = None,
    ) -> None:
        if sequences is None and factory is None:
            raise ValueError("provide either sequences or factory")
        self.sequences = sequences
        self.factory = factory
        self._length = length if length is not None else len(sequences or [])
        self.sampler = sampler
        self.transform = transform

    def __len__(self) -> int:
        return self._length

    def __getitem__(self, i: int) -> Sequence:
        seq = self.sequences[i] if self.sequences is not None else self.factory(i)
        if self.sampler is not None:
            seq = self.sampler(seq, np.random.default_rng(self.sampler.seed + i))
        if self.transform is not None:
            seq = self.transform(seq)
        return seq


def collate_sequences(batch: List[Sequence]) -> Dict[str, torch.Tensor]:
    """``collate_fn`` for :class:`torch.utils.data.DataLoader`."""
    return sequences_to_batch(batch)


# --------------------------------------------------------------------------- #
# DeepDISC integration
# --------------------------------------------------------------------------- #

def make_multi_epoch_dict_mapper():  # pragma: no cover - requires detectron2
    """Return a ``DataMapper`` subclass for the Detectron2 training loop.

    Follows the ``DictMapper`` / ``RedshiftDictMapper`` contract in
    ``deepdisc.model.loaders``: subclass ``DataMapper``, implement
    ``map_data(dataset_dict)``, and return the dict the model expects.

    One divergence is unavoidable.  ``DictMapper`` applies Detectron2's
    ``AugmentationList`` to a single ``(H, W, C)`` image.  A multi-epoch sequence
    has to have the *same geometric* transform applied to every epoch (or the
    epochs stop being registered to each other) while photometric augmentation
    must vary per epoch (or the model never learns that epochs differ).  The
    transform is therefore sampled once from the first epoch and replayed.
    """
    import copy

    import detectron2.data.transforms as T
    from detectron2.data import detection_utils as utils
    from deepdisc.model.loaders import DataMapper

    class MultiEpochDictMapper(DataMapper):
        def __init__(self, *args, epoch_sampler: Optional[EpochSampler] = None, **kwargs):
            self.epoch_sampler = epoch_sampler
            super().__init__(*args, **kwargs)

        def map_data(self, dataset_dict):
            dataset_dict = copy.deepcopy(dataset_dict)
            key = self.km(dataset_dict)
            seq: Sequence = self.IR(key)  # a SequenceReader returns a Sequence
            if self.epoch_sampler is not None:
                seq = self.epoch_sampler(seq)

            images = seq.images
            if self.augmentations is not None:
                auginput = T.AugInput(images[0][..., None])
                transform = self.augmentations(auginput)(auginput)
                # Replay the *same* geometric transform on every epoch.
                images = np.stack(
                    [transform.apply_image(im[..., None])[..., 0] for im in images]
                )
            else:
                transform = None

            annos = [
                utils.transform_instance_annotations(
                    a, [transform] if transform else [], images.shape[1:]
                )
                for a in dataset_dict.pop("annotations", [])
            ]
            instances = utils.annotations_to_instances(annos, images.shape[1:])
            instances = utils.filter_empty_instances(instances)

            single = sequences_to_batch([seq], with_truth=False)
            return {
                "images": single["images"][0],
                "variances": single["variances"][0],
                "psfs": single["psfs"][0],
                "meta": single["meta"][0],
                "band_idx": single["band_idx"][0],
                "t_days": single["t_days"][0],
                "pad_mask": single["pad_mask"][0],
                "height": images.shape[1],
                "width": images.shape[2],
                "image_id": dataset_dict.get("image_id", seq.scene_id),
                "instances": instances,
            }

    return MultiEpochDictMapper


#: Alias kept for symmetry with ``deepdisc.model.loaders.DictMapper``.
MultiEpochDictMapper = make_multi_epoch_dict_mapper
