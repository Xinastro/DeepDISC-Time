"""Inject variable point sources into real Rubin visit imagery.

Why injection into *real* frames rather than fully synthetic scenes: synthetic
scenes give exact truth but not realistic noise, PSF, or blending statistics;
real catalogues give realism but no truth.  Injection into real frames is the
only route that gives both, and it is the backbone of the quantitative
validation described in the ACCESS proposal.

Two renderers are supported.  ``galsim`` is used when available and is what
should be used for production runs on DP2, because it handles pixel integration
and PSF realisation correctly.  A pure-numpy Sersic renderer is provided as a
fallback so that the package is testable without the full Rubin software stack,
and so CI does not depend on a compiled dependency.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence as TSequence, Tuple

import numpy as np

from ..core.schema import BAND_INDEX, BANDS, EpochMeta, Sequence, SceneTruth, SourceTruth
from .drw import DRWParams, mag_to_njy, simulate_drw

try:  # pragma: no cover - exercised only where the full stack is installed
    import galsim  # type: ignore

    HAVE_GALSIM = True
except ImportError:  # pragma: no cover
    galsim = None
    HAVE_GALSIM = False

__all__ = [
    "InjectionConfig",
    "sersic_profile",
    "render_point_source",
    "convolve_psf",
    "inject_variable_source",
    "make_synthetic_sequence",
    "colour_gradient_host",
    "make_colour_gradient_sequence",
]


@dataclass
class InjectionConfig:
    """One point in the blending/variability grid from the proposal.

    Every axis here corresponds to a column of the blend-resolved validation
    table: nucleus-to-host contrast, host morphology, neighbour separation,
    neighbour flux ratio, and variability amplitude and timescale.
    """

    #: Ratio of mean nuclear flux to total host flux.  The scientifically
    #: interesting regime is <~ 0.3, where static morphology cannot separate
    #: the two (cf. the low-z broad-line AGN that static DeepDISC misclassifies).
    nucleus_to_host: float = 0.2
    host_flux: float = 5000.0  # nJy
    host_half_light_radius: float = 3.0  # pixels
    host_sersic_n: float = 1.0
    host_ellipticity: float = 0.0
    host_pa: float = 0.0  # radians
    #: Offset of the variable component from the host centroid, in pixels.
    #: Zero for a nuclear AGN; non-zero exercises the nuclear/non-nuclear
    #: discrimination that Ward et al. (2025) identify as a key application.
    nuclear_offset: float = 0.0
    neighbour_separation: Optional[float] = None  # pixels; None => no neighbour
    neighbour_flux_ratio: float = 1.0
    drw_tau: float = 200.0
    drw_sf_inf: float = 0.2
    #: Strength of the host colour gradient, in magnitudes of bulge-minus-disc
    #: colour across the full ugrizy range.  Zero gives a grey host, which is
    #: the (incorrect) assumption every band-independent morphology makes.
    #: Realistic early-type-in-late-type systems reach 0.5-1.0 mag.
    host_colour_gradient: float = 0.0
    #: Fraction of host flux in the compact, red component.
    host_bulge_fraction: float = 0.4
    #: Half-light radius of the bulge, as a fraction of the disc's.
    host_bulge_radius_frac: float = 0.25
    seed: int = 0


def sersic_profile(
    shape: Tuple[int, int],
    x: float,
    y: float,
    half_light_radius: float,
    n: float = 1.0,
    ellipticity: float = 0.0,
    pa: float = 0.0,
    oversample: int = 3,
) -> np.ndarray:
    """Unit-flux Sersic profile on a pixel grid.

    Parameters
    ----------
    oversample : int
        Sub-pixel sampling factor.  Pixel integration matters for compact
        sources: evaluating the profile at pixel centres under-counts flux in
        the core by several percent for ``r_e`` of a few pixels, which is
        directly comparable to the photometric effects being measured.
    """
    h, w = shape
    if n <= 0:
        raise ValueError("sersic index must be positive")
    # Ciotti & Bertin (1999) asymptotic expansion for b_n.
    bn = 2.0 * n - 1.0 / 3.0 + 4.0 / (405.0 * n) + 46.0 / (25515.0 * n**2)

    step = 1.0 / oversample
    off = np.arange(oversample) * step + step / 2.0 - 0.5
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)

    acc = np.zeros((h, w), dtype=np.float64)
    cos_pa, sin_pa = np.cos(pa), np.sin(pa)
    q = max(1.0 - ellipticity, 1e-3)
    for dy in off:
        for dx in off:
            dxp = (xx + dx) - x
            dyp = (yy + dy) - y
            xr = dxp * cos_pa + dyp * sin_pa
            yr = -dxp * sin_pa + dyp * cos_pa
            r = np.sqrt(xr**2 + (yr / q) ** 2)
            acc += np.exp(-bn * ((r / half_light_radius) ** (1.0 / n) - 1.0))
    acc /= oversample**2
    total = acc.sum()
    return (acc / total).astype(np.float32) if total > 0 else acc.astype(np.float32)


def render_point_source(shape: Tuple[int, int], x: float, y: float, psf: np.ndarray) -> np.ndarray:
    """Unit-flux point source at sub-pixel position ``(x, y)``, PSF-convolved.

    Implemented by shifting the PSF kernel with bilinear interpolation rather
    than by placing a delta and convolving, which avoids aliasing the kernel
    onto the pixel grid.
    """
    h, w = shape
    k = psf.shape[0]
    c = (k - 1) // 2
    out = np.zeros((h, w), dtype=np.float64)

    x0, y0 = int(np.floor(x)), int(np.floor(y))
    fx, fy = x - x0, y - y0
    for dy, wy in ((0, 1 - fy), (1, fy)):
        for dx, wx in ((0, 1 - fx), (1, fx)):
            if wy * wx == 0:
                continue
            ox, oy = x0 + dx - c, y0 + dy - c
            xs0, xs1 = max(ox, 0), min(ox + k, w)
            ys0, ys1 = max(oy, 0), min(oy + k, h)
            if xs0 >= xs1 or ys0 >= ys1:
                continue
            out[ys0:ys1, xs0:xs1] += wy * wx * psf[ys0 - oy : ys1 - oy, xs0 - ox : xs1 - ox]
    return out.astype(np.float32)


def convolve_psf(image: np.ndarray, psf: np.ndarray) -> np.ndarray:
    """FFT convolution with a centred, odd-sized kernel; shape preserved."""
    h, w = image.shape
    k = psf.shape[0]
    ph, pw = h + k - 1, w + k - 1
    fh, fw = 1 << int(np.ceil(np.log2(ph))), 1 << int(np.ceil(np.log2(pw)))
    conv = np.fft.irfft2(np.fft.rfft2(image, (fh, fw)) * np.fft.rfft2(psf, (fh, fw)), (fh, fw))
    c = (k - 1) // 2
    return conv[c : c + h, c : c + w].astype(np.float32)


def inject_variable_source(
    seq: Sequence,
    x: float,
    y: float,
    lightcurve_njy: np.ndarray,
    add_noise: bool = True,
    rng: Optional[np.random.Generator] = None,
) -> Sequence:
    """Add a variable point source to every epoch of an existing sequence.

    The source is rendered with each epoch's own PSF, and shot noise from the
    injected flux is added to both the image and the variance plane so the
    injected object is not artificially noiseless relative to its surroundings.
    A model that could exploit an inconsistent noise budget would score well
    here and fail on real data.
    """
    rng = np.random.default_rng() if rng is None else rng
    if len(lightcurve_njy) != seq.n_epochs:
        raise ValueError(
            f"lightcurve has {len(lightcurve_njy)} points for {seq.n_epochs} epochs"
        )

    images = seq.images.copy()
    variances = seq.variances.copy()
    for t, epoch in enumerate(seq.epochs):
        flux = float(lightcurve_njy[t])
        stamp = render_point_source(seq.shape, x, y, epoch.psf) * flux
        images[t] += stamp
        shot = np.abs(stamp) * float(epoch.noise_sigma) ** 2 / max(
            float(epoch.sky_level) + float(epoch.noise_sigma) ** 2, 1e-6
        )
        variances[t] += shot
        if add_noise:
            images[t] += rng.normal(0.0, np.sqrt(np.maximum(shot, 0.0))).astype(np.float32)

    truth = seq.truth or SceneTruth(sources=[], provenance="injection")
    truth.sources = list(truth.sources) + [
        SourceTruth(
            x=x,
            y=y,
            is_variable=True,
            variable_flux=np.asarray(lightcurve_njy, dtype=np.float64),
            source_type="agn",
        )
    ]
    return Sequence(
        images=images,
        variances=variances,
        epochs=seq.epochs,
        scene_id=seq.scene_id,
        ra=seq.ra,
        dec=seq.dec,
        truth=truth,
        wcs_header=seq.wcs_header,
    )


def _gaussian_psf(sigma: float, size: int = 21) -> np.ndarray:
    c = (size - 1) / 2.0
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)
    g = np.exp(-((xx - c) ** 2 + (yy - c) ** 2) / (2 * sigma**2))
    return (g / g.sum()).astype(np.float32)


def make_synthetic_sequence(
    cfg: InjectionConfig,
    n_epochs: int = 24,
    size: int = 64,
    baseline_days: float = 80.0,
    bands: TSequence[str] = ("g", "r", "i"),
    seeing_range: Tuple[float, float] = (1.4, 2.6),
    noise_sigma: float = 12.0,
) -> Sequence:
    """Build a fully synthetic AGN-in-host sequence with exact truth.

    This exists for unit tests, for smoke-testing the training loop, and for the
    controlled first pass of Experiment C before the DP2 injection pipeline is
    stood up.  Production runs should inject into real DP2 visit frames via
    :func:`inject_variable_source`; the cadence model here is a crude stand-in
    for the real DDF visit history.
    """
    rng = np.random.default_rng(cfg.seed)
    centre = (size - 1) / 2.0

    # Irregular cadence: uniform draws with a season gap, roughly mimicking the
    # DDF visit distribution better than an even grid would.
    mjds = np.sort(60000.0 + rng.uniform(0.0, baseline_days, size=n_epochs))
    epochs: List[EpochMeta] = []
    for t in range(n_epochs):
        sigma = float(rng.uniform(*seeing_range)) / 2.355 / 0.2  # arcsec FWHM -> pixel sigma
        epochs.append(
            EpochMeta(
                mjd=float(mjds[t]),
                band=bands[t % len(bands)],
                psf=_gaussian_psf(sigma),
                sky_level=200.0,
                noise_sigma=noise_sigma * float(rng.uniform(0.85, 1.3)),
                airmass=float(rng.uniform(1.0, 1.6)),
                visit_id=t,
                quality_flag=int(rng.random() < 0.15),
            )
        )

    host = sersic_profile(
        (size, size),
        centre,
        centre,
        cfg.host_half_light_radius,
        cfg.host_sersic_n,
        cfg.host_ellipticity,
        cfg.host_pa,
    ) * cfg.host_flux

    neighbour = np.zeros((size, size), dtype=np.float32)
    neighbour_truth = None
    if cfg.neighbour_separation is not None:
        nx = centre + cfg.neighbour_separation
        ny = centre
        neighbour = sersic_profile(
            (size, size), nx, ny, cfg.host_half_light_radius * 0.8, 1.0
        ) * (cfg.host_flux * cfg.neighbour_flux_ratio)
        neighbour_truth = SourceTruth(
            x=nx,
            y=ny,
            is_variable=False,
            static_flux={"total": cfg.host_flux * cfg.neighbour_flux_ratio},
            source_type="galaxy",
        )

    mean_nuc = cfg.host_flux * cfg.nucleus_to_host
    drw = DRWParams(tau=cfg.drw_tau, sf_inf=cfg.drw_sf_inf, mean_mag=0.0)
    lc = mean_nuc * 10.0 ** (-0.4 * simulate_drw(mjds, drw, rng=rng))

    images = np.zeros((n_epochs, size, size), dtype=np.float32)
    variances = np.zeros_like(images)
    nx_, ny_ = centre + cfg.nuclear_offset, centre
    for t, epoch in enumerate(epochs):
        static = convolve_psf(host + neighbour, epoch.psf)
        point = render_point_source((size, size), nx_, ny_, epoch.psf) * lc[t]
        sig = epoch.noise_sigma
        images[t] = static + point + rng.normal(0.0, sig, (size, size))
        variances[t] = sig**2 + np.maximum(static + point, 0.0) * 0.0 + 1e-3

    sources = [
        SourceTruth(
            x=centre,
            y=centre,
            is_variable=False,
            static_flux={"total": cfg.host_flux},
            half_light_radius=cfg.host_half_light_radius,
            sersic_n=cfg.host_sersic_n,
            source_type="galaxy",
        ),
        SourceTruth(
            x=nx_,
            y=ny_,
            is_variable=True,
            variable_flux=lc,
            source_type="agn",
            drw_tau=cfg.drw_tau,
            drw_sf_inf=cfg.drw_sf_inf,
        ),
    ]
    if neighbour_truth is not None:
        sources.append(neighbour_truth)

    return Sequence(
        images=images,
        variances=variances,
        epochs=epochs,
        scene_id=f"synthetic_{cfg.seed}",
        truth=SceneTruth(sources=sources, provenance="injection"),
    )


def colour_gradient_host(
    shape: Tuple[int, int],
    x: float,
    y: float,
    band: str,
    cfg: "InjectionConfig",
) -> np.ndarray:
    """Two-component host whose apparent morphology changes with bandpass.

    A red compact bulge plus a bluer extended disc.  Their relative amplitudes
    are set by ``cfg.host_colour_gradient``, so the summed profile is more
    centrally concentrated in the red bands than in the blue ones.  The total
    flux is held fixed across bands: the *shape* changes, not the brightness.
    Holding total flux fixed is deliberate and is what makes the resulting test
    diagnostic.  A pure per-band flux change is something a per-band amplitude
    can absorb; a per-band change of shape is not, and separating the two is the
    entire point of :func:`deepdisc_time.eval.experiments.experiment_d`.

    Parameters
    ----------
    band : str
        One of :data:`~deepdisc_time.core.schema.BANDS`.  The colour term is
        linear in band index, which is a crude but monotone stand-in for a real
        bulge/disc SED pair and is sufficient to produce the systematic.

    Notes
    -----
    Why this matters, in one sentence: fitting one band-independent morphology
    to a host like this leaves a residual that is largest in the bands furthest
    from the fitted average, and the nearest free parameter able to absorb it is
    the variable point-source amplitude in exactly those bands -- so a perfectly
    constant nucleus acquires a light curve correlated with filter.
    """
    k = BAND_INDEX[band]
    # Centre the colour term so the mid-band host matches the grey case.
    t = (k - (len(BANDS) - 1) / 2.0) / max((len(BANDS) - 1) / 2.0, 1.0)  # -1..+1
    # Redder bands (larger k) get more bulge.
    delta = 0.5 * cfg.host_colour_gradient * t
    f_bulge = float(np.clip(cfg.host_bulge_fraction + delta, 0.02, 0.98))

    bulge = sersic_profile(
        shape, x, y,
        max(cfg.host_half_light_radius * cfg.host_bulge_radius_frac, 0.6),
        n=4.0,
    )
    disc = sersic_profile(
        shape, x, y,
        cfg.host_half_light_radius,
        n=1.0,
        ellipticity=cfg.host_ellipticity,
        pa=cfg.host_pa,
    )
    return (f_bulge * bulge + (1.0 - f_bulge) * disc) * cfg.host_flux


def make_colour_gradient_sequence(
    cfg: InjectionConfig,
    n_epochs: int = 24,
    size: int = 64,
    baseline_days: float = 80.0,
    bands: TSequence[str] = BANDS,
    seeing_range: Tuple[float, float] = (1.4, 2.6),
    noise_sigma: float = 12.0,
    variable: bool = False,
) -> Sequence:
    """Host with a colour gradient and, by default, a strictly constant nucleus.

    This is the Experiment D generator.  With ``variable=False`` the nuclear
    component has exactly the same flux at every epoch, so **any** recovered
    variability is an artefact by construction and its amplitude is a direct
    measurement of the systematic introduced by assuming a band-independent
    host morphology.

    The control is the same call with ``cfg.host_colour_gradient = 0``: a grey
    host of identical total flux and identical profile at mid-band.  The
    difference between the two is attributable to the colour gradient alone.

    Set ``variable=True`` to study how the systematic interacts with a genuine
    light curve, which is the regime real measurements live in.
    """
    rng = np.random.default_rng(cfg.seed)
    centre = (size - 1) / 2.0
    mjds = np.sort(60000.0 + rng.uniform(0.0, baseline_days, size=n_epochs))

    epochs: List[EpochMeta] = []
    for t in range(n_epochs):
        sigma = float(rng.uniform(*seeing_range)) / 2.355 / 0.2
        epochs.append(
            EpochMeta(
                mjd=float(mjds[t]),
                band=bands[t % len(bands)],
                psf=_gaussian_psf(sigma),
                sky_level=200.0,
                noise_sigma=noise_sigma * float(rng.uniform(0.85, 1.3)),
                airmass=float(rng.uniform(1.0, 1.6)),
                visit_id=t,
            )
        )

    mean_nuc = cfg.host_flux * cfg.nucleus_to_host
    if variable:
        drw = DRWParams(tau=cfg.drw_tau, sf_inf=cfg.drw_sf_inf, mean_mag=0.0)
        lc = mean_nuc * 10.0 ** (-0.4 * simulate_drw(mjds, drw, rng=rng))
    else:
        lc = np.full(n_epochs, mean_nuc, dtype=np.float64)

    nx_, ny_ = centre + cfg.nuclear_offset, centre
    images = np.zeros((n_epochs, size, size), dtype=np.float32)
    variances = np.zeros_like(images)
    for t, epoch in enumerate(epochs):
        host = colour_gradient_host((size, size), centre, centre, epoch.band, cfg)
        static = convolve_psf(host, epoch.psf)
        point = render_point_source((size, size), nx_, ny_, epoch.psf) * lc[t]
        sig = epoch.noise_sigma
        images[t] = static + point + rng.normal(0.0, sig, (size, size))
        variances[t] = sig**2 + 1e-3

    sources = [
        SourceTruth(
            x=centre, y=centre, is_variable=False,
            static_flux={"total": cfg.host_flux},
            half_light_radius=cfg.host_half_light_radius,
            sersic_n=cfg.host_sersic_n,
            source_type="galaxy",
        ),
        SourceTruth(
            x=nx_, y=ny_, is_variable=bool(variable),
            variable_flux=lc,
            source_type="agn",
            drw_tau=cfg.drw_tau if variable else None,
            drw_sf_inf=cfg.drw_sf_inf if variable else None,
        ),
    ]
    return Sequence(
        images=images, variances=variances, epochs=epochs,
        scene_id=f"cgrad_{cfg.host_colour_gradient:.2f}_{cfg.seed}",
        truth=SceneTruth(sources=sources, provenance="injection"),
    )
