"""Common data structures shared by every method in the package.

The single most important design decision in ``deepdisc_time`` lives here: every
method that models a multi-epoch scene -- DeepDISC-Time, scarlet2-TD, DIA forced
photometry, static DeepDISC -- consumes a :class:`Sequence` and emits a
:class:`SceneSolution`.  Nothing in :mod:`deepdisc_time.eval` knows which method
produced a solution.

That is what makes Experiment B (the amortization frontier, per the ACCESS
proposal) a fair comparison rather than an apples-to-oranges one: the metrics
code cannot tell the difference, so it cannot advantage either side.

Units and conventions
---------------------
* Fluxes are in nJy throughout (the Rubin science pipelines' internal unit).
* ``mjd`` is TAI Modified Julian Date at exposure midpoint.
* Pixel coordinates are 0-indexed, ``(x, y)`` = ``(column, row)``, matching
  ``numpy`` array indexing as ``arr[y, x]``.
* PSF kernels are normalised to sum to 1 and are odd-sized and centred.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence as TSequence, Tuple

import numpy as np

__all__ = [
    "BANDS",
    "BAND_INDEX",
    "EpochMeta",
    "Sequence",
    "SourceTruth",
    "SceneTruth",
    "SourceSolution",
    "SceneSolution",
    "META_FIELDS",
    "meta_to_array",
]

#: Rubin filter set, in the canonical order used for band embeddings.
BANDS: Tuple[str, ...] = ("u", "g", "r", "i", "z", "y")
BAND_INDEX: Dict[str, int] = {b: i for i, b in enumerate(BANDS)}

#: Continuous per-epoch metadata handed to the FiLM conditioning network.
#: Order is fixed and load-bearing -- :func:`meta_to_array` and
#: :class:`deepdisc_time.modeling.film.EpochConditioner` both rely on it.
META_FIELDS: Tuple[str, ...] = (
    "dt",            # (mjd - sequence reference mjd) / timescale, dimensionless
    "psf_sigma",     # PSF Gaussian-equivalent sigma, pixels
    "sky_level",     # sky background, nJy / pixel
    "noise_sigma",   # median per-pixel noise, nJy
    "zp_offset",     # photometric zeropoint minus reference zeropoint, mag
    "airmass",
    "log_var_scale",  # log of the variance-plane scaling; large => down-weight
)


@dataclass
class EpochMeta:
    """Per-visit instrumental state.

    This is the object that makes the whole framework template-free.  Rather
    than matching PSFs between a science image and a template, every epoch
    carries its own measured state and the model is conditioned on it.

    Parameters
    ----------
    mjd : float
        TAI MJD at exposure midpoint.
    band : str
        One of :data:`BANDS`.
    psf : np.ndarray
        Normalised PSF kernel, shape ``(k, k)`` with ``k`` odd.
    zeropoint : float
        AB magnitude zeropoint of the visit.
    sky_level : float
        Sky background in nJy/pixel.
    noise_sigma : float
        Median per-pixel noise in nJy.
    airmass : float
    visit_id : int
    quality_flag : int
        0 = science grade (coadd-quality).  1 = below coadd threshold but
        usable.  DP2 releases roughly 4000 such visits as single-visit products
        only; the whole point of conditioning on measured noise is that these
        can be down-weighted rather than discarded.
    """

    mjd: float
    band: str
    psf: np.ndarray
    zeropoint: float = 31.4
    sky_level: float = 0.0
    noise_sigma: float = 1.0
    airmass: float = 1.0
    visit_id: int = -1
    quality_flag: int = 0

    def __post_init__(self) -> None:
        if self.band not in BAND_INDEX:
            raise ValueError(f"unknown band {self.band!r}; expected one of {BANDS}")
        self.psf = np.asarray(self.psf, dtype=np.float32)
        if self.psf.ndim != 2 or self.psf.shape[0] != self.psf.shape[1]:
            raise ValueError(f"psf must be square 2-D, got shape {self.psf.shape}")
        if self.psf.shape[0] % 2 == 0:
            raise ValueError(f"psf must have odd side length, got {self.psf.shape[0]}")
        total = float(self.psf.sum())
        if total <= 0:
            raise ValueError("psf must have positive sum")
        self.psf = self.psf / total

    @property
    def psf_sigma(self) -> float:
        """Gaussian-equivalent sigma of the PSF, in pixels.

        Computed as the second moment of the kernel, which is well defined for
        any centred profile and does not assume the PSF is actually Gaussian.
        """
        k = self.psf.shape[0]
        c = (k - 1) / 2.0
        yy, xx = np.mgrid[0:k, 0:k]
        r2 = (xx - c) ** 2 + (yy - c) ** 2
        return float(np.sqrt(0.5 * (self.psf * r2).sum()))

    @property
    def band_index(self) -> int:
        return BAND_INDEX[self.band]


@dataclass
class SourceTruth:
    """Ground truth for one injected source.

    Only available for injected sources (see
    :mod:`deepdisc_time.data.injection`).  Real DDF scenes carry
    ``truth=None`` and are supervised instead by scarlet2-TD reference
    solutions.
    """

    x: float
    y: float
    is_variable: bool
    static_flux: Dict[str, float] = field(default_factory=dict)
    variable_flux: Optional[np.ndarray] = None  # per-epoch, length n_epochs, nJy
    half_light_radius: Optional[float] = None
    sersic_n: Optional[float] = None
    source_type: str = "galaxy"  # galaxy | star | agn | sn | tde
    drw_tau: Optional[float] = None
    drw_sf_inf: Optional[float] = None


@dataclass
class SceneTruth:
    sources: List[SourceTruth] = field(default_factory=list)
    provenance: str = "injection"  # injection | scarlet2_td | none


@dataclass
class Sequence:
    """A multi-epoch cutout of one patch of sky.

    Attributes
    ----------
    images : np.ndarray
        Shape ``(T, H, W)``, float32, nJy.  One plane per *visit*, not per
        band: Rubin visits are single-filter, so band is carried in
        ``epochs[t].band`` rather than as an image axis.  This is a deliberate
        departure from the static DeepDISC convention of ``(H, W, C)`` band
        stacks and is why the sequence loader cannot simply reuse
        ``deepdisc.data_format.image_readers``.
    variances : np.ndarray
        Shape ``(T, H, W)``, per-pixel variance in nJy^2.
    epochs : list of EpochMeta
        Length ``T``.
    scene_id : str
    ra, dec : float
        Sky position of the stamp centre, degrees.
    truth : SceneTruth or None
    """

    images: np.ndarray
    variances: np.ndarray
    epochs: List[EpochMeta]
    scene_id: str = ""
    ra: float = float("nan")
    dec: float = float("nan")
    truth: Optional[SceneTruth] = None
    wcs_header: Optional[dict] = None

    def __post_init__(self) -> None:
        self.images = np.asarray(self.images, dtype=np.float32)
        self.variances = np.asarray(self.variances, dtype=np.float32)
        if self.images.ndim != 3:
            raise ValueError(f"images must be (T, H, W), got {self.images.shape}")
        if self.images.shape != self.variances.shape:
            raise ValueError(
                f"images {self.images.shape} and variances {self.variances.shape} must match"
            )
        if len(self.epochs) != self.images.shape[0]:
            raise ValueError(
                f"got {len(self.epochs)} epochs for {self.images.shape[0]} image planes"
            )
        if np.any(self.variances <= 0):
            raise ValueError("variances must be strictly positive")

    @property
    def n_epochs(self) -> int:
        return self.images.shape[0]

    @property
    def shape(self) -> Tuple[int, int]:
        return self.images.shape[1], self.images.shape[2]

    @property
    def mjds(self) -> np.ndarray:
        return np.array([e.mjd for e in self.epochs], dtype=np.float64)

    @property
    def band_indices(self) -> np.ndarray:
        return np.array([e.band_index for e in self.epochs], dtype=np.int64)

    def psf_stack(self) -> np.ndarray:
        """PSF kernels for all epochs, zero-padded to a common odd size."""
        kmax = max(e.psf.shape[0] for e in self.epochs)
        out = np.zeros((self.n_epochs, kmax, kmax), dtype=np.float32)
        for t, e in enumerate(self.epochs):
            k = e.psf.shape[0]
            lo = (kmax - k) // 2
            out[t, lo : lo + k, lo : lo + k] = e.psf
        return out

    def subsample(self, indices: TSequence[int]) -> "Sequence":
        """Return a Sequence keeping only the given epochs.

        This is the primitive behind Experiment C (the epoch ablation): we
        progressively remove epochs and ask when temporal information starts to
        improve deblending.  Truth light curves are subsampled in lockstep so
        the comparison stays honest.
        """
        idx = list(indices)
        truth = None
        if self.truth is not None:
            srcs = []
            for s in self.truth.sources:
                vf = None if s.variable_flux is None else np.asarray(s.variable_flux)[idx]
                srcs.append(dataclasses.replace(s, variable_flux=vf))
            truth = SceneTruth(sources=srcs, provenance=self.truth.provenance)
        return Sequence(
            images=self.images[idx],
            variances=self.variances[idx],
            epochs=[self.epochs[i] for i in idx],
            scene_id=self.scene_id,
            ra=self.ra,
            dec=self.dec,
            truth=truth,
            wcs_header=self.wcs_header,
        )


def meta_to_array(
    epochs: TSequence[EpochMeta],
    ref_mjd: Optional[float] = None,
    timescale: float = 100.0,
    ref_zeropoint: float = 31.4,
) -> np.ndarray:
    """Pack epoch metadata into the ``(T, len(META_FIELDS))`` conditioning array.

    Parameters
    ----------
    ref_mjd : float, optional
        Reference epoch.  Defaults to the first epoch's MJD.  Using a per-scene
        reference (rather than an absolute MJD) keeps the conditioning input
        scale-free and avoids the network memorising survey calendar dates.
    timescale : float
        Days per unit of ``dt``.  100 d is roughly the DDF season length and
        keeps ``dt`` order-unity for DP2 sequences.
    """
    if ref_mjd is None:
        ref_mjd = float(epochs[0].mjd)
    rows = []
    for e in epochs:
        rows.append(
            [
                (float(e.mjd) - ref_mjd) / timescale,
                e.psf_sigma,
                float(e.sky_level),
                float(e.noise_sigma),
                float(e.zeropoint) - ref_zeropoint,
                float(e.airmass),
                # quality_flag=1 visits get their variance inflated by the loader;
                # exposing the log scaling lets the network learn to down-weight
                # them rather than forcing us to drop them as a coadd would.
                float(np.log(max(e.noise_sigma, 1e-6) ** 2)),
            ]
        )
    return np.asarray(rows, dtype=np.float32)


@dataclass
class SourceSolution:
    """One source as modelled by any method."""

    x: float
    y: float
    #: Posterior mean per-epoch flux of the variable component, nJy, length T.
    lightcurve: np.ndarray
    #: 1-sigma uncertainty on ``lightcurve``, same shape.
    lightcurve_err: Optional[np.ndarray] = None
    #: Optional full posterior samples, shape ``(n_samples, T)``.
    lightcurve_samples: Optional[np.ndarray] = None
    #: Probability that this source has a variable component at all.
    #: scarlet2-TD does not produce this (static-vs-variable is a user-imposed
    #: constraint there); DeepDISC-Time predicts it.
    p_variable: Optional[float] = None
    static_flux: Dict[str, float] = field(default_factory=dict)
    static_model: Optional[np.ndarray] = None  # (H, W) host morphology
    segmentation: Optional[np.ndarray] = None  # (H, W) bool
    obj_class: Optional[str] = None
    class_probs: Optional[Dict[str, float]] = None
    score: float = 1.0


@dataclass
class SceneSolution:
    """The output of *any* scene-modelling method on a :class:`Sequence`."""

    scene_id: str
    sources: List[SourceSolution] = field(default_factory=list)
    method: str = "unknown"
    #: Wall-clock seconds for this scene.  Populated by every backend so that
    #: the amortization frontier can be measured rather than asserted.
    wallclock_s: float = float("nan")
    #: Whether the underlying optimiser converged.  Always True for amortized
    #: models; meaningful for scarlet2-TD, where non-convergent scenes are
    #: retained as a separately analysed subset.
    converged: bool = True
    n_epochs: int = 0
    diagnostics: Dict[str, float] = field(default_factory=dict)

    def positions(self) -> np.ndarray:
        if not self.sources:
            return np.zeros((0, 2), dtype=np.float64)
        return np.array([[s.x, s.y] for s in self.sources], dtype=np.float64)
