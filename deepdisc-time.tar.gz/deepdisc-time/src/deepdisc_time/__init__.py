"""DeepDISC-Time: amortized scene-level inference for blended variable sources.

Extends the DeepDISC framework (https://github.com/lincc-frameworks/deepdisc)
from static coadds to sequences of native single-visit Rubin images, performing
detection, deblending, static/variable decomposition, classification and
probabilistic light-curve inference jointly in one forward pass.

Positioning.  Template-free multi-epoch static/variable decomposition is
established: the scarlet2 time-domain extension (Ward et al. 2025, A&C 51,
100930) does it, does it well, and is treated here as the reference baseline
and as a supervision source, not as a strawman.  What this package adds is the
part per-scene optimisation structurally cannot do -- detection inside the same
model, amortized inference at survey throughput, and a *predicted* rather than
imposed static-versus-variable assignment with calibrated uncertainty.

Quick start::

    from deepdisc_time.data.injection import make_synthetic_sequence, InjectionConfig
    from deepdisc_time.data.loaders import sequences_to_batch
    from deepdisc_time.modeling.meta_arch import TemporalSceneModel

    seqs = [make_synthetic_sequence(InjectionConfig(seed=i)) for i in range(4)]
    model = TemporalSceneModel()
    losses = model(sequences_to_batch(seqs))
"""

from .core.schema import (
    BANDS,
    EpochMeta,
    SceneSolution,
    SceneTruth,
    Sequence,
    SourceSolution,
    SourceTruth,
)

__version__ = "0.2.0"

__all__ = [
    "BANDS",
    "EpochMeta",
    "Sequence",
    "SceneTruth",
    "SourceTruth",
    "SceneSolution",
    "SourceSolution",
    "__version__",
]
