"""Method-blind metrics.

Nothing in this module knows which method produced a :class:`SceneSolution`.
That is what keeps the comparison in Experiment B fair.

The metric set follows the validation section of the ACCESS proposal:
detection completeness and purity, host/nucleus flux separation error,
transient-host offset accuracy, light-curve bias and scatter, DRW parameter
recovery, uncertainty calibration by probability integral transform and
interval coverage, variability-probability calibration, and wall-clock cost
per source.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence as TSequence, Tuple

import numpy as np

from ..core.schema import SceneSolution, Sequence, SourceSolution, SourceTruth
from ..data.drw import fit_drw_map, njy_to_mag

__all__ = [
    "match_sources",
    "detection_metrics",
    "lightcurve_metrics",
    "pit_values",
    "calibration_metrics",
    "variability_metrics",
    "drw_recovery",
    "spurious_variability_metrics",
    "throughput_metrics",
    "MatchResult",
]


@dataclass
class MatchResult:
    """Bipartite match between predicted and true sources."""

    pairs: List[Tuple[int, int]] = field(default_factory=list)  # (pred_idx, true_idx)
    unmatched_pred: List[int] = field(default_factory=list)
    unmatched_true: List[int] = field(default_factory=list)
    distances: List[float] = field(default_factory=list)


def match_sources(
    pred_xy: np.ndarray,
    true_xy: np.ndarray,
    radius: float = 3.0,
    pred_scores: Optional[np.ndarray] = None,
) -> MatchResult:
    """Greedy one-to-one match within ``radius`` pixels, highest score first.

    Greedy-by-score rather than nearest-neighbour: nearest-neighbour matching
    can assign a spurious low-score detection to a true source and push the
    real detection into the unmatched pile, which inflates purity and deflates
    completeness at the same time.  Matching in score order is what a catalogue
    consumer would actually do.

    A fixed radius is used rather than an adaptive one because the whole point
    is to measure positional accuracy in the blended regime; scaling the radius
    with blending severity would hide the effect.
    """
    pred_xy = np.asarray(pred_xy, dtype=float).reshape(-1, 2)
    true_xy = np.asarray(true_xy, dtype=float).reshape(-1, 2)
    order = (
        np.argsort(-np.asarray(pred_scores))
        if pred_scores is not None
        else np.arange(len(pred_xy))
    )

    taken = set()
    res = MatchResult()
    for pi in order:
        if len(true_xy) == 0:
            res.unmatched_pred.append(int(pi))
            continue
        d = np.linalg.norm(true_xy - pred_xy[pi], axis=1)
        d[list(taken)] = np.inf if taken else d[list(taken)]
        ti = int(np.argmin(d))
        if d[ti] <= radius and ti not in taken:
            taken.add(ti)
            res.pairs.append((int(pi), ti))
            res.distances.append(float(d[ti]))
        else:
            res.unmatched_pred.append(int(pi))
    res.unmatched_true = [i for i in range(len(true_xy)) if i not in taken]
    return res


def detection_metrics(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    radius: float = 3.0,
    variable_only: bool = False,
) -> Dict[str, float]:
    """Completeness, purity, and positional accuracy.

    Parameters
    ----------
    variable_only : bool
        Restrict to sources with a variable component.  This is the Experiment A
        headline: whether a temporally aware detector finds variable sources
        that static detection on the equivalent coadd misses.
    """
    tp = fn = fp = 0
    dists: List[float] = []
    by_id = {s.scene_id: s for s in solutions}

    for seq in sequences:
        sol = by_id.get(seq.scene_id)
        if seq.truth is None:
            continue
        truth = [s for s in seq.truth.sources if (s.is_variable or not variable_only)]
        true_xy = np.array([[s.x, s.y] for s in truth]).reshape(-1, 2)
        if sol is None:
            fn += len(truth)
            continue
        pred_xy = sol.positions()
        scores = np.array([s.score for s in sol.sources]) if sol.sources else None
        m = match_sources(pred_xy, true_xy, radius, scores)
        tp += len(m.pairs)
        fn += len(m.unmatched_true)
        fp += len(m.unmatched_pred)
        dists.extend(m.distances)

    completeness = tp / max(tp + fn, 1)
    purity = tp / max(tp + fp, 1)
    f1 = 2 * completeness * purity / max(completeness + purity, 1e-12)
    return {
        "completeness": completeness,
        "purity": purity,
        "f1": f1,
        "n_true": float(tp + fn),
        "n_pred": float(tp + fp),
        "median_offset_px": float(np.median(dists)) if dists else float("nan"),
    }


def _paired_lightcurves(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    radius: float = 3.0,
) -> List[Tuple[SourceSolution, SourceTruth, Sequence]]:
    """Match predicted to true sources; return (prediction, truth, scene) triples.

    The scene is carried along because per-epoch metrics need the observation
    times, and a ``SourceSolution`` is deliberately a plain value object with no
    back-pointer to its scene.
    """
    out = []
    by_id = {s.scene_id: s for s in solutions}
    for seq in sequences:
        sol = by_id.get(seq.scene_id)
        if sol is None or seq.truth is None:
            continue
        truth = [s for s in seq.truth.sources if s.variable_flux is not None]
        if not truth:
            continue
        m = match_sources(
            sol.positions(),
            np.array([[s.x, s.y] for s in truth]),
            radius,
            np.array([s.score for s in sol.sources]) if sol.sources else None,
        )
        for pi, ti in m.pairs:
            out.append((sol.sources[pi], truth[ti], seq))
    return out


def lightcurve_metrics(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    radius: float = 3.0,
    normalise: str = "mean_flux",
) -> Dict[str, float]:
    """Per-epoch light-curve bias, scatter, and chi-square.

    Parameters
    ----------
    normalise : str
        ``"mean_flux"`` divides residuals by the true mean flux of that source,
        so bright and faint sources contribute comparably.  ``"none"`` reports
        raw nJy.  ``"error"`` reports pulls, i.e. residual over quoted error --
        the quantity that reveals whether the error bars are honest.

    Notes
    -----
    Difference-image photometry measures flux *relative to the template*, which
    contains the source's mean flux.  Its bias against an absolute truth light
    curve is therefore expected to be close to -1 in ``mean_flux`` units, and
    that is not a bug in the baseline.  When comparing DIA against absolute
    methods, look at the scatter and the correlation, or re-reference all
    methods to their own mean.
    """
    pairs = _paired_lightcurves(solutions, sequences, radius)
    if not pairs:
        return {k: float("nan") for k in ("bias", "scatter", "chi2_per_dof", "corr", "n_points")}

    biases, scatters, chi2s, corrs = [], [], [], []
    n_points = 0
    for pred, truth, _seq in pairs:
        lc = np.asarray(pred.lightcurve, dtype=float)
        tl = np.asarray(truth.variable_flux, dtype=float)
        n = min(len(lc), len(tl))
        lc, tl = lc[:n], tl[:n]
        good = np.isfinite(lc) & np.isfinite(tl)
        if good.sum() < 2:
            continue
        lc, tl = lc[good], tl[good]
        n_points += int(good.sum())

        resid = lc - tl
        if normalise == "mean_flux":
            scale = max(abs(tl.mean()), 1e-8)
            resid = resid / scale
        elif normalise == "error" and pred.lightcurve_err is not None:
            err = np.asarray(pred.lightcurve_err, dtype=float)[:n][good]
            resid = resid / np.maximum(err, 1e-8)

        biases.append(float(np.mean(resid)))
        scatters.append(float(np.std(resid)))
        if pred.lightcurve_err is not None:
            err = np.asarray(pred.lightcurve_err, dtype=float)[:n][good]
            chi2s.append(float(np.mean(((lc - tl) / np.maximum(err, 1e-8)) ** 2)))
        if np.std(lc) > 0 and np.std(tl) > 0:
            corrs.append(float(np.corrcoef(lc, tl)[0, 1]))

    return {
        "bias": float(np.mean(biases)) if biases else float("nan"),
        "bias_median": float(np.median(biases)) if biases else float("nan"),
        "scatter": float(np.mean(scatters)) if scatters else float("nan"),
        "chi2_per_dof": float(np.mean(chi2s)) if chi2s else float("nan"),
        "corr": float(np.mean(corrs)) if corrs else float("nan"),
        "n_sources": float(len(biases)),
        "n_points": float(n_points),
    }


def pit_values(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    radius: float = 3.0,
) -> np.ndarray:
    """Probability integral transform of true flux under the predicted posterior.

    If the posteriors are calibrated, PIT values are uniform on [0, 1].
    A U-shaped histogram means the posteriors are too narrow (overconfident);
    a peaked one means they are too wide.

    A Gaussian approximation from ``lightcurve_err`` is used when full posterior
    samples are unavailable, which is the case for every baseline.  For
    DeepDISC-Time, prefer ``lightcurve_samples``, since the whole argument for
    a flow over a Gaussian is what happens in the tails.
    """
    from scipy.stats import norm

    vals: List[float] = []
    for pred, truth, _seq in _paired_lightcurves(solutions, sequences, radius):
        tl = np.asarray(truth.variable_flux, dtype=float)
        if pred.lightcurve_samples is not None:
            s = np.asarray(pred.lightcurve_samples)  # (n_samples, T)
            n = min(s.shape[1], len(tl))
            vals.extend(((s[:, :n] < tl[None, :n]).mean(axis=0)).tolist())
            continue
        if pred.lightcurve_err is None:
            continue
        lc = np.asarray(pred.lightcurve, dtype=float)
        err = np.asarray(pred.lightcurve_err, dtype=float)
        n = min(len(lc), len(tl))
        good = np.isfinite(lc[:n]) & np.isfinite(tl[:n]) & (err[:n] > 0)
        vals.extend(norm.cdf(tl[:n][good], lc[:n][good], err[:n][good]).tolist())
    return np.asarray(vals)


def calibration_metrics(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    radius: float = 3.0,
    levels: TSequence[float] = (0.5, 0.68, 0.9, 0.95),
) -> Dict[str, float]:
    """PIT uniformity and central-interval coverage.

    ``pit_ks`` is the Kolmogorov-Smirnov distance from uniform; 0 is perfect.
    ``coverage_XX`` should equal ``XX`` for a calibrated posterior.
    """
    pit = pit_values(solutions, sequences, radius)
    if pit.size == 0:
        return {"pit_ks": float("nan"), "n_points": 0.0}

    srt = np.sort(pit)
    n = srt.size
    emp = np.arange(1, n + 1) / n
    ks = float(np.max(np.abs(srt - emp)))

    out = {"pit_ks": ks, "pit_mean": float(pit.mean()), "n_points": float(n)}
    for lv in levels:
        lo, hi = (1 - lv) / 2, 1 - (1 - lv) / 2
        out[f"coverage_{int(round(lv * 100))}"] = float(((pit >= lo) & (pit <= hi)).mean())
    return out


def variability_metrics(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    radius: float = 3.0,
    n_bins: int = 10,
) -> Dict[str, float]:
    """ROC-AUC and calibration error of the predicted variability probability.

    Only DeepDISC-Time populates ``p_variable``; scarlet2-TD leaves it ``None``
    because static-versus-variable is imposed there rather than inferred.  This
    metric therefore has no baseline by construction, which is itself the point:
    it measures a capability the reference method does not have.
    """
    probs: List[float] = []
    labels: List[int] = []
    by_id = {s.scene_id: s for s in solutions}

    for seq in sequences:
        sol = by_id.get(seq.scene_id)
        if sol is None or seq.truth is None:
            continue
        truth = seq.truth.sources
        m = match_sources(
            sol.positions(),
            np.array([[s.x, s.y] for s in truth]).reshape(-1, 2),
            radius,
            np.array([s.score for s in sol.sources]) if sol.sources else None,
        )
        for pi, ti in m.pairs:
            p = sol.sources[pi].p_variable
            if p is None:
                continue
            probs.append(float(p))
            labels.append(int(truth[ti].is_variable))

    if len(set(labels)) < 2:
        return {"auc": float("nan"), "ece": float("nan"), "n": float(len(labels))}

    p = np.asarray(probs)
    y = np.asarray(labels)

    # Rank-based AUC (Mann-Whitney U), tie-aware.
    order = np.argsort(p)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(p) + 1)
    n_pos, n_neg = int(y.sum()), int((1 - y).sum())
    auc = (ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)

    # Expected calibration error.
    edges = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    for b in range(n_bins):
        sel = (p >= edges[b]) & (p < edges[b + 1] if b < n_bins - 1 else p <= 1.0)
        if sel.sum() == 0:
            continue
        ece += sel.mean() * abs(p[sel].mean() - y[sel].mean())

    return {"auc": float(auc), "ece": float(ece), "n": float(len(y))}


def drw_recovery(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    radius: float = 3.0,
) -> Dict[str, float]:
    """Bias in recovered DRW parameters relative to injected truth.

    A sharper test than per-epoch scatter: a method can have small per-epoch
    residuals and still get the damping timescale wrong if its errors are
    correlated in time, which is exactly what host contamination produces.

    ``tau`` is reported in dex because it is only ever constrained to order of
    magnitude on a season-length baseline.  DP2 DDF baselines are 55-84 days
    against AGN timescales of hundreds of days, so treat recovered ``tau`` as a
    lower bound in that regime, not a measurement.
    """
    d_log_tau: List[float] = []
    d_sf: List[float] = []

    for pred, truth, seq in _paired_lightcurves(solutions, sequences, radius):
        if truth.drw_tau is None or truth.drw_sf_inf is None:
            continue
        lc = np.asarray(pred.lightcurve, dtype=float)
        err = (
            np.asarray(pred.lightcurve_err, dtype=float)
            if pred.lightcurve_err is not None
            else np.full_like(lc, np.nanstd(lc) * 0.1 + 1e-6)
        )
        mjds = seq.mjds
        n = min(len(lc), len(mjds))
        mag = njy_to_mag(lc[:n])
        # Magnitude error from flux error: dm = 2.5/ln(10) * df/f.
        magerr = 1.0857 * np.abs(err[:n]) / np.maximum(np.abs(lc[:n]), 1e-8)
        fit = fit_drw_map(mjds[:n], mag, magerr)
        if not np.isfinite(fit.tau):
            continue
        d_log_tau.append(float(np.log10(fit.tau) - np.log10(truth.drw_tau)))
        d_sf.append(float(fit.sf_inf - truth.drw_sf_inf))

    return {
        "d_log_tau_median": float(np.median(d_log_tau)) if d_log_tau else float("nan"),
        "d_log_tau_scatter": float(np.std(d_log_tau)) if d_log_tau else float("nan"),
        "d_sf_inf_median": float(np.median(d_sf)) if d_sf else float("nan"),
        "n": float(len(d_log_tau)),
    }


def throughput_metrics(solutions: TSequence[SceneSolution]) -> Dict[str, float]:
    """Wall-clock cost, the second axis of the amortization frontier.

    Reports per scene, per source, and per source-epoch.  The last is the one
    that scales: per-scene optimisation cost grows with epoch count, which is
    why the amortization gain is far larger in the temporal case than it was for
    static deblending.
    """
    if not solutions:
        return {}
    t = np.array([s.wallclock_s for s in solutions], dtype=float)
    n_src = np.array([max(len(s.sources), 1) for s in solutions], dtype=float)
    n_ep = np.array([max(s.n_epochs, 1) for s in solutions], dtype=float)
    conv = np.array([s.converged for s in solutions], dtype=float)
    return {
        "s_per_scene_median": float(np.median(t)),
        "s_per_scene_mean": float(np.mean(t)),
        "s_per_source": float(np.sum(t) / np.sum(n_src)),
        "ms_per_source_epoch": float(1e3 * np.sum(t) / np.sum(n_src * n_ep)),
        "scenes_per_gpu_hour": float(3600.0 / max(np.mean(t), 1e-9)),
        "convergence_rate": float(conv.mean()),
        "n_scenes": float(len(solutions)),
    }


def spurious_variability_metrics(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    radius: float = 3.0,
) -> Dict[str, float]:
    """Variability recovered from sources that have none.  Experiment D.

    Run on scenes built by
    :func:`~deepdisc_time.data.injection.make_colour_gradient_sequence` with
    ``variable=False``, where the injected nucleus has identical flux at every
    epoch.  Any structure in the recovered light curve is therefore an artefact,
    and this function measures its size.

    The interesting quantity is not the raw scatter -- photon noise guarantees
    some -- but how much of it correlates with *bandpass*.  A band-independent
    host morphology fitted to a host with a colour gradient leaves a residual
    that is largest in the bands furthest from the fitted average, and the
    nearest free parameter able to absorb it is the nuclear amplitude in those
    same bands.  The signature is therefore a light curve that steps with filter
    rather than wandering with time, and ``band_frac`` is what detects it.

    Returns
    -------
    dict
        ``spurious_rms_frac``
            RMS of the recovered light curve about its own mean, divided by
            that mean.  Zero for a perfect recovery.
        ``spurious_band_frac``
            Fraction of that variance explained by band identity alone (a
            one-way between-band variance ratio, i.e. eta-squared).  Photon
            noise contributes at the level of 1/n_bands; a value well above
            that is the colour-gradient artefact.
        ``spurious_band_range_frac``
            Peak-to-peak spread of the per-band means, over the global mean.
            The directly interpretable version of ``band_frac``: it is the
            systematic photometric error, in fractional flux, that a band-
            independent host model imposes on a constant source.
        ``n_sources``
            How many non-variable injected sources were matched.
    """
    rms_fracs: List[float] = []
    band_fracs: List[float] = []
    range_fracs: List[float] = []
    by_id = {s.scene_id: s for s in solutions}

    for seq in sequences:
        sol = by_id.get(seq.scene_id)
        if sol is None or seq.truth is None:
            continue
        bands = np.array([e.band_index for e in seq.epochs])
        truth_static = [t for t in seq.truth.sources if not t.is_variable and t.source_type != "galaxy"]
        # Fall back to any injected source whose truth light curve is flat.
        if not truth_static:
            truth_static = [
                t for t in seq.truth.sources
                if t.variable_flux is not None and float(np.std(t.variable_flux)) == 0.0
            ]
        if not truth_static:
            continue

        m = match_sources(
            sol.positions(),
            np.array([[t.x, t.y] for t in truth_static]).reshape(-1, 2),
            radius,
            np.array([s.score for s in sol.sources]) if sol.sources else None,
        )
        for pi, ti in m.pairs:
            lc = np.asarray(sol.sources[pi].lightcurve, dtype=float)
            n = min(len(lc), len(bands))
            lc, bb = lc[:n], bands[:n]
            mu = float(np.mean(lc))
            if not np.isfinite(mu) or abs(mu) < 1e-12:
                continue
            total_var = float(np.var(lc))
            rms_fracs.append(float(np.std(lc)) / abs(mu))

            means, weights = [], []
            for b in np.unique(bb):
                sel = bb == b
                if sel.sum() == 0:
                    continue
                means.append(float(np.mean(lc[sel])))
                weights.append(int(sel.sum()))
            if len(means) < 2:
                continue
            means_a, w_a = np.array(means), np.array(weights, dtype=float)
            between = float(np.sum(w_a * (means_a - mu) ** 2) / w_a.sum())
            band_fracs.append(between / total_var if total_var > 0 else 0.0)
            range_fracs.append(float(means_a.max() - means_a.min()) / abs(mu))

    if not rms_fracs:
        return {
            "spurious_rms_frac": float("nan"),
            "spurious_band_frac": float("nan"),
            "spurious_band_range_frac": float("nan"),
            "n_sources": 0.0,
        }
    return {
        "spurious_rms_frac": float(np.mean(rms_fracs)),
        "spurious_band_frac": float(np.mean(band_fracs)) if band_fracs else float("nan"),
        "spurious_band_range_frac": float(np.mean(range_fracs)) if range_fracs else float("nan"),
        "n_sources": float(len(rms_fracs)),
    }
