"""The three experiments that define the project.

Each is a function so it can be called from a script, a notebook, or a test,
and each returns a tidy list of records rather than writing plots, so the
analysis and the presentation stay separable.

* :func:`experiment_a_detection` -- does temporal information improve detection?
* :func:`experiment_b_amortization` -- the accuracy/throughput frontier.
* :func:`experiment_c_epoch_ablation` -- when does time start to help?
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional, Sequence as TSequence

import numpy as np

from ..core.schema import SceneSolution, Sequence
from ..data.loaders import EpochSampler
from .metrics import (
    calibration_metrics,
    detection_metrics,
    drw_recovery,
    lightcurve_metrics,
    throughput_metrics,
    variability_metrics,
)

__all__ = [
    "evaluate",
    "experiment_a_detection",
    "experiment_b_amortization",
    "experiment_c_epoch_ablation",
    "experiment_d_colour_gradient",
    "blend_resolved_table",
]

Backend = Callable[[TSequence[Sequence]], List[SceneSolution]]


def evaluate(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    radius: float = 3.0,
    include_drw: bool = True,
) -> Dict[str, float]:
    """Run the full metric suite and flatten it into one record."""
    rec: Dict[str, float] = {}
    rec.update({f"det_{k}": v for k, v in detection_metrics(solutions, sequences, radius).items()})
    rec.update(
        {
            f"detvar_{k}": v
            for k, v in detection_metrics(solutions, sequences, radius, variable_only=True).items()
        }
    )
    rec.update({f"lc_{k}": v for k, v in lightcurve_metrics(solutions, sequences, radius).items()})
    rec.update({f"cal_{k}": v for k, v in calibration_metrics(solutions, sequences, radius).items()})
    rec.update({f"var_{k}": v for k, v in variability_metrics(solutions, sequences, radius).items()})
    if include_drw:
        rec.update({f"drw_{k}": v for k, v in drw_recovery(solutions, sequences, radius).items()})
    rec.update({f"thr_{k}": v for k, v in throughput_metrics(solutions).items()})
    return rec


def experiment_a_detection(
    sequences: TSequence[Sequence],
    temporal_backend: Backend,
    static_backend: Backend,
    radius: float = 3.0,
) -> List[Dict[str, float]]:
    """Does temporal information improve detection and segmentation?

    This is the question scarlet2-TD structurally cannot answer, because it is
    handed a source list.  The comparison is between a detector operating on
    temporally pooled features and the same detector operating on the
    equivalent static stack, evaluated on identical scenes.

    The headline number is ``detvar_completeness``: completeness restricted to
    sources that actually have a variable component.  Overall completeness can
    be flat while variable-source completeness improves substantially, and
    conflating the two would bury the result.

    Returns
    -------
    list of dict
        One record per method, plus a ``delta`` record with the differences.
    """
    records = []
    for name, backend in (("temporal", temporal_backend), ("static", static_backend)):
        sols = backend(sequences)
        rec = evaluate(sols, sequences, radius, include_drw=False)
        rec["method"] = name
        records.append(rec)

    delta = {"method": "delta_temporal_minus_static"}
    for k in records[0]:
        if k == "method":
            continue
        try:
            delta[k] = float(records[0][k]) - float(records[1][k])
        except (TypeError, ValueError):
            continue
    records.append(delta)
    return records


def experiment_b_amortization(
    sequences: TSequence[Sequence],
    backends: Dict[str, Backend],
    epoch_counts: TSequence[int] = (4, 8, 16, 32, 64),
    radius: float = 3.0,
    sampler_strategy: str = "uniform",
) -> List[Dict[str, float]]:
    """Accuracy versus wall-clock cost, as a function of sequence length.

    The deliverable is a *curve*, not a winner.  Per-scene optimisation is
    expected to remain more accurate in some regimes; the useful result is
    where the crossover lies and how each method's cost scales with epoch
    count.  Per-scene cost grows with ``T``; amortized cost per scene grows
    much more slowly, and that gap is the entire argument for whether scene
    modelling can be an LSST-scale data product rather than a follow-up tool.

    Scenes where a per-scene optimiser fails to converge are retained and
    reported through ``thr_convergence_rate`` rather than dropped, since a
    method that is accurate only on the easy 80% of scenes has not solved the
    problem.
    """
    records: List[Dict[str, float]] = []
    for n_ep in epoch_counts:
        sampler = EpochSampler(max_epochs=n_ep, strategy=sampler_strategy)
        subset = [sampler(s) for s in sequences]
        actual = int(np.median([s.n_epochs for s in subset]))
        for name, backend in backends.items():
            sols = backend(subset)
            rec = evaluate(sols, subset, radius)
            rec["method"] = name
            rec["requested_epochs"] = float(n_ep)
            rec["n_epochs"] = float(actual)
            records.append(rec)
    return records


def experiment_c_epoch_ablation(
    sequences: TSequence[Sequence],
    temporal_backend: Backend,
    static_backend: Backend,
    epoch_counts: TSequence[int] = (2, 3, 4, 6, 8, 12, 16, 24, 32),
    strategies: TSequence[str] = ("uniform", "contiguous"),
    radius: float = 3.0,
) -> List[Dict[str, float]]:
    """When does temporal information start to beat static methods?

    Sweeps sequence length under two thinning strategies, which probe different
    things.  ``uniform`` thins the cadence while preserving the baseline and so
    isolates the effect of the number of samples.  ``contiguous`` shortens the
    baseline and is the degradation that matters for damping-timescale
    recovery.  Reporting only one of them would let a method that needs many
    closely spaced epochs look identical to one that needs a long baseline.
    """
    records: List[Dict[str, float]] = []
    for strategy in strategies:
        for n_ep in epoch_counts:
            sampler = EpochSampler(max_epochs=n_ep, strategy=strategy)
            subset = [sampler(s) for s in sequences]
            actual = int(np.median([s.n_epochs for s in subset]))
            for name, backend in (("temporal", temporal_backend), ("static", static_backend)):
                sols = backend(subset)
                rec = evaluate(sols, subset, radius, include_drw=(actual >= 8))
                rec["method"] = name
                rec["strategy"] = strategy
                rec["n_epochs"] = float(actual)
                records.append(rec)
    return records


def blend_resolved_table(
    make_sequences: Callable[[Dict[str, float]], List[Sequence]],
    backends: Dict[str, Backend],
    grid: Dict[str, TSequence[float]],
    radius: float = 3.0,
) -> List[Dict[str, float]]:
    """Sweep the blending/variability grid from the proposal.

    Parameters
    ----------
    make_sequences : callable
        ``make_sequences(point) -> list[Sequence]`` where ``point`` is a dict of
        grid values, e.g. ``{"nucleus_to_host": 0.1, "neighbour_separation": 4}``.
    grid : dict
        Axis name to values.  The Cartesian product is swept, so keep it small
        or run it as an array job; the full proposal grid is a cluster-scale
        sweep, not a laptop one.
    """
    import itertools

    keys = list(grid)
    records: List[Dict[str, float]] = []
    for values in itertools.product(*(grid[k] for k in keys)):
        point = dict(zip(keys, values))
        seqs = make_sequences(point)
        for name, backend in backends.items():
            rec = evaluate(backend(seqs), seqs, radius)
            rec["method"] = name
            rec.update({f"grid_{k}": float(v) for k, v in point.items()})
            records.append(rec)
    return records


def experiment_d_colour_gradient(
    backends: Dict[str, Backend],
    gradients: TSequence[float] = (0.0, 0.25, 0.5, 0.75, 1.0),
    n_scenes: int = 40,
    n_epochs: int = 24,
    base_cfg: Optional[dict] = None,
    seed: int = 0,
) -> "pd.DataFrame":
    """Experiment D: the systematic from assuming band-independent morphology.

    Every method here, and scarlet2 as well, represents a source's static
    component with one morphology shared across all bands and at most a per-band
    amplitude.  Real hosts have colour gradients, so their apparent morphology
    genuinely differs between u and y.  The residual left by a band-independent
    fit has to go somewhere, and the nearest free parameter is the nuclear
    amplitude in the bands where the mismatch is worst.  The result is a
    *spurious, band-correlated light curve* on a source that does not vary.

    The design isolates it.  Scenes carry a nucleus of exactly constant flux, so
    any recovered variability is an artefact by construction.  Host total flux
    is held fixed across bands, so the effect measured is a change of shape and
    not of brightness -- the distinction matters, because a per-band amplitude
    can absorb the latter and not the former.  Gradient strength 0 is the grey
    control: identical scenes, identical noise, no colour gradient.

    Read the output as a systematic error budget.  ``spurious_band_range_frac``
    at the largest gradient is, directly, the fractional photometric error that
    this modelling assumption imposes on every light curve the framework
    produces.  Compare the ``predict_sed=True`` and ``predict_sed=False`` arms
    to separate what a per-band amplitude fixes from what it cannot.
    """
    import pandas as pd

    from ..data.injection import InjectionConfig, make_colour_gradient_sequence
    from .metrics import spurious_variability_metrics

    rows: List[Dict[str, object]] = []
    for g in gradients:
        seqs: List[Sequence] = []
        for i in range(n_scenes):
            kw = dict(base_cfg or {})
            kw.update(host_colour_gradient=float(g), seed=seed + i)
            seqs.append(
                make_colour_gradient_sequence(
                    InjectionConfig(**kw), n_epochs=n_epochs, variable=False
                )
            )
        for name, backend in backends.items():
            sols = backend(seqs)
            m = spurious_variability_metrics(sols, seqs)
            rows.append({"method": name, "colour_gradient": float(g), **m})

    df = pd.DataFrame(rows)
    # Difference against the grey control, per method: the part attributable to
    # the gradient rather than to photon noise or to the model's own bias.
    if not df.empty and 0.0 in set(df["colour_gradient"]):
        base = (
            df[df["colour_gradient"] == 0.0]
            .set_index("method")["spurious_band_range_frac"]
            .to_dict()
        )
        df["excess_band_range_frac"] = [
            r["spurious_band_range_frac"] - base.get(r["method"], float("nan"))
            for _, r in df.iterrows()
        ]
    return df
