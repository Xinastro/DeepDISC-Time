"""Method-blind evaluation and the three headline experiments."""
from .experiments import (
    blend_resolved_table,
    evaluate,
    experiment_a_detection,
    experiment_b_amortization,
    experiment_c_epoch_ablation,
)
from .metrics import (
    calibration_metrics,
    detection_metrics,
    drw_recovery,
    lightcurve_metrics,
    match_sources,
    pit_values,
    throughput_metrics,
    variability_metrics,
)

__all__ = [
    "match_sources", "detection_metrics", "lightcurve_metrics", "pit_values",
    "calibration_metrics", "variability_metrics", "drw_recovery", "throughput_metrics",
    "evaluate", "experiment_a_detection", "experiment_b_amortization",
    "experiment_c_epoch_ablation", "blend_resolved_table",
]
