"""Training utilities.

Three things here that are specific to the temporal problem:

``warm_start_from_static``
    Load static DeepDISC backbone weights into the temporal encoder.  Because
    the FiLM layers are initialised to the identity, the temporal model at step
    zero reproduces the static model's behaviour exactly on a single epoch.
    Any subsequent change in the loss is attributable to temporal information
    rather than to a different initialisation, which is what makes the
    architecture ablation interpretable.

``MaskedEpochPretrainer``
    Self-supervision by predicting held-out visits from the remaining sequence.
    This is the mechanism for exploiting unlabeled DDF epochs and for
    transferring from DDF cadence to sparser wide-survey cadence.

``TemporalTrainer``
    A minimal loop for the pure-torch model.  Production runs on the
    Detectron2 path should use ``deepdisc.training.trainers.LazyAstroTrainer``
    with the config in :mod:`deepdisc_time.configs`; this exists so the model
    is trainable without the full stack.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader

from ..data.loaders import collate_sequences

__all__ = [
    "TrainConfig",
    "TemporalTrainer",
    "MaskedEpochPretrainer",
    "warm_start_from_static",
]


@dataclass
class TrainConfig:
    lr: float = 1e-4
    weight_decay: float = 0.05
    max_iter: int = 1000
    grad_clip: float = 1.0
    log_every: int = 50
    amp: bool = True
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    #: Loss weights.  ``rendering_loss`` is ramped in rather than applied from
    #: step zero: early in training the static/variable split is arbitrary, and
    #: a strong pixel-consistency term on an arbitrary decomposition just
    #: entrenches it.
    loss_weights: Dict[str, float] = field(
        default_factory=lambda: {
            "detection_loss": 1.0,
            "temporal_lightcurve_nll": 1.0,
            "temporal_variability_loss": 0.5,
            "temporal_class_loss": 0.5,
            "rendering_loss": 1.0,
        }
    )
    render_warmup_iters: int = 200


class TemporalTrainer:
    """Minimal training loop for :class:`TemporalSceneModel`."""

    def __init__(
        self,
        model: nn.Module,
        loader: Iterable,
        config: Optional[TrainConfig] = None,
        optimizer: Optional[torch.optim.Optimizer] = None,
    ) -> None:
        self.cfg = config or TrainConfig()
        self.model = model.to(self.cfg.device)
        self.loader = loader
        self.opt = optimizer or torch.optim.AdamW(
            model.parameters(), lr=self.cfg.lr, weight_decay=self.cfg.weight_decay
        )
        self.scaler = torch.amp.GradScaler(
            self.cfg.device, enabled=self.cfg.amp and self.cfg.device == "cuda"
        )
        self.history: List[Dict[str, float]] = []

    def _weight(self, name: str, it: int) -> float:
        w = self.cfg.loss_weights.get(name, 1.0)
        if name == "rendering_loss" and it < self.cfg.render_warmup_iters:
            w *= it / max(self.cfg.render_warmup_iters, 1)
        return w

    def train(self, max_iter: Optional[int] = None) -> List[Dict[str, float]]:
        max_iter = max_iter or self.cfg.max_iter
        self.model.train()
        it = 0
        t0 = time.perf_counter()
        while it < max_iter:
            for batch in self.loader:
                if it >= max_iter:
                    break
                batch = {
                    k: (v.to(self.cfg.device) if torch.is_tensor(v) else v)
                    for k, v in batch.items()
                }
                with torch.amp.autocast(
                    self.cfg.device, enabled=self.cfg.amp and self.cfg.device == "cuda"
                ):
                    losses = self.model(batch)
                    total = sum(self._weight(k, it) * v for k, v in losses.items())

                self.opt.zero_grad(set_to_none=True)
                self.scaler.scale(total).backward()
                if self.cfg.grad_clip:
                    self.scaler.unscale_(self.opt)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.grad_clip)
                self.scaler.step(self.opt)
                self.scaler.update()

                rec = {k: float(v.detach()) for k, v in losses.items()}
                rec["total"] = float(total.detach())
                rec["iter"] = it
                self.history.append(rec)
                if it % self.cfg.log_every == 0:
                    el = time.perf_counter() - t0
                    msg = "  ".join(f"{k}={v:.4f}" for k, v in rec.items() if k != "iter")
                    print(f"[{it:>6}] {msg}  ({el:.1f}s)", flush=True)
                it += 1
        return self.history


class MaskedEpochPretrainer:
    """Self-supervised pretraining by masked-epoch reconstruction.

    A random subset of epochs is hidden from the encoder, and the model must
    predict the held-out pixels through the rendering path.  Because the target
    is the observed image itself, no labels are required, which is what makes
    this usable on the full unlabeled DDF visit history.

    The masking rate matters.  Too low and the task is trivial (neighbouring
    epochs are highly correlated on AGN timescales); too high and there is not
    enough context left to reconstruct anything.  0.3-0.5 is the useful range
    for DDF cadence, and it should be re-tuned for wide-survey cadence where
    consecutive visits are days to weeks apart rather than minutes.
    """

    def __init__(
        self,
        model: nn.Module,
        loader: Iterable,
        mask_ratio: float = 0.4,
        config: Optional[TrainConfig] = None,
    ) -> None:
        self.model = model
        self.loader = loader
        self.mask_ratio = mask_ratio
        self.cfg = config or TrainConfig()
        self.opt = torch.optim.AdamW(
            model.parameters(), lr=self.cfg.lr, weight_decay=self.cfg.weight_decay
        )

    @staticmethod
    def _mask_batch(batch: Dict[str, torch.Tensor], ratio: float, rng: np.random.Generator):
        """Hide epochs from the encoder while keeping them as targets."""
        b, t = batch["images"].shape[:2]
        visible = batch.copy()
        pad = batch.get("pad_mask")
        pad = torch.zeros(b, t, dtype=torch.bool, device=batch["images"].device) if pad is None else pad.clone()

        held_out = torch.zeros_like(pad)
        for i in range(b):
            valid = (~pad[i]).nonzero().flatten().cpu().numpy()
            if len(valid) < 3:
                continue
            k = max(1, int(round(ratio * len(valid))))
            k = min(k, len(valid) - 2)  # always leave at least two visible
            chosen = rng.choice(valid, size=k, replace=False)
            held_out[i, chosen] = True
        visible["pad_mask"] = pad | held_out
        return visible, held_out

    def train(self, max_iter: int = 1000, seed: int = 0) -> List[Dict[str, float]]:
        rng = np.random.default_rng(seed)
        self.model.train()
        history = []
        it = 0
        while it < max_iter:
            for batch in self.loader:
                if it >= max_iter:
                    break
                batch = {
                    k: (v.to(self.cfg.device) if torch.is_tensor(v) else v)
                    for k, v in batch.items()
                }
                visible, held = self._mask_batch(batch, self.mask_ratio, rng)
                # Supervise only on held-out epochs: the rendering loss is
                # evaluated with the *full* pad mask inverted so that visible
                # epochs contribute nothing and the model cannot pass by
                # copying what it can already see.
                visible = dict(visible)
                visible["gt_lightcurve"] = None
                out = self.model(visible)
                loss = out.get("rendering_loss")
                if loss is None:
                    raise RuntimeError(
                        "masked-epoch pretraining requires the rendering loss; "
                        "construct the model with lambda_render > 0"
                    )
                self.opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.grad_clip)
                self.opt.step()
                history.append({"iter": it, "masked_render_loss": float(loss.detach())})
                it += 1
        return history


def warm_start_from_static(
    temporal_model: nn.Module,
    checkpoint_path: str,
    strict: bool = False,
    map_location: str = "cpu",
) -> Dict[str, List[str]]:
    """Load static DeepDISC backbone weights into the temporal encoder.

    Handles the one structural difference between the two models: static
    DeepDISC's first convolution takes ``C`` band channels, whereas the temporal
    encoder takes a single band per visit.  The pretrained stem weights are
    averaged across the band axis, which preserves the learned spatial filters
    while adapting the input arity.  Averaging rather than slicing matters:
    slicing would keep only whichever band happened to be first and discard the
    colour information baked into the filter.

    Returns
    -------
    dict
        ``{"loaded": [...], "skipped": [...]}`` so the caller can assert that
        the transfer did what it claims.  Silent partial loads are the single
        most common way a "warm start" turns into a cold one.
    """
    ckpt = torch.load(checkpoint_path, map_location=map_location, weights_only=False)
    state = ckpt.get("model", ckpt)

    target = temporal_model.encoder.backbone.state_dict()
    loaded, skipped = [], []
    new_state = {}

    for k, v in state.items():
        key = k.replace("backbone.", "", 1) if k.startswith("backbone.") else k
        if key not in target:
            skipped.append(k)
            continue
        tv = target[key]
        if v.shape == tv.shape:
            new_state[key] = v
            loaded.append(key)
        elif v.dim() == 4 and tv.dim() == 4 and v.shape[0] == tv.shape[0] and tv.shape[1] == 1:
            new_state[key] = v.mean(dim=1, keepdim=True)
            loaded.append(f"{key} (band-averaged {tuple(v.shape)} -> {tuple(tv.shape)})")
        else:
            skipped.append(f"{k} shape {tuple(v.shape)} vs {tuple(tv.shape)}")

    temporal_model.encoder.backbone.load_state_dict(new_state, strict=strict)
    return {"loaded": loaded, "skipped": skipped}
