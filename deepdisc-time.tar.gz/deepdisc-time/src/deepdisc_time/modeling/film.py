"""FiLM conditioning of the shared encoder on per-epoch instrumental state.

The encoder is applied to every visit with shared weights, which keeps the
parameter count independent of sequence length.  Shared weights alone would
force the network to treat a 0.9" seeing frame and a 2.4" seeing frame
identically, so each epoch's feature maps are modulated by a feature-wise
affine transform (Perez et al. 2018) predicted from that epoch's measured PSF,
depth, noise, zeropoint and airmass.

Conceptually: shared weights say "this is how you read an image", and the FiLM
parameters say "this particular image was taken through two airmasses of soup,
so trust the small scales less".
"""

from __future__ import annotations

from typing import Dict, Optional, Sequence

import torch
from torch import nn

from ..core.schema import BANDS, META_FIELDS

__all__ = ["EpochConditioner", "FiLM", "FiLMFeatureModulator"]


class EpochConditioner(nn.Module):
    """Map per-epoch metadata to a conditioning vector.

    Continuous metadata (:data:`~deepdisc_time.core.schema.META_FIELDS`) goes
    through an MLP; the filter is a learned embedding, because band is
    categorical and Rubin visits are single-filter.

    Parameters
    ----------
    cond_dim : int
        Width of the output conditioning vector.
    n_meta : int
        Number of continuous metadata fields.
    n_bands : int
        Size of the filter vocabulary.
    """

    def __init__(
        self,
        cond_dim: int = 128,
        n_meta: int = len(META_FIELDS),
        n_bands: int = len(BANDS),
        hidden: int = 128,
    ) -> None:
        super().__init__()
        self.cond_dim = cond_dim
        self.band_embed = nn.Embedding(n_bands, cond_dim // 4)
        # Metadata arrives on wildly different scales (dt of order 1, sky level
        # of order 100s).  A LayerNorm on the raw input is cheaper and more
        # robust than maintaining hard-coded normalisation constants that would
        # silently go stale between DP1, DP2 and DR1.
        self.meta_norm = nn.LayerNorm(n_meta)
        self.mlp = nn.Sequential(
            nn.Linear(n_meta + cond_dim // 4, hidden),
            nn.SiLU(),
            nn.Linear(hidden, cond_dim),
        )

    def forward(self, meta: torch.Tensor, band_idx: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        meta : torch.Tensor
            ``(..., n_meta)`` continuous metadata.
        band_idx : torch.Tensor
            ``(...)`` integer filter indices.

        Returns
        -------
        torch.Tensor
            ``(..., cond_dim)``
        """
        b = self.band_embed(band_idx)
        x = torch.cat([self.meta_norm(meta), b], dim=-1)
        return self.mlp(x)


class FiLM(nn.Module):
    """Predict per-channel scale and shift from a conditioning vector.

    Initialised so that the modulation starts as the identity (``gamma = 1``,
    ``beta = 0``).  This matters when warm-starting from static DeepDISC
    weights: at step zero the temporal model reproduces the pretrained
    behaviour exactly, so any change in the loss is attributable to the
    conditioning rather than to a perturbed initialisation.
    """

    def __init__(self, cond_dim: int, n_channels: int) -> None:
        super().__init__()
        self.proj = nn.Linear(cond_dim, 2 * n_channels)
        nn.init.zeros_(self.proj.weight)
        nn.init.zeros_(self.proj.bias)
        self.n_channels = n_channels

    def forward(self, x: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        """Modulate ``x`` of shape ``(N, C, H, W)`` or ``(N, C)``."""
        gamma_beta = self.proj(cond)
        gamma, beta = gamma_beta.chunk(2, dim=-1)
        gamma = 1.0 + gamma
        if x.dim() == 4:
            gamma = gamma[..., None, None]
            beta = beta[..., None, None]
        return x * gamma + beta


class FiLMFeatureModulator(nn.Module):
    """Apply FiLM to every level of an FPN feature dict.

    Detectron2 backbones return ``{"p2": ..., "p5": ...}``; each level gets its
    own FiLM layer, because the conditioning acts differently at different
    spatial scales (seeing suppresses fine levels far more than coarse ones).
    """

    def __init__(self, cond_dim: int, channels: Dict[str, int]) -> None:
        super().__init__()
        self.films = nn.ModuleDict({k: FiLM(cond_dim, c) for k, c in channels.items()})

    def forward(
        self, features: Dict[str, torch.Tensor], cond: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        return {k: self.films[k](v, cond) if k in self.films else v for k, v in features.items()}
