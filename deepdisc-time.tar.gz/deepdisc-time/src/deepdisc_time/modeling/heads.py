"""ROI-level temporal heads.

Three outputs that per-scene forward modelling does not provide:

``p_variable``
    A *predicted* probability that a source has a variable component.  In
    scarlet2-TD, static-versus-variable is a constraint the user imposes on
    each source before fitting.  Here it is an output with an uncertainty,
    which is what permits blind discovery of variability in blended scenes
    rather than characterisation of variability already known to be there.

``lightcurve``
    A calibrated per-epoch flux posterior from a conditional flow or MDN.

``static_morphology``
    A time-invariant host model, used both as a science product and as the
    static term of the rendering loss.

The Detectron2 integration at the bottom follows the exact pattern of
``RedshiftPDFCasROIHeads`` in the public DeepDISC: subclass ``CascadeROIHeads``,
add ``_forward_*`` methods that return a loss dict in training and annotate
``Instances`` at inference, and wire it in through LazyConfig with
``model.roi_heads._target_``.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import torch
from torch import nn
from torch.nn import functional as F

from ..core.schema import BANDS
from .flows import FluxPosteriorHead, build_flux_head
from .temporal import TemporalTransformer

__all__ = ["TemporalROIHead", "TemporalHeadOutput", "build_temporal_roi_head"]


class TemporalHeadOutput:
    """Container for temporal head predictions (plain object; no Detectron2 dep)."""

    def __init__(
        self,
        p_variable_logit: torch.Tensor,
        flux_ctx: torch.Tensor,
        static_morph: torch.Tensor,
        class_logits: Optional[torch.Tensor] = None,
        delta_xy: Optional[torch.Tensor] = None,
        static_log_sed: Optional[torch.Tensor] = None,
    ) -> None:
        self.p_variable_logit = p_variable_logit  # (N,)
        self.flux_ctx = flux_ctx  # (N, T, ctx_dim)
        self.static_morph = static_morph  # (N, 1, m, m)
        self.class_logits = class_logits  # (N, n_classes)
        self.delta_xy = delta_xy  # (N, 2) centroid refinement, pixels
        self.static_log_sed = static_log_sed  # (N, n_bands) or None

    @property
    def static_sed(self) -> Optional[torch.Tensor]:
        """Per-band multiplicative amplitude of the static component, (N, n_bands).

        Returns None when the model was built with predict_sed=False, in
        which case every caller must fall back to a band-independent static
        component -- the behaviour of this package before v0.2.0 and, as of
        writing, of scarlet2 as well.
        """
        if self.static_log_sed is None:
            return None
        return torch.exp(self.static_log_sed)

    @property
    def p_variable(self) -> torch.Tensor:
        return torch.sigmoid(self.p_variable_logit)


class TemporalROIHead(nn.Module):
    """Temporal transformer plus task heads over per-epoch ROI features.

    Parameters
    ----------
    in_channels : int
        Channels of the pooled ROI feature maps.
    roi_size : int
        Spatial size of the pooled ROI features (e.g. 7 for RoIAlign 7x7).
    d_model : int
        Token width for the temporal transformer.
    n_classes : int
        Classification vocabulary, e.g. ``["star", "galaxy", "qso"]``.
    morph_size : int
        Side length of the predicted static morphology patch.
    flux_head : str
        ``"flow"`` or ``"mdn"``; the proposal's ablation knob.
    """

    def __init__(
        self,
        in_channels: int = 256,
        roi_size: int = 7,
        d_model: int = 256,
        cond_dim: int = 128,
        n_heads: int = 8,
        n_layers: int = 2,
        n_classes: int = 3,
        morph_size: int = 25,
        flux_head: str = "flow",
        flux_head_kwargs: Optional[dict] = None,
        predict_offset: bool = True,
        n_bands: int = len(BANDS),
        predict_sed: bool = True,
    ) -> None:
        super().__init__()
        self.roi_size = roi_size
        self.morph_size = morph_size
        self.d_model = d_model
        self.n_bands = n_bands
        self.predict_sed = predict_sed

        self.token_proj = nn.Sequential(
            nn.Flatten(start_dim=-3),
            nn.Linear(in_channels * roi_size * roi_size, d_model),
            nn.SiLU(),
        )
        self.temporal = TemporalTransformer(
            d_model=d_model, n_heads=n_heads, n_layers=n_layers, cond_dim=cond_dim
        )

        self.variability_head = nn.Sequential(
            nn.Linear(d_model, d_model // 2), nn.SiLU(), nn.Linear(d_model // 2, 1)
        )
        self.class_head = nn.Sequential(
            nn.Linear(d_model, d_model // 2), nn.SiLU(), nn.Linear(d_model // 2, n_classes)
        )
        self.offset_head = (
            nn.Sequential(nn.Linear(d_model, d_model // 2), nn.SiLU(), nn.Linear(d_model // 2, 2))
            if predict_offset
            else None
        )
        # Static morphology is decoded from the *pooled* (time-invariant)
        # representation on purpose: making it a function of the pooled token
        # rather than of any single epoch is what enforces "static" structurally
        # rather than relying on the loss to discover it.
        self.morph_decoder = nn.Sequential(
            nn.Linear(d_model, 256),
            nn.SiLU(),
            nn.Linear(256, morph_size * morph_size),
            nn.Softplus(),  # surface brightness is non-negative
        )

        # Per-band amplitude of the static component.  Predicted in log space
        # and zero-initialised, so an untrained or SED-disabled model reproduces
        # exactly the band-independent behaviour of earlier versions.
        #
        # Why this exists.  A single morphology shared across all bands is the
        # assumption both this package and scarlet2 made until now.  Real hosts
        # have colour gradients: a bluer disc and a redder bulge mean the host's
        # apparent morphology is not the same in u as in y.  Fitting one
        # band-independent morphology to such a host leaves residual structure
        # that the optimiser must put somewhere, and the nearest free parameter
        # is the variable point-source amplitude in the offending bands.  The
        # failure mode is therefore not a poor host model but a *spurious,
        # band-correlated light curve* -- an artefact in precisely the quantity
        # this package exists to measure.  See ``eval.experiments.experiment_d``.
        #
        # This head is the first-order fix: morphology stays band-independent,
        # but its amplitude does not, which captures a pure colour offset
        # (bulge/disc ratio) though not a genuine change of shape with
        # wavelength.  Band-conditioned *morphology* is the open research
        # question and is deliberately not attempted here.
        self.sed_decoder = (
            nn.Linear(d_model, n_bands) if predict_sed else None
        )
        if self.sed_decoder is not None:
            nn.init.zeros_(self.sed_decoder.weight)
            nn.init.zeros_(self.sed_decoder.bias)

        # The flux head is conditioned on the refined per-epoch token *and* the
        # pooled context, so that per-epoch flux is informed by the whole light
        # curve rather than estimated epoch-by-epoch in isolation.
        self.flux_head: FluxPosteriorHead = build_flux_head(
            flux_head, ctx_dim=2 * d_model, **(flux_head_kwargs or {})
        )

    def forward(
        self,
        roi_features: torch.Tensor,
        t_days: torch.Tensor,
        cond: torch.Tensor,
        pad_mask: Optional[torch.Tensor] = None,
    ) -> TemporalHeadOutput:
        """
        Parameters
        ----------
        roi_features : torch.Tensor
            ``(N, T, C, r, r)`` per-epoch pooled features for N proposals.
        t_days : torch.Tensor
            ``(N, T)``
        cond : torch.Tensor
            ``(N, T, cond_dim)``
        pad_mask : torch.Tensor, optional
            ``(N, T)``
        """
        tokens = self.token_proj(roi_features)  # (N, T, d_model)
        refined, pooled = self.temporal(tokens, t_days, cond, pad_mask)

        ctx = torch.cat([refined, pooled.unsqueeze(1).expand_as(refined)], dim=-1)
        morph = self.morph_decoder(pooled).reshape(-1, 1, self.morph_size, self.morph_size)

        return TemporalHeadOutput(
            p_variable_logit=self.variability_head(pooled).squeeze(-1),
            flux_ctx=ctx,
            static_morph=morph,
            class_logits=self.class_head(pooled),
            delta_xy=None if self.offset_head is None else self.offset_head(pooled),
            static_log_sed=None if self.sed_decoder is None else self.sed_decoder(pooled),
        )

    def losses(
        self,
        out: TemporalHeadOutput,
        gt_lightcurve: Optional[torch.Tensor] = None,
        gt_variable: Optional[torch.Tensor] = None,
        gt_class: Optional[torch.Tensor] = None,
        lc_mask: Optional[torch.Tensor] = None,
        flux_scale: float = 1.0,
        weights: Optional[Dict[str, float]] = None,
    ) -> Dict[str, torch.Tensor]:
        """Assemble the temporal loss terms.

        Parameters
        ----------
        gt_lightcurve : torch.Tensor, optional
            ``(N, T)`` true per-epoch flux, nJy.  Present for injected sources
            and for sources supervised by scarlet2-TD reference solutions;
            absent otherwise.
        lc_mask : torch.Tensor, optional
            ``(N, T)`` True where the light curve is supervised.  Unsupervised
            entries contribute nothing, which is how real DDF scenes with only
            partial labels are trained on without inventing targets.
        flux_scale : float
            Fluxes are divided by this before the likelihood.  A fixed scale
            keeps the flow operating on order-unity inputs across the ~5 dex of
            flux the DDFs span; without it the tails of the flow are asked to
            cover a dynamic range no reasonable transform handles.
        """
        w = {"lightcurve": 1.0, "variability": 1.0, "classification": 1.0, "sed": 1e-2}
        w.update(weights or {})
        losses: Dict[str, torch.Tensor] = {}
        device = out.p_variable_logit.device

        if gt_lightcurve is not None and gt_lightcurve.numel() > 0:
            x = gt_lightcurve / flux_scale
            logp = self.flux_head.log_prob(x, out.flux_ctx)
            if lc_mask is not None:
                m = lc_mask.to(logp.dtype)
                nll = -(logp * m).sum() / m.sum().clamp_min(1.0)
            else:
                nll = -logp.mean()
            losses["temporal_lightcurve_nll"] = w["lightcurve"] * nll

        if gt_variable is not None and gt_variable.numel() > 0:
            losses["temporal_variability_loss"] = w["variability"] * F.binary_cross_entropy_with_logits(
                out.p_variable_logit, gt_variable.to(out.p_variable_logit.dtype)
            )

        if gt_class is not None and out.class_logits is not None and gt_class.numel() > 0:
            # -1 marks "no label"; Detectron2's ignore_index convention, used
            # here for the same reason as in the group's DP1 stage-2 protocol:
            # detection annotations are dense, class labels are sparse.
            losses["temporal_class_loss"] = w["classification"] * F.cross_entropy(
                out.class_logits, gt_class.long(), ignore_index=-1
            )

        # Ridge penalty on the log SED.  Two jobs.  (1) It breaks the exact
        # degeneracy between a global rescaling of the morphology patch and a
        # uniform shift of the log SED, which is otherwise a flat direction the
        # optimiser will wander along.  (2) It is a prior that the static
        # component is grey unless the data say otherwise, so bands that are
        # absent from a sequence -- common in the DDFs, where u and y coverage
        # is far thinner than griz -- stay at unit amplitude rather than
        # drifting freely.  Deliberately not a cross-band normalisation: with
        # missing bands, normalising over all six lets an unconstrained band
        # shift the amplitude of the constrained ones.
        if out.static_log_sed is not None:
            losses["temporal_sed_reg"] = w["sed"] * out.static_log_sed.pow(2).mean()

        if not losses:
            losses["temporal_noop"] = torch.zeros((), device=device)
        return losses


def build_temporal_roi_head(**kwargs) -> TemporalROIHead:
    return TemporalROIHead(**kwargs)


# --------------------------------------------------------------------------- #
# Detectron2 integration
# --------------------------------------------------------------------------- #
# Imported lazily so that the numerical core above is testable without a
# compiled Detectron2 build.  The class mirrors RedshiftPDFCasROIHeads in the
# public DeepDISC so that existing configs port with a one-line target change.

def make_temporal_cascade_roi_heads():  # pragma: no cover - requires detectron2
    """Construct and return the ``TemporalCascadeROIHeads`` class.

    Deferred to a factory so ``import deepdisc_time`` never requires
    Detectron2.  Call this from a LazyConfig::

        from deepdisc_time.modeling.heads import make_temporal_cascade_roi_heads
        model.roi_heads._target_ = make_temporal_cascade_roi_heads()
    """
    from detectron2.modeling.poolers import ROIPooler
    from detectron2.modeling.proposal_generator.proposal_utils import add_ground_truth_to_proposals
    from detectron2.modeling.roi_heads import CascadeROIHeads, select_foreground_proposals
    from detectron2.layers import cat

    class TemporalCascadeROIHeads(CascadeROIHeads):
        """CascadeROIHeads with temporal variability and light-curve heads.

        Extra keyword arguments beyond the Detectron2 base class:

        temporal_head : TemporalROIHead
        temporal_loss_weight : float
        flux_scale : float
        """

        def __init__(
            self,
            temporal_head: TemporalROIHead,
            temporal_loss_weight: float = 1.0,
            flux_scale: float = 100.0,
            **kwargs,
        ):
            super().__init__(**kwargs)
            self.temporal_head = temporal_head
            self.temporal_loss_weight = temporal_loss_weight
            self.flux_scale = flux_scale
            self.temporal_pooler = ROIPooler(
                output_size=temporal_head.roi_size,
                scales=tuple(k for k in [0.25, 0.125, 0.0625, 0.03125]),
                sampling_ratio=0,
                pooler_type="ROIAlignV2",
            )

        def _pool_per_epoch(self, epoch_features, boxes, n_epochs):
            """RoIAlign the same boxes on every epoch's feature maps.

            Boxes come from the temporally pooled scene features, so a source is
            localised once and then tracked across epochs.  That is the
            structural reason the light curve is guaranteed to refer to the same
            object at every epoch, which forced photometry only achieves by
            assuming the coadd centroid was right.
            """
            per_epoch = []
            for t in range(n_epochs):
                feats = [epoch_features[f][:, t] for f in self.box_in_features]
                per_epoch.append(self.temporal_pooler(feats, boxes))
            return torch.stack(per_epoch, dim=1)  # (N, T, C, r, r)

        def _forward_temporal(
            self, epoch_features, instances, cond, t_days, pad_mask=None, targets=None
        ):
            if self.training:
                proposals = add_ground_truth_to_proposals(targets, instances)
                fg, _ = select_foreground_proposals(proposals, self.num_classes)
                instances = fg
            boxes = [x.proposal_boxes if self.training else x.pred_boxes for x in instances]
            n_per_img = [len(b) for b in boxes]
            if sum(n_per_img) == 0:
                return {} if self.training else instances

            n_epochs = t_days.shape[1]
            roi = self._pool_per_epoch(epoch_features, boxes, n_epochs)

            # Broadcast per-image epoch metadata to per-proposal.
            idx = torch.repeat_interleave(
                torch.arange(len(n_per_img), device=roi.device),
                torch.tensor(n_per_img, device=roi.device),
            )
            out = self.temporal_head(
                roi,
                t_days[idx],
                cond[idx],
                None if pad_mask is None else pad_mask[idx],
            )

            if self.training:
                gt_lc = cat([x.gt_lightcurve for x in instances]) if instances[0].has("gt_lightcurve") else None
                gt_var = cat([x.gt_variable for x in instances]) if instances[0].has("gt_variable") else None
                gt_cls = cat([x.gt_classes for x in instances])
                lc_mask = cat([x.gt_lightcurve_mask for x in instances]) if instances[0].has("gt_lightcurve_mask") else None
                losses = self.temporal_head.losses(
                    out,
                    gt_lightcurve=gt_lc,
                    gt_variable=gt_var,
                    gt_class=gt_cls,
                    lc_mask=lc_mask,
                    flux_scale=self.flux_scale,
                )
                return {k: v * self.temporal_loss_weight for k, v in losses.items()}

            mean, std = self.temporal_head.flux_head.mean_std(out.flux_ctx)
            splits = list(torch.cumsum(torch.tensor(n_per_img), 0).numpy())
            starts = [0] + splits[:-1]
            for i, inst in enumerate(instances):
                sl = slice(starts[i], splits[i])
                inst.pred_lightcurve = mean[sl] * self.flux_scale
                inst.pred_lightcurve_err = std[sl] * self.flux_scale
                inst.pred_p_variable = out.p_variable[sl]
                inst.pred_static_morph = out.static_morph[sl]
                if out.delta_xy is not None:
                    inst.pred_delta_xy = out.delta_xy[sl]
            return instances

        def forward(
            self,
            images,
            features,
            proposals,
            targets=None,
            epoch_features=None,
            cond=None,
            t_days=None,
            pad_mask=None,
        ):
            del images
            if self.training:
                proposals = self.label_and_sample_proposals(proposals, targets)
                losses = self._forward_box(features, proposals, targets)
                losses.update(self._forward_mask(features, proposals))
                losses.update(
                    self._forward_temporal(
                        epoch_features, proposals, cond, t_days, pad_mask, targets
                    )
                )
                return proposals, losses
            pred = self._forward_box(features, proposals)
            pred = self.forward_with_given_boxes(features, pred)
            pred = self._forward_temporal(epoch_features, pred, cond, t_days, pad_mask)
            return pred, {}

    return TemporalCascadeROIHeads
