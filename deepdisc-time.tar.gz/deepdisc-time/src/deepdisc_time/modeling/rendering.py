"""Differentiable multi-epoch scene rendering and the physics-informed loss.

This module is what makes the static/variable decomposition identifiable
without a difference-imaging template.  The model predicts, per source, a
time-invariant morphology and a per-epoch point-source amplitude.  Rendering
those through each epoch's *measured* PSF and comparing to that epoch's pixels
under that epoch's variance plane is the same likelihood scarlet2 optimises per
scene -- the difference is that here it is a training signal shaping an
amortized encoder rather than a per-scene objective.

The DP2 relevance is concrete: the DDF dither pattern early in commissioning
limited template construction, so a method that never needs a template is not
merely an architectural preference on this dataset.

A decomposition that explains one epoch but fails when propagated through
another epoch's observing conditions is penalised, which is exactly the
constraint that stops the network from dumping variable flux into the host.
"""

from __future__ import annotations

from typing import Optional, Tuple

import torch
from torch import nn
from torch.nn import functional as F

__all__ = ["psf_convolve", "render_point_sources", "render_scene", "RenderingLoss"]


def psf_convolve(images: torch.Tensor, psfs: torch.Tensor) -> torch.Tensor:
    """Convolve each image plane with its own PSF kernel.

    Parameters
    ----------
    images : torch.Tensor
        ``(B, T, H, W)``
    psfs : torch.Tensor
        ``(B, T, k, k)``, k odd, each kernel summing to 1.

    Returns
    -------
    torch.Tensor
        ``(B, T, H, W)``

    Notes
    -----
    Implemented as a grouped convolution with ``B*T`` groups so that every
    epoch gets its own kernel in a single kernel launch.  Looping over epochs
    is correct but ~T times slower, and T is of order 10^2 for the DDFs.
    """
    b, t, h, w = images.shape
    k = psfs.shape[-1]
    if k % 2 != 1:
        raise ValueError("psf kernel must be odd-sized")
    pad = k // 2
    x = images.reshape(1, b * t, h, w)
    # Correlation vs convolution: flip the kernel so the operation is a true
    # convolution.  For symmetric PSFs this is a no-op, but Rubin PSFs are not
    # symmetric and the resulting half-pixel-scale astrometric bias would be
    # indistinguishable from a real transient-host offset.
    weight = torch.flip(psfs, dims=(-1, -2)).reshape(b * t, 1, k, k)
    out = F.conv2d(x, weight, padding=pad, groups=b * t)
    return out.reshape(b, t, h, w)


def render_point_sources(
    positions: torch.Tensor,
    amplitudes: torch.Tensor,
    psfs: torch.Tensor,
    shape: Tuple[int, int],
) -> torch.Tensor:
    """Render PSF-shaped sources at sub-pixel positions.

    Parameters
    ----------
    positions : torch.Tensor
        ``(B, S, 2)`` as ``(x, y)`` in pixels.
    amplitudes : torch.Tensor
        ``(B, S, T)`` fluxes.
    psfs : torch.Tensor
        ``(B, T, k, k)``
    shape : tuple
        ``(H, W)``

    Notes
    -----
    Uses an analytic re-centring of the kernel by bilinear interpolation on a
    coordinate grid, which keeps the operation differentiable with respect to
    ``positions``.  That gradient is what lets the model refine transient
    centroids, and hence measure the transient-host offset that distinguishes
    nuclear from non-nuclear events.
    """
    b, s, _ = positions.shape
    t = amplitudes.shape[-1]
    h, w = shape
    k = psfs.shape[-1]
    device, dtype = positions.device, positions.dtype

    # Sample the PSF kernel onto the full stamp, centred on each source.
    yy, xx = torch.meshgrid(
        torch.arange(h, device=device, dtype=dtype),
        torch.arange(w, device=device, dtype=dtype),
        indexing="ij",
    )
    c = (k - 1) / 2.0
    # (B, S, H, W) offsets in kernel-pixel units
    dx = xx[None, None] - positions[..., 0][..., None, None] + c
    dy = yy[None, None] - positions[..., 1][..., None, None] + c
    # grid_sample expects normalised [-1, 1] coordinates
    gx = 2.0 * dx / max(k - 1, 1) - 1.0
    gy = 2.0 * dy / max(k - 1, 1) - 1.0
    grid = torch.stack([gx, gy], dim=-1)  # (B, S, H, W, 2)

    out = torch.zeros(b, t, h, w, device=device, dtype=dtype)
    for ti in range(t):
        kern = psfs[:, ti].unsqueeze(1)  # (B, 1, k, k)
        kern = kern.expand(b, s, k, k).reshape(b * s, 1, k, k)
        g = grid.reshape(b * s, h, w, 2)
        stamps = F.grid_sample(kern, g, mode="bilinear", align_corners=True, padding_mode="zeros")
        stamps = stamps.reshape(b, s, h, w)
        out[:, ti] = (stamps * amplitudes[..., ti][..., None, None]).sum(dim=1)
    return out


def render_scene(
    static_model: torch.Tensor,
    positions: torch.Tensor,
    variable_amplitudes: torch.Tensor,
    psfs: torch.Tensor,
) -> torch.Tensor:
    """Full forward model: static morphology plus variable point sources.

    Parameters
    ----------
    static_model : torch.Tensor
        ``(B, H, W)`` or ``(B, T, H, W)``, pre-seeing (i.e. deconvolved) surface
        brightness of the time-invariant scene.  Convolved separately at each
        epoch, which is the entire point: one intrinsic scene, many
        instrumental realisations.

        The ``(B, H, W)`` form is the band-independent static component: one
        map reused for every epoch regardless of filter.  The ``(B, T, H, W)``
        form carries a per-epoch static map, which is how a per-band amplitude
        enters -- the map is still time-invariant within a band, but epochs in
        different filters see differently scaled versions of it.  The scene is
        *not* free to vary epoch to epoch within a band; that would make the
        static/variable decomposition unidentifiable.  See
        :func:`deepdisc_time.modeling.meta_arch.build_static_per_epoch`.
    positions : torch.Tensor
        ``(B, S, 2)``
    variable_amplitudes : torch.Tensor
        ``(B, S, T)``
    psfs : torch.Tensor
        ``(B, T, k, k)``

    Returns
    -------
    torch.Tensor
        ``(B, T, H, W)`` predicted pixels.
    """
    t = psfs.shape[1]
    if static_model.dim() == 3:
        b, h, w = static_model.shape
        static_bt = static_model.unsqueeze(1).expand(b, t, h, w).contiguous()
    elif static_model.dim() == 4:
        b, t_s, h, w = static_model.shape
        if t_s != t:
            raise ValueError(
                f"static_model has {t_s} epochs but {t} PSFs were supplied"
            )
        static_bt = static_model.contiguous()
    else:
        raise ValueError(
            f"static_model must be (B, H, W) or (B, T, H, W), got {tuple(static_model.shape)}"
        )
    static_t = psf_convolve(static_bt, psfs)
    variable_t = render_point_sources(positions, variable_amplitudes, psfs, (h, w))
    return static_t + variable_t


class RenderingLoss(nn.Module):
    """Noise-weighted pixel likelihood of the rendered multi-epoch scene.

    Parameters
    ----------
    reduction : str
        ``"mean"`` (per pixel) or ``"sum"``.
    huber_delta : float or None
        If set, uses a Huber loss on the whitened residual instead of a plain
        chi-square.  Strongly recommended on real data: cosmic rays, satellite
        trails and unmasked artefacts are common in single-visit frames, and a
        pure chi-square lets a handful of hot pixels dominate the gradient for
        a whole scene.
    epoch_weights : bool
        If True, epochs are weighted by inverse median variance in addition to
        the per-pixel weighting.  This is how below-threshold DP2 visits
        (roughly 4000 of them, released as single-visit products only) get
        down-weighted rather than discarded.
    """

    def __init__(
        self,
        reduction: str = "mean",
        huber_delta: Optional[float] = 5.0,
        epoch_weights: bool = True,
    ) -> None:
        super().__init__()
        if reduction not in {"mean", "sum"}:
            raise ValueError("reduction must be 'mean' or 'sum'")
        self.reduction = reduction
        self.huber_delta = huber_delta
        self.epoch_weights = epoch_weights

    def forward(
        self,
        predicted: torch.Tensor,
        observed: torch.Tensor,
        variance: torch.Tensor,
        pad_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Parameters
        ----------
        predicted, observed, variance : torch.Tensor
            ``(B, T, H, W)``.  ``variance`` must be strictly positive.
        pad_mask : torch.Tensor, optional
            ``(B, T)`` True where the epoch is padding.
        """
        resid = (predicted - observed) * torch.rsqrt(variance.clamp_min(1e-8))

        if self.huber_delta is not None:
            d = self.huber_delta
            a = resid.abs()
            per_pix = torch.where(a <= d, 0.5 * resid**2, d * (a - 0.5 * d))
        else:
            per_pix = 0.5 * resid**2

        per_epoch = per_pix.mean(dim=(-1, -2))  # (B, T)

        w = torch.ones_like(per_epoch)
        if self.epoch_weights:
            med = variance.flatten(2).median(dim=-1).values  # (B, T)
            w = torch.rsqrt(med.clamp_min(1e-8))
            w = w / w.mean(dim=1, keepdim=True).clamp_min(1e-8)
        if pad_mask is not None:
            w = w.masked_fill(pad_mask, 0.0)

        total = (per_epoch * w).sum(dim=1)
        if self.reduction == "sum":
            return total.sum()
        denom = w.sum(dim=1).clamp_min(1e-8)
        return (total / denom).mean()
