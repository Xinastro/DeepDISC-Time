"""Meta-architectures.

Two paths, deliberately:

:class:`TemporalSceneModel`
    A self-contained PyTorch model with no Detectron2 dependency.  It runs end
    to end on CPU, which makes the whole framework unit-testable, lets the
    amortization-frontier harness time a real forward pass on any machine, and
    gives the student a model they can iterate on before touching the cluster.
    Detection is a lightweight centre-heatmap head rather than an RPN.

:func:`make_generalized_rcnn_time`
    The production path.  Mirrors ``GeneralizedRCNNWCS`` in the public DeepDISC,
    threading per-epoch features, conditioning and observation times through to
    the ROI heads in the same way that class threads ``image_wcs``.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from ..core.schema import BANDS, SceneSolution, SourceSolution
from .encoder import EpochConditionedEncoder, SimpleConvBackbone
from .heads import TemporalROIHead
from .rendering import RenderingLoss, render_scene

__all__ = ["TemporalSceneModel", "make_generalized_rcnn_time"]


class CenterHeatmapHead(nn.Module):
    """Anchor-free detection head producing a source-centre heatmap.

    Runs on the *temporally pooled* scene features, so temporal information is
    available to detection.  That is the whole point of Experiment A: with
    ``pool_mode="mean"`` this head sees something close to a coadd, and with
    ``pool_mode="attn_var"`` it additionally sees an explicit across-epoch
    variance channel.  Comparing the two isolates the contribution of
    variability to detection itself.
    """

    def __init__(self, in_channels: int, hidden: int = 64) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, hidden, 3, padding=1),
            nn.SiLU(),
            nn.Conv2d(hidden, 1, 1),
        )
        # Focal-loss style prior: initialise so the model starts by predicting
        # "no source here", which is true for ~99.9% of pixels.
        nn.init.constant_(self.net[-1].bias, -4.6)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return self.net(features)

    @staticmethod
    def decode(
        logits: torch.Tensor, threshold: float = 0.3, nms_radius: int = 3, max_sources: int = 32
    ) -> List[torch.Tensor]:
        """Local-maximum decoding of a heatmap into ``(x, y, score)`` triples."""
        prob = torch.sigmoid(logits)
        pooled = F.max_pool2d(prob, 2 * nms_radius + 1, stride=1, padding=nms_radius)
        peaks = (prob == pooled) & (prob > threshold)
        out = []
        for b in range(prob.shape[0]):
            ys, xs = torch.nonzero(peaks[b, 0], as_tuple=True)
            scores = prob[b, 0, ys, xs]
            if scores.numel() > max_sources:
                keep = torch.topk(scores, max_sources).indices
                ys, xs, scores = ys[keep], xs[keep], scores[keep]
            out.append(torch.stack([xs.float(), ys.float(), scores], dim=-1))
        return out


class TemporalSceneModel(nn.Module):
    """End-to-end multi-epoch scene model.

    Parameters
    ----------
    backbone : nn.Module, optional
        Defaults to :class:`~deepdisc_time.modeling.encoder.SimpleConvBackbone`.
    detect_level : str
        Which feature level feeds the detection head; must be full resolution
        for the centre heatmap to be interpretable in image pixels.
    roi_size : int
    lambda_render : float
        Weight of the physics-informed rendering term.  Setting it to zero is
        the ablation that isolates its contribution.
    predict_sed : bool
        Whether the static component carries a per-band amplitude.  ``False``
        reproduces the band-independent static model used before v0.2.0, and is
        the control arm of Experiment D: it is the assumption scarlet2 also
        makes, so the with/without comparison measures the cost of that shared
        assumption rather than a difference between the two packages.
    """

    def __init__(
        self,
        backbone: Optional[nn.Module] = None,
        detect_level: str = "p2",
        cond_dim: int = 128,
        d_model: int = 128,
        roi_size: int = 7,
        n_classes: int = 3,
        morph_size: int = 25,
        flux_head: str = "flow",
        pool_mode: str = "attn_var",
        lambda_render: float = 1.0,
        flux_scale: float = 100.0,
        predict_sed: bool = True,
    ) -> None:
        super().__init__()
        backbone = backbone or SimpleConvBackbone(levels=(detect_level,))
        self.encoder = EpochConditionedEncoder(backbone, cond_dim=cond_dim, pool_mode=pool_mode)
        self.detect_level = detect_level
        ch = self.encoder.channels[detect_level]
        self.detector = CenterHeatmapHead(ch)
        self.roi_head = TemporalROIHead(
            in_channels=ch,
            roi_size=roi_size,
            d_model=d_model,
            cond_dim=cond_dim,
            n_classes=n_classes,
            morph_size=morph_size,
            flux_head=flux_head,
            predict_sed=predict_sed,
        )
        self.rendering_loss = RenderingLoss()
        self.lambda_render = lambda_render
        self.flux_scale = flux_scale
        self.roi_size = roi_size
        self.morph_size = morph_size

    # -- ROI extraction ----------------------------------------------------- #
    @staticmethod
    def _crop_rois(
        feats: torch.Tensor, positions: torch.Tensor, size: int
    ) -> torch.Tensor:
        """Bilinear ROI crop of ``(B, T, C, H, W)`` at ``(B, S, 2)`` positions.

        Returns ``(B*S, T, C, size, size)``.  Uses ``grid_sample`` rather than
        integer slicing so that gradients reach the positions, matching the
        renderer.
        """
        b, t, c, h, w = feats.shape
        s = positions.shape[1]
        half = (size - 1) / 2.0
        lin = torch.arange(size, device=feats.device, dtype=feats.dtype) - half
        dy, dx = torch.meshgrid(lin, lin, indexing="ij")
        gx = positions[..., 0][..., None, None] + dx  # (B, S, size, size)
        gy = positions[..., 1][..., None, None] + dy
        gx = 2.0 * gx / max(w - 1, 1) - 1.0
        gy = 2.0 * gy / max(h - 1, 1) - 1.0
        grid = torch.stack([gx, gy], dim=-1).reshape(b * s, size, size, 2)

        out = []
        for ti in range(t):
            f = feats[:, ti].repeat_interleave(s, dim=0)  # (B*S, C, H, W)
            out.append(F.grid_sample(f, grid, mode="bilinear", align_corners=True))
        return torch.stack(out, dim=1)  # (B*S, T, C, size, size)

    # -- forward ------------------------------------------------------------ #
    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        Parameters
        ----------
        batch : dict
            ``images`` ``(B, T, H, W)``; ``variances`` same; ``meta``
            ``(B, T, n_meta)``; ``band_idx`` ``(B, T)``; ``t_days`` ``(B, T)``;
            ``psfs`` ``(B, T, k, k)``; optional ``pad_mask`` ``(B, T)``;
            optional ``positions`` ``(B, S, 2)`` and supervision tensors.

        Returns
        -------
        dict
            In training mode, a dict of losses.  Otherwise, predictions.
        """
        images = batch["images"]
        b, t, h, w = images.shape
        pad_mask = batch.get("pad_mask")

        scene_feats, epoch_feats, cond = self.encoder(
            images, batch["meta"], batch["band_idx"], pad_mask
        )
        det_logits = self.detector(scene_feats[self.detect_level])

        positions = batch.get("positions")
        if positions is None:
            decoded = self.detector.decode(det_logits)
            npos = max(1, max(d.shape[0] for d in decoded))
            positions = torch.zeros(b, npos, 2, device=images.device, dtype=images.dtype)
            scores = torch.zeros(b, npos, device=images.device, dtype=images.dtype)
            for i, d in enumerate(decoded):
                if d.shape[0]:
                    positions[i, : d.shape[0]] = d[:, :2]
                    scores[i, : d.shape[0]] = d[:, 2]
        else:
            scores = torch.ones(b, positions.shape[1], device=images.device, dtype=images.dtype)

        s = positions.shape[1]
        roi = self._crop_rois(epoch_feats[self.detect_level], positions, self.roi_size)
        idx = torch.arange(b, device=images.device).repeat_interleave(s)
        out = self.roi_head(
            roi,
            batch["t_days"][idx],
            cond[idx],
            None if pad_mask is None else pad_mask[idx],
        )

        result: Dict[str, torch.Tensor] = {
            "det_logits": det_logits,
            "positions": positions,
            "scores": scores,
            "head_out": out,
        }

        if not self.training:
            mean, std = self.roi_head.flux_head.mean_std(out.flux_ctx, n=128)
            result["lightcurve"] = (mean * self.flux_scale).reshape(b, s, t)
            result["lightcurve_err"] = (std * self.flux_scale).reshape(b, s, t)
            result["p_variable"] = out.p_variable.reshape(b, s)
            result["static_morph"] = out.static_morph.reshape(b, s, self.morph_size, self.morph_size)
            if out.static_sed is not None:
                result["static_sed"] = out.static_sed.reshape(b, s, -1)
            if out.class_logits is not None:
                result["class_probs"] = torch.softmax(out.class_logits, -1).reshape(b, s, -1)
            return result

        losses = self.roi_head.losses(
            out,
            gt_lightcurve=batch.get("gt_lightcurve"),
            gt_variable=batch.get("gt_variable"),
            gt_class=batch.get("gt_class"),
            lc_mask=batch.get("gt_lightcurve_mask"),
            flux_scale=self.flux_scale,
        )
        if "gt_heatmap" in batch:
            losses["detection_loss"] = _focal_bce(det_logits, batch["gt_heatmap"])
        if self.lambda_render > 0 and "psfs" in batch:
            losses["rendering_loss"] = self.lambda_render * self._render_term(batch, out, positions)
        return losses

    def _render_term(self, batch, out, positions) -> torch.Tensor:
        """Physics-informed consistency between the decomposition and the pixels."""
        images = batch["images"]
        b, t, h, w = images.shape
        s = positions.shape[1]

        # Paint each source's predicted static morphology into a scene canvas.
        # With a predicted SED this is a per-epoch canvas: the morphology is
        # still time-invariant, but epochs in different filters see it scaled
        # differently.  Without one it collapses to the single band-independent
        # canvas used before v0.2.0.
        morph = out.static_morph.reshape(b, s, self.morph_size, self.morph_size)
        sed = out.static_sed
        if sed is not None:
            sed = sed.reshape(b, s, -1)
        static = build_static_per_epoch(
            morph, positions, batch["band_idx"], (h, w), sed=sed
        )

        # Point-source amplitudes: the posterior mean is used here rather than a
        # sample, so the rendering gradient is deterministic and does not fight
        # the likelihood gradient of the flux head.
        amps, _ = self.roi_head.flux_head.mean_std(out.flux_ctx, n=32)
        amps = (amps * self.flux_scale).reshape(b, s, t)

        pred = render_scene(static, positions, amps, batch["psfs"])
        return self.rendering_loss(pred, images, batch["variances"], batch.get("pad_mask"))

    # -- inference convenience ---------------------------------------------- #
    @torch.no_grad()
    def predict_scene(self, batch: Dict[str, torch.Tensor], scene_ids: List[str]) -> List[SceneSolution]:
        """Run inference and emit method-agnostic :class:`SceneSolution` objects.

        Every backend in :mod:`deepdisc_time.baselines` implements this same
        contract, which is what keeps the amortization comparison honest.
        """
        import time

        self.eval()
        start = time.perf_counter()
        out = self.forward(batch)
        elapsed = time.perf_counter() - start

        b, s, t = out["lightcurve"].shape
        per_scene = elapsed / max(b, 1)
        solutions = []
        for i in range(b):
            sources = []
            for j in range(s):
                if float(out["scores"][i, j]) <= 0:
                    continue
                sources.append(
                    SourceSolution(
                        x=float(out["positions"][i, j, 0]),
                        y=float(out["positions"][i, j, 1]),
                        lightcurve=out["lightcurve"][i, j].cpu().numpy(),
                        lightcurve_err=out["lightcurve_err"][i, j].cpu().numpy(),
                        p_variable=float(out["p_variable"][i, j]),
                        static_model=out["static_morph"][i, j].cpu().numpy(),
                        static_flux=_static_flux_dict(out, i, j),
                        score=float(out["scores"][i, j]),
                    )
                )
            solutions.append(
                SceneSolution(
                    scene_id=scene_ids[i],
                    sources=sources,
                    method="deepdisc_time",
                    wallclock_s=per_scene,
                    n_epochs=t,
                )
            )
        return solutions


def _focal_bce(logits: torch.Tensor, target: torch.Tensor, alpha: float = 2.0, beta: float = 4.0):
    """CornerNet-style penalty-reduced focal loss for centre heatmaps."""
    pos = (target >= 1.0 - 1e-4).float()
    p = torch.sigmoid(logits).clamp(1e-4, 1 - 1e-4)
    pos_loss = -((1 - p) ** alpha) * torch.log(p) * pos
    neg_loss = -((1 - target) ** beta) * (p**alpha) * torch.log(1 - p) * (1 - pos)
    n = pos.sum().clamp_min(1.0)
    return (pos_loss.sum() + neg_loss.sum()) / n


def _static_flux_dict(out: Dict[str, torch.Tensor], i: int, j: int) -> Dict[str, float]:
    """Integrated static flux per band for source ``j`` of scene ``i``.

    The morphology patch integrates to the band-averaged static flux; the SED
    scales it per filter.  With no SED predicted, every band gets the same
    number, which is the honest representation of a band-independent model
    rather than a silently omitted field.
    """
    total = float(out["static_morph"][i, j].sum())
    sed = out.get("static_sed")
    if sed is None:
        return {band: total for band in BANDS}
    amps = sed[i, j].cpu().numpy()
    return {band: total * float(amps[k]) for k, band in enumerate(BANDS[: len(amps)])}


def build_static_per_epoch(
    morph: torch.Tensor,
    positions: torch.Tensor,
    band_idx: torch.Tensor,
    shape: Tuple[int, int],
    sed: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """Paint per-source static morphologies into a per-epoch scene canvas.

    Parameters
    ----------
    morph : torch.Tensor
        ``(B, S, m, m)`` per-source static surface brightness patches.
    positions : torch.Tensor
        ``(B, S, 2)`` as ``(x, y)`` in pixels.
    band_idx : torch.Tensor
        ``(B, T)`` integer filter index per epoch.
    shape : tuple
        ``(H, W)``.
    sed : torch.Tensor, optional
        ``(B, S, n_bands)`` multiplicative per-band amplitude of the static
        component.  ``None`` reproduces the band-independent behaviour exactly.

    Returns
    -------
    torch.Tensor
        ``(B, T, H, W)``, or ``(B, H, W)`` when ``sed`` is ``None``.

    Notes
    -----
    Cost is why this is written the way it is.  The naive route builds one
    canvas per epoch, which is ``T`` paste operations; ``T`` runs to several
    hundred in the DDFs.  Since the static component depends on the epoch only
    through its *filter*, we build one canvas per band -- six, always -- and
    index by ``band_idx``.  The paste cost is therefore independent of sequence
    length, which matters because sequence length is the axis the whole project
    varies.

    The returned tensor is differentiable in ``positions`` and in ``sed``.
    """
    if sed is None:
        return _paste_patches(morph, positions, shape)

    n_bands = sed.shape[-1]
    h, w = shape
    per_band = torch.stack(
        [_paste_patches(morph * sed[..., k][..., None, None], positions, shape)
         for k in range(n_bands)],
        dim=1,
    )  # (B, n_bands, H, W)
    b = per_band.shape[0]
    # Out-of-place, deliberately.  ``band_idx`` is the same tensor the encoder
    # hands to its band embedding, and an embedding saves its index tensor for
    # backward; mutating it in place bumps the version counter and autograd
    # refuses the backward pass.  Caught by
    # ``test_model_trains_and_predicts_end_to_end``.
    idx = band_idx.long().clamp(0, n_bands - 1)  # (B, T)
    gather_idx = idx[:, :, None, None].expand(b, idx.shape[1], h, w)
    return torch.gather(per_band, 1, gather_idx)


def _paste_patches(
    patches: torch.Tensor, positions: torch.Tensor, shape: Tuple[int, int]
) -> torch.Tensor:
    """Additively paste ``(B, S, m, m)`` patches onto a ``(B, H, W)`` canvas.

    Uses inverse bilinear sampling of a zero-padded canvas coordinate grid so
    patch placement is sub-pixel and differentiable in ``positions``.
    """
    b, s, m, _ = patches.shape
    h, w = shape
    device, dtype = patches.device, patches.dtype
    half = (m - 1) / 2.0

    yy, xx = torch.meshgrid(
        torch.arange(h, device=device, dtype=dtype),
        torch.arange(w, device=device, dtype=dtype),
        indexing="ij",
    )
    dx = xx[None, None] - positions[..., 0][..., None, None] + half
    dy = yy[None, None] - positions[..., 1][..., None, None] + half
    gx = 2.0 * dx / max(m - 1, 1) - 1.0
    gy = 2.0 * dy / max(m - 1, 1) - 1.0
    grid = torch.stack([gx, gy], dim=-1).reshape(b * s, h, w, 2)

    src = patches.reshape(b * s, 1, m, m)
    painted = F.grid_sample(src, grid, mode="bilinear", align_corners=True, padding_mode="zeros")
    return painted.reshape(b, s, h, w).sum(dim=1)


def make_generalized_rcnn_time():  # pragma: no cover - requires detectron2
    """Construct and return ``GeneralizedRCNNTime``.

    Deferred behind a factory so importing this module never requires a
    compiled Detectron2 build.  Usage in a LazyConfig::

        from deepdisc_time.modeling.meta_arch import make_generalized_rcnn_time
        model._target_ = make_generalized_rcnn_time()
    """
    from detectron2.config import configurable
    from detectron2.modeling.backbone import Backbone
    from detectron2.modeling.postprocessing import detector_postprocess
    from detectron2.structures import ImageList

    class GeneralizedRCNNTime(nn.Module):
        """Generalized R-CNN over multi-epoch sequences.

        Differs from ``GeneralizedRCNNWCS`` in the public DeepDISC in three
        places: the encoder is applied per epoch and pooled before the RPN; the
        per-epoch features are kept alive and handed to the ROI heads; and the
        observation times and conditioning vectors are threaded through in the
        same way that class threads ``image_wcs``.
        """

        def __init__(
            self,
            *,
            encoder: EpochConditionedEncoder,
            proposal_generator: nn.Module,
            roi_heads: nn.Module,
            pixel_mean,
            pixel_std,
            vis_period: int = 0,
        ):
            super().__init__()
            self.encoder = encoder
            self.proposal_generator = proposal_generator
            self.roi_heads = roi_heads
            self.vis_period = vis_period
            self.register_buffer("pixel_mean", torch.tensor(pixel_mean).view(-1, 1, 1), False)
            self.register_buffer("pixel_std", torch.tensor(pixel_std).view(-1, 1, 1), False)

        @property
        def device(self):
            return self.pixel_mean.device

        def preprocess(self, batched_inputs):
            images = torch.stack([x["images"] for x in batched_inputs]).to(self.device)
            images = (images - self.pixel_mean.squeeze()) / self.pixel_std.squeeze()
            meta = torch.stack([x["meta"] for x in batched_inputs]).to(self.device)
            band = torch.stack([x["band_idx"] for x in batched_inputs]).to(self.device)
            t_days = torch.stack([x["t_days"] for x in batched_inputs]).to(self.device)
            pad = None
            if "pad_mask" in batched_inputs[0]:
                pad = torch.stack([x["pad_mask"] for x in batched_inputs]).to(self.device)
            return images, meta, band, t_days, pad

        def forward(self, batched_inputs):
            images, meta, band, t_days, pad = self.preprocess(batched_inputs)
            scene_feats, epoch_feats, cond = self.encoder(images, meta, band, pad)

            # The RPN expects an ImageList of the pooled scene; construct one
            # from the temporally aggregated representation.
            b, t, h, w = images.shape
            image_list = ImageList(images.mean(1, keepdim=True), [(h, w)] * b)

            if self.training:
                gt_instances = [x["instances"].to(self.device) for x in batched_inputs]
                proposals, proposal_losses = self.proposal_generator(
                    image_list, scene_feats, gt_instances
                )
                _, detector_losses = self.roi_heads(
                    image_list,
                    scene_feats,
                    proposals,
                    gt_instances,
                    epoch_features=epoch_feats,
                    cond=cond,
                    t_days=t_days,
                    pad_mask=pad,
                )
                losses = dict(proposal_losses)
                losses.update(detector_losses)
                return losses

            proposals, _ = self.proposal_generator(image_list, scene_feats, None)
            results, _ = self.roi_heads(
                image_list,
                scene_feats,
                proposals,
                None,
                epoch_features=epoch_feats,
                cond=cond,
                t_days=t_days,
                pad_mask=pad,
            )
            return results

    return GeneralizedRCNNTime
