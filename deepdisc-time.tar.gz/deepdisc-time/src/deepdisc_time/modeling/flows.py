"""Calibrated per-epoch flux posteriors.

Downstream time-domain inference is more sensitive to the *error bars* than to
the point estimates: DRW timescale and black-hole mass estimates are biased when
photometric errors are misspecified, and forced photometry on blended scenes is
exactly where they are misspecified.  So the light-curve head returns a
distribution, not a number.

Two implementations with a common interface:

* :class:`MDNFluxHead` -- a Gaussian mixture, matching the pattern already used
  by ``RedshiftPDFCasROIHeads`` in the public DeepDISC.  Cheap, well understood,
  and the sensible default for a first run.
* :class:`LogisticMixtureFlowHead` -- a conditional normalizing flow.  A 1-D
  variable cannot use affine coupling (there is nothing to split), so this uses
  a monotonic logistic-mixture CDF transform followed by a logit, in the manner
  of Flow++.  Strictly more expressive than the MDN in the tails, which is where
  photometric outliers live.

The architecture ablation in the proposal compares these directly; neither is
assumed superior in advance.
"""

from __future__ import annotations

import math
from typing import Optional, Tuple

import torch
from torch import nn
from torch.nn import functional as F

__all__ = ["FluxPosteriorHead", "MDNFluxHead", "LogisticMixtureFlowHead", "build_flux_head"]

_LOG_2PI = math.log(2.0 * math.pi)


class FluxPosteriorHead(nn.Module):
    """Interface for conditional 1-D flux posteriors."""

    def log_prob(self, x: torch.Tensor, ctx: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError

    def sample(self, ctx: torch.Tensor, n: int = 100) -> torch.Tensor:
        raise NotImplementedError

    def mean_std(self, ctx: torch.Tensor, n: int = 256) -> Tuple[torch.Tensor, torch.Tensor]:
        s = self.sample(ctx, n=n)
        return s.mean(0), s.std(0)

    def cdf(self, x: torch.Tensor, ctx: torch.Tensor) -> torch.Tensor:
        """CDF evaluated at ``x``.  Needed for probability integral transform."""
        raise NotImplementedError


class MDNFluxHead(FluxPosteriorHead):
    """Gaussian mixture density network over flux."""

    def __init__(self, ctx_dim: int, n_components: int = 5, hidden: int = 256) -> None:
        super().__init__()
        self.k = n_components
        self.net = nn.Sequential(
            nn.Linear(ctx_dim, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
            nn.SiLU(),
            nn.Linear(hidden, 3 * n_components),
        )

    def _params(self, ctx: torch.Tensor):
        out = self.net(ctx)
        logit_pi, mu, log_sigma = out.split(self.k, dim=-1)
        log_pi = F.log_softmax(logit_pi, dim=-1)
        # Clamp keeps the loss finite when a component collapses onto a point,
        # which happens routinely early in training on faint sources.
        log_sigma = log_sigma.clamp(-7.0, 7.0)
        return log_pi, mu, log_sigma

    def log_prob(self, x: torch.Tensor, ctx: torch.Tensor) -> torch.Tensor:
        log_pi, mu, log_sigma = self._params(ctx)
        z = (x.unsqueeze(-1) - mu) * torch.exp(-log_sigma)
        comp = -0.5 * (z**2 + _LOG_2PI) - log_sigma
        return torch.logsumexp(log_pi + comp, dim=-1)

    def cdf(self, x: torch.Tensor, ctx: torch.Tensor) -> torch.Tensor:
        log_pi, mu, log_sigma = self._params(ctx)
        z = (x.unsqueeze(-1) - mu) * torch.exp(-log_sigma)
        phi = 0.5 * (1.0 + torch.erf(z / math.sqrt(2.0)))
        return (log_pi.exp() * phi).sum(-1)

    def sample(self, ctx: torch.Tensor, n: int = 100) -> torch.Tensor:
        log_pi, mu, log_sigma = self._params(ctx)
        idx = torch.distributions.Categorical(logits=log_pi).sample((n,))
        mu_s = torch.gather(mu.expand(n, *mu.shape), -1, idx.unsqueeze(-1)).squeeze(-1)
        ls_s = torch.gather(log_sigma.expand(n, *log_sigma.shape), -1, idx.unsqueeze(-1)).squeeze(-1)
        return mu_s + torch.randn_like(mu_s) * torch.exp(ls_s)


class LogisticMixtureFlowHead(FluxPosteriorHead):
    """Conditional 1-D flow: logistic-mixture CDF, then logit, then a Gaussian base.

    The transform is

    .. math::
        z = \\sum_k \\pi_k \\sigma\\!\\left(\\frac{x - \\mu_k}{e^{s_k}}\\right),
        \\qquad u = \\operatorname{logit}(z), \\qquad u \\sim \\mathcal{N}(0, 1)

    which is monotonic in ``x`` for any valid mixture weights, hence a valid
    normalizing flow.  Every quantity below is computed in log space via
    ``logsumexp`` and ``logsigmoid``: the naive form underflows for
    well-separated components, which is the regime you land in as soon as the
    model becomes confident.
    """

    def __init__(
        self,
        ctx_dim: int,
        n_components: int = 8,
        n_blocks: int = 2,
        hidden: int = 256,
    ) -> None:
        super().__init__()
        self.k = n_components
        self.n_blocks = n_blocks
        self.nets = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(ctx_dim, hidden),
                    nn.SiLU(),
                    nn.Linear(hidden, hidden),
                    nn.SiLU(),
                    nn.Linear(hidden, 3 * n_components + 2),
                )
                for _ in range(n_blocks)
            ]
        )

    def _block_params(self, net: nn.Module, ctx: torch.Tensor):
        out = net(ctx)
        logit_pi, mu, log_s, a, b = out.split([self.k, self.k, self.k, 1, 1], dim=-1)
        return (
            F.log_softmax(logit_pi, dim=-1),
            mu,
            log_s.clamp(-5.0, 5.0),
            a.squeeze(-1).clamp(-3.0, 3.0),
            b.squeeze(-1),
        )

    def _forward_block(
        self, x: torch.Tensor, net: nn.Module, ctx: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """One block: affine pre-transform, then the monotonic CDF map."""
        log_pi, mu, log_s, a, b = self._block_params(net, ctx)
        y = x * torch.exp(a) + b
        log_det = a

        t = (y.unsqueeze(-1) - mu) * torch.exp(-log_s)
        log_z = torch.logsumexp(log_pi + F.logsigmoid(t), dim=-1)
        log_1mz = torch.logsumexp(log_pi + F.logsigmoid(-t), dim=-1)
        # d/dy of the mixture CDF, in log space.
        log_dzdy = torch.logsumexp(
            log_pi + F.logsigmoid(t) + F.logsigmoid(-t) - log_s, dim=-1
        )
        u = log_z - log_1mz  # logit(z), computed stably
        log_det = log_det + log_dzdy - log_z - log_1mz
        return u, log_det

    def log_prob(self, x: torch.Tensor, ctx: torch.Tensor) -> torch.Tensor:
        u = x
        log_det = torch.zeros_like(x)
        for net in self.nets:
            u, ld = self._forward_block(u, net, ctx)
            log_det = log_det + ld
        return -0.5 * (u**2 + _LOG_2PI) + log_det

    def cdf(self, x: torch.Tensor, ctx: torch.Tensor) -> torch.Tensor:
        u = x
        for net in self.nets:
            u, _ = self._forward_block(u, net, ctx)
        return 0.5 * (1.0 + torch.erf(u / math.sqrt(2.0)))

    @torch.no_grad()
    def sample(self, ctx: torch.Tensor, n: int = 100, iters: int = 40) -> torch.Tensor:
        """Sample by inverting the monotone map with bisection.

        There is no closed-form inverse of a logistic-mixture CDF.  Bisection is
        exact to machine precision in ~40 iterations here and is trivially
        parallel, which is what matters at survey scale.
        """
        shape = (n,) + ctx.shape[:-1]
        target = torch.rand(shape, device=ctx.device, dtype=ctx.dtype)
        ctx_e = ctx.expand(n, *ctx.shape)

        lo = torch.full(shape, -50.0, device=ctx.device, dtype=ctx.dtype)
        hi = torch.full(shape, 50.0, device=ctx.device, dtype=ctx.dtype)
        for _ in range(iters):
            mid = 0.5 * (lo + hi)
            c = self.cdf(mid, ctx_e)
            go_up = c < target
            lo = torch.where(go_up, mid, lo)
            hi = torch.where(go_up, hi, mid)
        return 0.5 * (lo + hi)


def build_flux_head(kind: str, ctx_dim: int, **kwargs) -> FluxPosteriorHead:
    """Factory used by the LazyConfig so the head is an ablatable knob."""
    kind = kind.lower()
    if kind in {"mdn", "gmm"}:
        return MDNFluxHead(ctx_dim, **kwargs)
    if kind in {"flow", "logistic_flow"}:
        return LogisticMixtureFlowHead(ctx_dim, **kwargs)
    raise ValueError(f"unknown flux head {kind!r}")
