"""Epoch-conditioned shared encoder.

One backbone, applied to every visit with shared weights and FiLM conditioning
on that visit's instrumental state, followed by temporal pooling into a
scene-level feature map for the RPN.

The single most consequential implementation detail is the input convention.
Static DeepDISC feeds a ``(H, W, C)`` band stack: bands are channels.  Rubin
visits are single-filter, so a multi-epoch sequence is not a band stack -- it is
``T`` single-band frames whose filter identity is metadata.  Stacking them as
channels would (a) fix the sequence length in the architecture and (b) discard
the irregular cadence.  Instead the epoch axis is folded into the batch, and
filter identity enters through the conditioner.

Memory note.  Activation memory scales linearly with ``T``.  A 32-epoch,
6-band-equivalent scene with full FPN activations exceeds an 80 GB A100 at any
useful batch size; ``chunk_size`` and ``grad_checkpoint`` exist so the model
degrades gracefully on smaller cards, but the intended target is GH200-class
coherent memory where the sequence axis does not have to be traded against
batch size.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import torch
from torch import nn
from torch.utils.checkpoint import checkpoint

from .film import EpochConditioner, FiLMFeatureModulator
from .temporal import TemporalFeaturePool

__all__ = ["EpochConditionedEncoder", "SimpleConvBackbone"]


class SimpleConvBackbone(nn.Module):
    """Small FPN-like backbone used for tests and CPU smoke runs.

    Production configs should substitute the MViTv2+FPN backbone from
    ``deepdisc``/Detectron2 via LazyConfig; this exists so the package has no
    hard dependency on a compiled Detectron2 build for its unit tests.
    """

    def __init__(self, in_channels: int = 1, width: int = 32, levels: Sequence[str] = ("p2", "p3")):
        super().__init__()
        self.levels = tuple(levels)
        self.stem = nn.Sequential(
            nn.Conv2d(in_channels, width, 3, padding=1),
            nn.GroupNorm(4, width),
            nn.SiLU(),
            nn.Conv2d(width, width, 3, padding=1),
            nn.GroupNorm(4, width),
            nn.SiLU(),
        )
        self.downs = nn.ModuleList(
            [nn.Conv2d(width, width, 3, stride=2, padding=1) for _ in range(len(self.levels) - 1)]
        )
        self._out_channels = {lvl: width for lvl in self.levels}

    def output_shape(self) -> Dict[str, int]:
        return dict(self._out_channels)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        out = {}
        h = self.stem(x)
        out[self.levels[0]] = h
        for i, down in enumerate(self.downs):
            h = torch.nn.functional.silu(down(h))
            out[self.levels[i + 1]] = h
        return out


class EpochConditionedEncoder(nn.Module):
    """Encode a sequence of visits into per-epoch and scene-level features.

    Parameters
    ----------
    backbone : nn.Module
        Any module mapping ``(N, C_in, H, W)`` to a ``{level: (N, C, h, w)}``
        dict, i.e. the Detectron2 backbone interface.  Must expose
        ``output_shape()``.
    channels : dict
        ``{level: n_channels}``.  Taken from ``backbone.output_shape()`` when
        omitted; Detectron2 returns ``ShapeSpec`` objects, which are unpacked.
    cond_dim : int
    pool_mode : str
        Temporal pooling mode; see :class:`~deepdisc_time.modeling.temporal.TemporalFeaturePool`.
        ``"mean"`` is the ablation null for the architecture study.
    chunk_size : int, optional
        Process at most this many epochs at a time through the backbone.
    grad_checkpoint : bool
        Recompute backbone activations in the backward pass.
    """

    def __init__(
        self,
        backbone: nn.Module,
        channels: Optional[Dict[str, int]] = None,
        cond_dim: int = 128,
        pool_mode: str = "attn_var",
        chunk_size: Optional[int] = None,
        grad_checkpoint: bool = False,
    ) -> None:
        super().__init__()
        self.backbone = backbone
        if channels is None:
            raw = backbone.output_shape()
            channels = {k: getattr(v, "channels", v) for k, v in raw.items()}
        self.channels = dict(channels)
        self.conditioner = EpochConditioner(cond_dim=cond_dim)
        self.film = FiLMFeatureModulator(cond_dim, self.channels)
        self.pools = nn.ModuleDict(
            {k: TemporalFeaturePool(c, cond_dim, mode=pool_mode) for k, c in self.channels.items()}
        )
        self.chunk_size = chunk_size
        self.grad_checkpoint = grad_checkpoint
        self.cond_dim = cond_dim

    def _run_backbone(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        if self.grad_checkpoint and self.training:
            return checkpoint(self.backbone, x, use_reentrant=False)
        return self.backbone(x)

    def forward(
        self,
        images: torch.Tensor,
        meta: torch.Tensor,
        band_idx: torch.Tensor,
        pad_mask: Optional[torch.Tensor] = None,
    ) -> Tuple[Dict[str, torch.Tensor], Dict[str, torch.Tensor], torch.Tensor]:
        """
        Parameters
        ----------
        images : torch.Tensor
            ``(B, T, H, W)`` single-band visit frames.
        meta : torch.Tensor
            ``(B, T, n_meta)``
        band_idx : torch.Tensor
            ``(B, T)``
        pad_mask : torch.Tensor, optional
            ``(B, T)``, True where padding.

        Returns
        -------
        scene_features : dict
            ``{level: (B, C, h, w)}`` -- temporally pooled, fed to the RPN.
        epoch_features : dict
            ``{level: (B, T, C, h, w)}`` -- retained for ROI-level temporal
            attention and for the rendering loss.
        cond : torch.Tensor
            ``(B, T, cond_dim)``
        """
        b, t, h, w = images.shape
        cond = self.conditioner(meta, band_idx)  # (B, T, cond_dim)

        flat = images.reshape(b * t, 1, h, w)
        flat_cond = cond.reshape(b * t, -1)

        chunks = self.chunk_size or (b * t)
        collected: List[Dict[str, torch.Tensor]] = []
        for start in range(0, b * t, chunks):
            sl = slice(start, min(start + chunks, b * t))
            feats = self._run_backbone(flat[sl])
            feats = self.film(feats, flat_cond[sl])
            collected.append(feats)

        epoch_features: Dict[str, torch.Tensor] = {}
        for lvl in collected[0]:
            merged = torch.cat([c[lvl] for c in collected], dim=0)
            _, ch, fh, fw = merged.shape
            epoch_features[lvl] = merged.reshape(b, t, ch, fh, fw)

        scene_features = {
            lvl: self.pools[lvl](feat, cond, pad_mask) if lvl in self.pools else feat.mean(1)
            for lvl, feat in epoch_features.items()
        }
        return scene_features, epoch_features, cond
