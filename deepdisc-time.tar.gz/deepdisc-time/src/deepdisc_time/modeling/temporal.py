"""Temporal aggregation across irregularly sampled Rubin visits.

Two aggregation points, deliberately:

* :class:`TemporalFeaturePool` collapses dense per-epoch feature maps into one
  scene-level map that the RPN sees.  This is what makes Experiment A possible:
  if detection is run on a temporally aggregated feature map, then temporal
  information can in principle improve *detection*, not merely the photometry
  of sources already catalogued.  scarlet2-TD cannot address that question
  because it is handed a source list.
* :class:`TemporalTransformer` operates on ROI-level token sequences, one token
  per epoch per source, and produces both a pooled context vector (for
  classification and variability) and refined per-epoch tokens (for the light
  curve head).

Standard sinusoidal position encodings assume integer positions on a regular
grid.  Rubin cadence is neither.  :class:`ContinuousTimePositionalEncoding`
therefore encodes real-valued time lags directly, with a band of frequencies
spanning intra-night to season timescales.
"""

from __future__ import annotations

import math
from typing import Optional, Tuple

import torch
from torch import nn
from torch.nn import functional as F

__all__ = [
    "ContinuousTimePositionalEncoding",
    "TemporalTransformer",
    "TemporalFeaturePool",
]


class ContinuousTimePositionalEncoding(nn.Module):
    """Sinusoidal encoding of real-valued observation times.

    Frequencies are geometrically spaced between ``min_period`` and
    ``max_period`` days.  The defaults (0.02 d to 3000 d) bracket the range from
    intra-night dithered revisits to the multi-year AGN damping timescales the
    downstream science cares about, so the encoding does not alias the
    timescales of interest onto each other.

    Parameters
    ----------
    dim : int
        Output width; must be even.
    min_period, max_period : float
        Period bounds in days.
    """

    def __init__(self, dim: int, min_period: float = 0.02, max_period: float = 3000.0) -> None:
        super().__init__()
        if dim % 2 != 0:
            raise ValueError("dim must be even")
        n = dim // 2
        periods = torch.logspace(math.log10(min_period), math.log10(max_period), n)
        self.register_buffer("omega", 2.0 * math.pi / periods)
        self.dim = dim

    def forward(self, t_days: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        t_days : torch.Tensor
            ``(..., T)`` times in days, relative to any per-sequence origin.

        Returns
        -------
        torch.Tensor
            ``(..., T, dim)``
        """
        phase = t_days.unsqueeze(-1) * self.omega
        return torch.cat([torch.sin(phase), torch.cos(phase)], dim=-1)


class TemporalTransformer(nn.Module):
    """Self-attention over the epoch axis of ROI token sequences.

    Parameters
    ----------
    d_model : int
        Token width.
    n_heads, n_layers : int
    cond_dim : int
        Width of the per-epoch conditioning vector, added to each token so that
        attention can down-weight poor-seeing or below-threshold visits.
    """

    def __init__(
        self,
        d_model: int = 256,
        n_heads: int = 8,
        n_layers: int = 2,
        cond_dim: int = 128,
        dropout: float = 0.1,
        time_dim: int = 64,
    ) -> None:
        super().__init__()
        self.d_model = d_model
        self.time_enc = ContinuousTimePositionalEncoding(time_dim)
        self.time_proj = nn.Linear(time_dim, d_model)
        self.cond_proj = nn.Linear(cond_dim, d_model)
        layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=4 * d_model,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=n_layers)
        # Learned query for attention pooling; a mean over epochs would let a
        # long run of poor-seeing visits drown out the few good ones.
        self.pool_query = nn.Parameter(torch.randn(1, 1, d_model) * 0.02)
        self.pool_attn = nn.MultiheadAttention(d_model, n_heads, batch_first=True)

    def forward(
        self,
        tokens: torch.Tensor,
        t_days: torch.Tensor,
        cond: torch.Tensor,
        pad_mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Parameters
        ----------
        tokens : torch.Tensor
            ``(N, T, d_model)`` per-epoch ROI features.
        t_days : torch.Tensor
            ``(N, T)`` observation times in days.
        cond : torch.Tensor
            ``(N, T, cond_dim)`` per-epoch conditioning.
        pad_mask : torch.Tensor, optional
            ``(N, T)`` boolean, True where the epoch is padding.  Sequences in a
            batch have different lengths whenever scenes come from different
            fields, so this is the normal case, not an edge case.

        Returns
        -------
        refined : torch.Tensor
            ``(N, T, d_model)``
        pooled : torch.Tensor
            ``(N, d_model)``
        """
        x = tokens + self.time_proj(self.time_enc(t_days)) + self.cond_proj(cond)
        refined = self.encoder(x, src_key_padding_mask=pad_mask)

        q = self.pool_query.expand(refined.shape[0], -1, -1)
        pooled, _ = self.pool_attn(q, refined, refined, key_padding_mask=pad_mask)
        return refined, pooled.squeeze(1)


class TemporalFeaturePool(nn.Module):
    """Collapse ``(B, T, C, H, W)`` per-epoch feature maps to ``(B, C, H, W)``.

    The pooled map is what the RPN and box heads consume, so this is where
    temporal information gets a chance to help detection.

    Modes
    -----
    ``mean``
        Cheap ablation baseline.  Equivalent in spirit to coadding in feature
        space, and included precisely so the architecture ablation has a
        null against which attention can be judged.
    ``max``
        Sensitive to transients that are bright in a single epoch, at the cost
        of amplifying single-epoch artefacts (cosmic rays, satellite trails).
    ``attn``
        Per-pixel softmax over epochs from a learned score conditioned on
        instrumental state.  Default.
    ``attn_var``
        ``attn`` concatenated with the across-epoch variance of the features.
        The variance channel is an explicit variability statistic; it gives the
        RPN a direct handle on "something here changed", which is the whole
        premise of Experiment A.
    """

    def __init__(
        self,
        channels: int,
        cond_dim: int = 128,
        mode: str = "attn_var",
    ) -> None:
        super().__init__()
        if mode not in {"mean", "max", "attn", "attn_var"}:
            raise ValueError(f"unknown pooling mode {mode!r}")
        self.mode = mode
        self.channels = channels
        if mode in {"attn", "attn_var"}:
            self.score = nn.Conv2d(channels, 1, kernel_size=1)
            self.cond_score = nn.Linear(cond_dim, 1)
        if mode == "attn_var":
            self.merge = nn.Conv2d(2 * channels, channels, kernel_size=1)

    def forward(
        self,
        feats: torch.Tensor,
        cond: Optional[torch.Tensor] = None,
        pad_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Parameters
        ----------
        feats : torch.Tensor
            ``(B, T, C, H, W)``
        cond : torch.Tensor, optional
            ``(B, T, cond_dim)``
        pad_mask : torch.Tensor, optional
            ``(B, T)`` True where padding.
        """
        b, t, c, h, w = feats.shape
        valid = None
        if pad_mask is not None:
            valid = (~pad_mask).to(feats.dtype)[:, :, None, None, None]

        if self.mode == "mean":
            if valid is None:
                return feats.mean(dim=1)
            return (feats * valid).sum(1) / valid.sum(1).clamp_min(1e-6)

        if self.mode == "max":
            if valid is not None:
                feats = feats.masked_fill(valid == 0, float("-inf"))
            return feats.max(dim=1).values

        logits = self.score(feats.reshape(b * t, c, h, w)).reshape(b, t, 1, h, w)
        if cond is not None:
            logits = logits + self.cond_score(cond)[:, :, :, None, None]
        if pad_mask is not None:
            logits = logits.masked_fill(pad_mask[:, :, None, None, None], float("-inf"))
        weights = torch.softmax(logits, dim=1)
        pooled = (feats * weights).sum(dim=1)

        if self.mode == "attn":
            return pooled

        mean = (
            feats.mean(dim=1)
            if valid is None
            else (feats * valid).sum(1) / valid.sum(1).clamp_min(1e-6)
        )
        sq = (
            (feats**2).mean(dim=1)
            if valid is None
            else ((feats**2) * valid).sum(1) / valid.sum(1).clamp_min(1e-6)
        )
        var = (sq - mean**2).clamp_min(0.0)
        return self.merge(torch.cat([pooled, torch.sqrt(var + 1e-6)], dim=1))
