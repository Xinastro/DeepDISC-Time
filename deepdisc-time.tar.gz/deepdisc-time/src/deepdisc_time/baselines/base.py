"""Common backend interface and timing discipline."""

from __future__ import annotations

import time
from typing import Iterable, List, Optional

from ..core.schema import SceneSolution, Sequence

__all__ = ["SceneModelBackend"]


class SceneModelBackend:
    """Base class for anything that turns a :class:`Sequence` into a solution.

    Subclasses implement :meth:`_fit`.  :meth:`fit` wraps it with the timing and
    bookkeeping that every method must report identically, because the
    accuracy/throughput frontier is a headline deliverable and a comparison in
    which one side times only its inner loop is not a comparison.

    Timing convention: wall-clock from the moment the sequence is handed over to
    the moment a solution exists, including any per-scene initialisation.  For
    per-scene optimisers, initialisation is a real cost.  For amortized models it
    is amortized over the batch, which is the point.
    """

    name: str = "base"

    def _fit(self, seq: Sequence) -> SceneSolution:  # pragma: no cover - abstract
        raise NotImplementedError

    def fit(self, seq: Sequence) -> SceneSolution:
        start = time.perf_counter()
        sol = self._fit(seq)
        sol.wallclock_s = time.perf_counter() - start
        sol.method = self.name
        sol.scene_id = sol.scene_id or seq.scene_id
        sol.n_epochs = seq.n_epochs
        return sol

    def fit_many(self, seqs: Iterable[Sequence]) -> List[SceneSolution]:
        return [self.fit(s) for s in seqs]
