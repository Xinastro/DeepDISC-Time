"""Classical baselines: the pipelines DeepDISC-Time is trying to beat.

These are the production workflows, and implementing them faithfully matters
more than implementing them quickly.  If the baselines are strawmen, the
headline number is worthless.

Both baselines share the structural weakness the project targets: source
separation is decided once on a static image, and every error in that decision
propagates unchecked into the light curve.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np

from ..core.schema import SceneSolution, Sequence, SourceSolution
from ..data.injection import convolve_psf, render_point_source
from .base import SceneModelBackend

__all__ = ["StaticThenForcedPhotometry", "DIAForcedPhotometry", "psf_photometry"]


def psf_photometry(
    image: np.ndarray,
    variance: np.ndarray,
    psf: np.ndarray,
    x: float,
    y: float,
) -> Tuple[float, float]:
    """Optimally weighted PSF-fitting photometry at a fixed position.

    The standard estimator: with model ``m = f * P``, the inverse-variance
    weighted least-squares flux is ``f = sum(P*I/V) / sum(P^2/V)`` with variance
    ``1 / sum(P^2/V)``.

    Note what this *assumes*: that the only thing at ``(x, y)`` is the point
    source.  Any host or neighbour flux under the PSF is absorbed into ``f``.
    That is the bias this whole project exists to measure.
    """
    model = render_point_source(image.shape, x, y, psf)
    w = 1.0 / np.maximum(variance, 1e-12)
    denom = float((model**2 * w).sum())
    if denom <= 0:
        return float("nan"), float("nan")
    flux = float((model * image * w).sum() / denom)
    err = float(np.sqrt(1.0 / denom))
    return flux, err


class StaticThenForcedPhotometry(SceneModelBackend):
    """Detect and deblend on a coadd, then force-photometer each epoch.

    The dominant production workflow, and the one whose failure mode motivates
    the project: the deblend is computed on the *stacked* image, where a
    variable nucleus contributes its mean flux and is therefore maximally
    confused with its host.

    Parameters
    ----------
    detect : callable, optional
        ``detect(seq) -> (N, 2)`` positions.
    subtract_static : bool
        If False (the default, and the production behaviour), PSF photometry is
        done directly on each epoch at the coadd-derived position.  The measured
        flux is then nucleus plus whatever host light falls under the PSF, and
        because that host contribution grows with seeing, the recovered light
        curve acquires a seeing-correlated systematic.  That systematic is
        precisely what this project exists to measure, so the default must not
        hide it.

        If True, a coadd-derived static model is PSF-matched to each epoch and
        subtracted first.  Note this is close to, but not the same as, DIA: the
        coadd contains the source's *mean* nuclear flux, so subtracting it
        removes most of the signal and leaves a low-amplitude residual.

    Notes
    -----
    The static model must be matched to each epoch's PSF, not convolved with
    it.  The coadd is already seeing-convolved; convolving it again double-blurs
    the model and produces a large seeing-correlated residual that looks like a
    real photometric systematic.  An earlier version of this class had exactly
    that bug, and it made the baseline look far worse than it is.
    """

    name = "static_then_forced"

    def __init__(self, detect: Optional[callable] = None, subtract_static: bool = False) -> None:
        from .scarlet2_td import detect_peaks

        self.detect = detect or detect_peaks
        self.subtract_static = subtract_static

    def _coadd(self, seq: Sequence) -> Tuple[np.ndarray, np.ndarray, float]:
        w = 1.0 / seq.variances
        sigmas = np.array([e.psf_sigma for e in seq.epochs])
        return (seq.images * w).sum(0) / w.sum(0), 1.0 / w.sum(0), float(sigmas.min())

    def _fit(self, seq: Sequence) -> SceneSolution:
        positions = self.detect(seq)
        coadd, coadd_var, coadd_sigma = self._coadd(seq)

        sources: List[SourceSolution] = []
        for x, y in positions:
            lc = np.zeros(seq.n_epochs)
            err = np.zeros(seq.n_epochs)
            for t, epoch in enumerate(seq.epochs):
                img = seq.images[t]
                var = seq.variances[t]
                if self.subtract_static:
                    d2 = epoch.psf_sigma**2 - coadd_sigma**2
                    matched = (
                        convolve_psf(coadd, _gaussian_kernel(np.sqrt(d2), epoch.psf.shape[0]))
                        if d2 > 0
                        else coadd
                    )
                    img = img - matched
                    var = var + coadd_var
                lc[t], err[t] = psf_photometry(img, var, epoch.psf, x, y)
            sources.append(
                SourceSolution(
                    x=float(x),
                    y=float(y),
                    lightcurve=lc,
                    lightcurve_err=err,
                    p_variable=None,
                )
            )
        return SceneSolution(scene_id=seq.scene_id, sources=sources, method=self.name)


class DIAForcedPhotometry(SceneModelBackend):
    """Difference image analysis with a template built from the sequence itself.

    Parameters
    ----------
    template_fraction : float
        Fraction of epochs (best seeing first) used to build the template.
    match_psf : bool
        Convolve the template to each science epoch's PSF before subtracting.
        This is the step whose quality the DP2 commissioning dither pattern
        limited: without intra-night dithering, template construction in the
        DDFs was explicitly degraded.  Setting this False shows what happens
        when PSF matching is unavailable or wrong.

    Notes
    -----
    A real DIA implementation solves for a spatially varying convolution kernel
    (Alard & Lupton).  This is a simplified stand-in, adequate for a controlled
    comparison on small stamps with known PSFs but *not* a substitute for the
    Rubin ``ap_pipe`` outputs.  Production runs should compare against the DP2
    DIA source table directly; see ``scripts/run_experiments.py --dia-from-butler``.
    """

    name = "dia_forced"

    def __init__(
        self,
        detect: Optional[callable] = None,
        template_fraction: float = 0.3,
        match_psf: bool = True,
    ) -> None:
        from .scarlet2_td import detect_peaks

        self.detect = detect or detect_peaks
        self.template_fraction = template_fraction
        self.match_psf = match_psf

    def _build_template(self, seq: Sequence) -> Tuple[np.ndarray, np.ndarray, float]:
        sigmas = np.array([e.psf_sigma for e in seq.epochs])
        n = max(2, int(round(self.template_fraction * seq.n_epochs)))
        idx = np.argsort(sigmas)[:n]
        w = 1.0 / seq.variances[idx]
        tmpl = (seq.images[idx] * w).sum(0) / w.sum(0)
        tmpl_var = 1.0 / w.sum(0)
        return tmpl, tmpl_var, float(sigmas[idx].max())

    def _fit(self, seq: Sequence) -> SceneSolution:
        positions = self.detect(seq)
        tmpl, tmpl_var, tmpl_sigma = self._build_template(seq)

        sources: List[SourceSolution] = []
        for x, y in positions:
            lc = np.zeros(seq.n_epochs)
            err = np.zeros(seq.n_epochs)
            for t, epoch in enumerate(seq.epochs):
                if self.match_psf:
                    # Gaussian matching kernel; requires the science epoch to be
                    # broader than the template, which is why the template is
                    # built from the best-seeing frames.
                    d2 = epoch.psf_sigma**2 - tmpl_sigma**2
                    if d2 > 0:
                        k = _gaussian_kernel(np.sqrt(d2), epoch.psf.shape[0])
                        matched = convolve_psf(tmpl, k)
                    else:
                        matched = tmpl
                else:
                    matched = tmpl
                diff = seq.images[t] - matched
                lc[t], err[t] = psf_photometry(
                    diff, seq.variances[t] + tmpl_var, epoch.psf, x, y
                )
            sources.append(
                SourceSolution(
                    x=float(x),
                    y=float(y),
                    lightcurve=lc,
                    lightcurve_err=err,
                    p_variable=None,
                )
            )
        return SceneSolution(
            scene_id=seq.scene_id,
            sources=sources,
            method=self.name,
            diagnostics={"template_sigma": tmpl_sigma},
        )


def _gaussian_kernel(sigma: float, size: int) -> np.ndarray:
    size = size if size % 2 == 1 else size + 1
    c = (size - 1) / 2.0
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float64)
    g = np.exp(-((xx - c) ** 2 + (yy - c) ** 2) / (2 * max(sigma, 1e-3) ** 2))
    return (g / g.sum()).astype(np.float32)
