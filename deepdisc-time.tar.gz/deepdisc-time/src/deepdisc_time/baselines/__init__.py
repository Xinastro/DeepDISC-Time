"""Baseline scene-modelling methods.

Every backend implements the same contract::

    solution = backend.fit(sequence) -> SceneSolution

so that :mod:`deepdisc_time.eval` cannot tell which method produced a result.
That is deliberate.  The amortization comparison in the ACCESS proposal is only
meaningful if the metrics code is method-blind and the timing is measured the
same way on both sides.

The scarlet2 time-domain extension (Ward et al. 2025, *Astronomy and Computing*
51, 100930) is the reference standard here, not a strawman.  It already does
template-free multi-epoch static/variable decomposition, and does it well.  The
questions this package asks are the ones per-scene optimisation structurally
cannot answer: whether temporal information improves *detection*, what the
accuracy/throughput frontier looks like, and whether the static-versus-variable
assignment can be *predicted* rather than imposed.
"""

from .base import SceneModelBackend
from .forced_photometry import DIAForcedPhotometry, StaticThenForcedPhotometry
from .scarlet2_td import Scarlet2TDBackend

__all__ = [
    "SceneModelBackend",
    "DIAForcedPhotometry",
    "StaticThenForcedPhotometry",
    "Scarlet2TDBackend",
]
