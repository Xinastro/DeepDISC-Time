"""Adapter to the scarlet2 time-domain extension (Ward et al. 2025).

scarlet2-TD plays two distinct roles in this project and it is worth being
explicit about both, because they pull in opposite directions.

**Role 1: the accuracy baseline.**  It is the state of the art for template-free
multi-epoch static/variable decomposition.  Experiment B measures where an
amortized model sits relative to it on the accuracy/throughput plane, and the
honest expectation is that per-scene optimisation wins on accuracy in at least
some regimes.  For that comparison to mean anything, scarlet2-TD has to be run
*well* -- correct initialisation, adequate iterations, convergence checked -- not
run badly so the learned model looks good.

**Role 2: the supervision source.**  On real DDF scenes there is no injection
truth.  scarlet2-TD solutions supply static/variable decompositions and
component light curves that the network can be trained against.  This mirrors
the pattern already validated in the group's DP1 work, where scarlet supplied
the segmentation annotations DeepDISC learned to reproduce in one amortized
pass; the temporal case is the same move, with a much larger amortization gain
because per-scene cost now scales with epoch count.

Scenes where scarlet2-TD fails to converge are *retained*, flagged, and analysed
separately.  They are informative rather than inconvenient: they mark where
per-scene optimisation is fragile, and therefore where an amortized prior has
the most to offer.

Requires ``scarlet2`` (JAX).  Import is deferred so this module is importable
without it.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence as TSequence, Tuple

import numpy as np

from ..core.schema import SceneSolution, SceneTruth, Sequence, SourceSolution, SourceTruth
from .base import SceneModelBackend

__all__ = ["Scarlet2TDConfig", "Scarlet2TDBackend", "solutions_to_supervision"]


def _require_scarlet2():
    try:
        import scarlet2  # type: ignore

        return scarlet2
    except ImportError as exc:  # pragma: no cover
        raise ImportError(
            "scarlet2 is required for the reference baseline.\n"
            "  pip install 'jax[cuda12]' && pip install scarlet2\n"
            "See https://github.com/pmelchior/scarlet2 . On DeltaAI, install the "
            "CUDA 12 jaxlib wheel matching the GH200 driver stack before scarlet2."
        ) from exc


@dataclass
class Scarlet2TDConfig:
    """Fitting configuration.

    Parameters
    ----------
    max_iter : int
        Optimiser iterations.  The default is deliberately generous: an
        under-converged baseline would flatter the amortized model and
        invalidate Experiment B.
    rel_tol : float
        Relative change in loss below which the fit is declared converged.
    use_morphology_prior : bool
        Use the score-based galaxy morphology prior (Sampson et al. 2024).
        On by default because that is how scarlet2 is meant to be run, and
        disabling it would understate the baseline.
    prior_name : str
        Which pretrained score model to use.  Must be trained on imaging with
        comparable depth and resolution; a ZTF-trained prior on Rubin DDF data
        is a domain mismatch, not a free improvement.
    variable_source_hints : bool
        If True, sources flagged as candidate variables (e.g. from the DP2 DIA
        object table) are given a time-varying flux component and the rest are
        held static.  This is the *specified* decomposition that DeepDISC-Time
        replaces with a prediction, and it is worth measuring how much the
        baseline depends on that hint being correct.
    """

    max_iter: int = 500
    rel_tol: float = 1e-5
    learning_rate: float = 1e-2
    use_morphology_prior: bool = True
    prior_name: str = ""
    variable_source_hints: bool = True
    min_separation_px: float = 2.0


class Scarlet2TDBackend(SceneModelBackend):
    """Fit a :class:`Sequence` with the scarlet2 time-domain extension.

    Parameters
    ----------
    config : Scarlet2TDConfig
    detect : callable, optional
        ``detect(seq) -> np.ndarray`` of ``(x, y)`` source positions.  scarlet2
        requires an input source list; it models a scene given the sources
        rather than discovering them.  Supplying detection externally is not a
        limitation of this adapter, it is the design of the method, and it is
        precisely why Experiment A ("does time help detection?") cannot be
        answered with scarlet2 alone.
    """

    name = "scarlet2_td"

    def __init__(
        self,
        config: Optional[Scarlet2TDConfig] = None,
        detect: Optional[callable] = None,
    ) -> None:
        self.config = config or Scarlet2TDConfig()
        self.detect = detect or detect_peaks

    # -- translation layer -------------------------------------------------- #
    def build_observations(self, seq: Sequence) -> List:  # pragma: no cover
        """Translate a :class:`Sequence` into scarlet2 ``Observation`` objects.

        One observation per epoch, each carrying its own PSF and weights.
        scarlet2 supports multi-resolution observations, so the same code path
        extends to joint Rubin + Euclid or Rubin + Roman fitting without change
        -- worth noting because the group's cross-survey project shares this
        interface.
        """
        sc = _require_scarlet2()
        import jax.numpy as jnp

        observations = []
        for t, epoch in enumerate(seq.epochs):
            obs = sc.Observation(
                jnp.asarray(seq.images[t][None]),          # (1, H, W): one band per visit
                weights=jnp.asarray(1.0 / seq.variances[t][None]),
                psf=sc.GaussianPSF(epoch.psf_sigma) if epoch.psf is None else sc.ArrayPSF(
                    jnp.asarray(epoch.psf[None])
                ),
                channels=[f"{epoch.band}_{t}"],
            )
            observations.append(obs)
        return observations

    def _fit(self, seq: Sequence) -> SceneSolution:  # pragma: no cover - needs scarlet2
        sc = _require_scarlet2()
        import jax.numpy as jnp

        positions = self.detect(seq)
        observations = self.build_observations(seq)
        frame = sc.Frame.from_observations(observations)

        variable_flags = self._variable_hints(seq, positions)

        with sc.Scene(frame) as scene:
            for (x, y), is_var in zip(positions, variable_flags):
                centre = (float(y), float(x))  # scarlet2 uses (row, col)
                if is_var and self.config.variable_source_hints:
                    sc.PointSource(centre)   # flux free per observation => variable
                else:
                    sc.Source(centre)        # spectrum tied across observations => static

        loss_history: List[float] = []
        converged = False
        try:
            scene_fit = scene.fit(
                observations,
                max_iter=self.config.max_iter,
                e_rel=self.config.rel_tol,
                progress_bar=False,
            )
            loss_history = list(getattr(scene_fit, "loss", []) or [])
            converged = len(loss_history) < self.config.max_iter
        except Exception as exc:  # noqa: BLE001
            warnings.warn(f"scarlet2 fit failed for {seq.scene_id}: {exc}")
            return SceneSolution(
                scene_id=seq.scene_id, sources=[], method=self.name, converged=False
            )

        sources = []
        for i, src in enumerate(scene_fit.sources):
            lc = self._extract_lightcurve(src, seq.n_epochs)
            sources.append(
                SourceSolution(
                    x=float(positions[i][0]),
                    y=float(positions[i][1]),
                    lightcurve=lc,
                    lightcurve_err=None,   # a MAP fit gives no error bar; see note below
                    p_variable=None,       # imposed, not inferred -- reported as None on purpose
                    static_model=np.asarray(getattr(src, "morphology", np.zeros((1, 1)))),
                )
            )

        return SceneSolution(
            scene_id=seq.scene_id,
            sources=sources,
            method=self.name,
            converged=converged,
            n_epochs=seq.n_epochs,
            diagnostics={
                "n_iter": float(len(loss_history)),
                "final_loss": float(loss_history[-1]) if loss_history else float("nan"),
            },
        )

    def _variable_hints(self, seq: Sequence, positions: np.ndarray) -> List[bool]:
        """Which sources get a time-varying component.

        In production this should come from the DP2 DIA object table.  Falling
        back to "the brightest, most compact source is the variable one" is a
        reasonable heuristic for AGN-in-host scenes but is exactly the kind of
        prior knowledge that DeepDISC-Time is supposed to make unnecessary, so
        the fallback is logged rather than silent.
        """
        if not self.config.variable_source_hints:
            return [True] * len(positions)
        centre = np.array(seq.shape[::-1]) / 2.0
        d = np.linalg.norm(np.asarray(positions) - centre, axis=1)
        flags = [False] * len(positions)
        if len(flags):
            flags[int(np.argmin(d))] = True
        return flags

    @staticmethod
    def _extract_lightcurve(src, n_epochs: int) -> np.ndarray:  # pragma: no cover
        """Pull a per-epoch flux vector out of a fitted scarlet2 source.

        scarlet2 stores one spectrum entry per observation channel, and this
        adapter creates one channel per visit, so the spectrum *is* the light
        curve.  Guarded because the attribute layout has changed across
        scarlet2 releases; pin the version in the environment file.
        """
        spec = getattr(src, "spectrum", None)
        if spec is None:
            return np.full(n_epochs, np.nan)
        arr = np.asarray(getattr(spec, "data", spec)).ravel()
        if arr.size < n_epochs:
            out = np.full(n_epochs, np.nan)
            out[: arr.size] = arr
            return out
        return arr[:n_epochs]


def detect_peaks(seq: Sequence, threshold_sigma: float = 5.0, min_separation: int = 3) -> np.ndarray:
    """Simple peak detection on the inverse-variance-weighted stack.

    This is the *static* detection stage that scarlet2 requires as input, and
    it is also the control for Experiment A: if a temporally aware detector
    beats this, the gain is attributable to the temporal axis rather than to a
    better static detector.
    """
    w = 1.0 / seq.variances
    stack = (seq.images * w).sum(0) / w.sum(0)
    noise = 1.0 / np.sqrt(w.sum(0))
    snr = stack / np.maximum(noise, 1e-8)

    h, wd = snr.shape
    peaks = []
    r = min_separation
    for y in range(r, h - r):
        for x in range(r, wd - r):
            v = snr[y, x]
            if v < threshold_sigma:
                continue
            if v >= snr[y - r : y + r + 1, x - r : x + r + 1].max():
                peaks.append((float(x), float(y)))
    return np.asarray(peaks, dtype=np.float64).reshape(-1, 2)


def solutions_to_supervision(
    solutions: TSequence[SceneSolution],
    sequences: TSequence[Sequence],
    min_snr: float = 5.0,
    require_converged: bool = True,
) -> List[Sequence]:
    """Attach scarlet2-TD solutions to sequences as training targets.

    This is Role 2: turning a per-scene optimiser into a label factory for an
    amortized model on real data where no injection truth exists.

    Parameters
    ----------
    min_snr : float
        Light-curve points below this significance are masked out rather than
        used as targets.  Training a probabilistic head on noise-dominated
        "labels" teaches it that the noise is signal, which shows up later as
        overconfident posteriors on faint sources -- exactly the failure the
        calibration metrics are meant to catch.
    require_converged : bool
        Non-convergent scenes are excluded from *supervision* but should still
        be kept in the evaluation set, since they are where the amortized model
        may have the most to add.

    Returns
    -------
    list of Sequence
        Copies with ``truth.provenance == "scarlet2_td"``.
    """
    out: List[Sequence] = []
    by_id: Dict[str, SceneSolution] = {s.scene_id: s for s in solutions}

    for seq in sequences:
        sol = by_id.get(seq.scene_id)
        if sol is None or (require_converged and not sol.converged):
            continue
        sources: List[SourceTruth] = []
        for src in sol.sources:
            lc = np.asarray(src.lightcurve, dtype=np.float64)
            if src.lightcurve_err is not None:
                snr = lc / np.maximum(np.asarray(src.lightcurve_err), 1e-8)
                lc = np.where(np.abs(snr) >= min_snr, lc, np.nan)
            sources.append(
                SourceTruth(
                    x=src.x,
                    y=src.y,
                    # A scarlet2 source is variable because we told it to be.
                    # Recording that provenance keeps us honest: the network is
                    # being taught a *hint*, not a measurement, and the
                    # variability head's calibration must be checked against
                    # injection truth, never against this.
                    is_variable=bool(np.nanstd(lc) > 0),
                    variable_flux=lc,
                    source_type="unknown",
                )
            )
        out.append(
            Sequence(
                images=seq.images,
                variances=seq.variances,
                epochs=seq.epochs,
                scene_id=seq.scene_id,
                ra=seq.ra,
                dec=seq.dec,
                truth=SceneTruth(sources=sources, provenance="scarlet2_td"),
                wcs_header=seq.wcs_header,
            )
        )
    return out
