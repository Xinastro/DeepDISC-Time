"""LazyConfig for DeepDISC-Time on the Rubin DP2 Deep Drilling Fields.

Follows the structure of ``configs/solo/demo_r50_btk_photoz.py`` in the public
DeepDISC so that anyone familiar with that repo can read this one: import the
COCO base, override the model target, swap the ROI heads, point the dataloader
at custom mappers.

Run with::

    python scripts/train_time.py \\
        --config-file src/deepdisc_time/configs/deepdisc_time_ddf.py \\
        --num-gpus 4 --run-name ddf_v1

Requires Detectron2 and ``deepdisc``.  Import will fail without them, which is
intentional: this file *is* the production path.
"""

from omegaconf import OmegaConf

from detectron2.config import LazyCall as L

# Base model, optimizer, and schedule from the DeepDISC COCO configs.
from deepdisc.configs.COCO.cascade_mask_rcnn_mvitv2_b_in21k_100ep import (  # noqa: F401
    dataloader,
    lr_multiplier,
    optimizer,
    train,
)
from deepdisc.configs.common.models.cascade_rcnn import model  # noqa: F401

from deepdisc_time.data.loaders import EpochSampler, make_multi_epoch_dict_mapper
from deepdisc_time.modeling.encoder import EpochConditionedEncoder
from deepdisc_time.modeling.heads import TemporalROIHead, make_temporal_cascade_roi_heads
from deepdisc_time.modeling.meta_arch import make_generalized_rcnn_time

# --------------------------------------------------------------------------- #
# Metadata
# --------------------------------------------------------------------------- #
metadata = OmegaConf.create()
metadata.classes = ["star", "galaxy", "qso"]
numclasses = len(metadata.classes)

MISC = OmegaConf.create()
# Sequence length seen by the model.  This is the knob Experiment C sweeps.
# 32 is a compromise: ELAISS1 and COSMOS have hundreds of visits, but activation
# memory scales linearly with T, and 32 x 6-band scenes with full FPN activations
# already exceed an 80 GB A100 at useful batch sizes.  On GH200 this can go
# substantially higher, which is the point of requesting DeltaAI specifically.
MISC.max_epochs = 32
MISC.epoch_strategy = "uniform"
# Fluxes are divided by this before the light-curve likelihood.  ~100 nJy is
# roughly i ~ 26, near the DDF single-visit limit, so typical targets land at
# order unity and the flow is not asked to cover 5 dex of dynamic range.
MISC.flux_scale = 100.0
MISC.cond_dim = 128
MISC.d_model = 256

# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #
model._target_ = make_generalized_rcnn_time()

# The shared encoder wraps the standard DeepDISC backbone.  Note the input
# arity change: static DeepDISC takes a 6-channel ugrizy stack, whereas a Rubin
# visit is single-filter, so the backbone stem takes one channel and filter
# identity enters through the conditioner.  Use
# ``deepdisc_time.training.warm_start_from_static`` to band-average pretrained
# stem weights rather than reinitialising them.
model.backbone.bottom_up.in_chans = 1
model.encoder = L(EpochConditionedEncoder)(
    backbone=model.backbone,
    cond_dim=MISC.cond_dim,
    # "attn_var" gives the RPN an explicit across-epoch variance channel.
    # Set to "mean" for the Experiment A null, which is the closest feature-space
    # analogue of detecting on a coadd.
    pool_mode="attn_var",
    chunk_size=8,          # epochs per backbone pass; lower if memory-bound
    grad_checkpoint=True,  # trades ~30% step time for a much longer usable T
)
del model.backbone  # now owned by the encoder

model.roi_heads._target_ = make_temporal_cascade_roi_heads()
model.roi_heads.num_classes = numclasses
model.roi_heads.batch_size_per_image = 512
model.roi_heads.flux_scale = MISC.flux_scale
model.roi_heads.temporal_loss_weight = 1.0
model.roi_heads.temporal_head = L(TemporalROIHead)(
    in_channels=256,
    roi_size=7,
    d_model=MISC.d_model,
    cond_dim=MISC.cond_dim,
    n_classes=numclasses,
    morph_size=25,
    # "flow" vs "mdn" is the light-curve head ablation.
    flux_head="flow",
    predict_offset=True,  # transient-host offset, for nuclear/non-nuclear calls
)

# Anchor sizes are in absolute pixels and DP2 is 0.2"/pixel.  These match the
# static DeepDISC DP1/DP2 configs; changing the pixel scale without changing
# these silently breaks anchor matching, which has bitten this group before.
model.proposal_generator.anchor_generator.sizes = [[8], [16], [32], [64], [128]]
model.proposal_generator.post_nms_topk = [6000, 1000]
for box_predictor in model.roi_heads.box_predictors:
    box_predictor.test_topk_per_image = 3000
    box_predictor.test_score_thresh = 0.3
    box_predictor.test_nms_thresh = 0.5

model.pixel_mean = [0.0]
model.pixel_std = [1.0]

# --------------------------------------------------------------------------- #
# Data
# --------------------------------------------------------------------------- #
bs = 2  # scenes per GPU; sequence length is the real memory driver, not batch
dataloader.train.total_batch_size = bs
dataloader.test.total_batch_size = bs
dataloader.test.num_workers = 8

_mapper = make_multi_epoch_dict_mapper()
dataloader.train.mapper = L(_mapper)(
    epoch_sampler=L(EpochSampler)(
        max_epochs=MISC.max_epochs, strategy=MISC.epoch_strategy, seed=0
    )
)
dataloader.test.mapper = L(_mapper)(
    epoch_sampler=L(EpochSampler)(max_epochs=MISC.max_epochs, strategy="uniform", seed=0)
)

DATASETS = OmegaConf.create()
DATASETS.TRAIN = "ddf_sequences_train"
DATASETS.TEST = "ddf_sequences_val"

# --------------------------------------------------------------------------- #
# Schedule
# --------------------------------------------------------------------------- #
train.init_checkpoint = ""  # set to a static DeepDISC checkpoint to warm start
train.max_iter = 60000
train.eval_period = 2000
train.checkpointer.period = 2000
optimizer.lr = 1e-4
