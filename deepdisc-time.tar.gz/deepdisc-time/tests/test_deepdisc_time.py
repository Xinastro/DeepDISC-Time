"""Test suite.

Weighted towards the things that are easy to get subtly wrong and that would
silently corrupt a science result rather than raise: PSF convolution
conventions, flux conservation, density normalisation, padding handling, and
whether the metrics actually detect a miscalibrated posterior.
"""

from __future__ import annotations

import numpy as np
import pytest
import torch

from deepdisc_time.baselines import DIAForcedPhotometry, StaticThenForcedPhotometry
from deepdisc_time.baselines.scarlet2_td import Scarlet2TDBackend, detect_peaks
from deepdisc_time.core.schema import BAND_INDEX, BANDS, EpochMeta, Sequence, meta_to_array
from deepdisc_time.data.drw import DRWParams, fit_drw_map, simulate_drw, structure_function
from deepdisc_time.data.injection import (
    InjectionConfig,
    _gaussian_psf,
    convolve_psf,
    inject_variable_source,
    make_synthetic_sequence,
    render_point_source,
    sersic_profile,
)
from deepdisc_time.data.loaders import EpochSampler, sequences_to_batch
from deepdisc_time.eval.metrics import (
    calibration_metrics,
    detection_metrics,
    lightcurve_metrics,
    match_sources,
    throughput_metrics,
)
from deepdisc_time.modeling.flows import LogisticMixtureFlowHead, MDNFluxHead
from deepdisc_time.modeling.meta_arch import TemporalSceneModel
from deepdisc_time.modeling.rendering import RenderingLoss, psf_convolve, render_point_sources
from deepdisc_time.modeling.temporal import TemporalFeaturePool, TemporalTransformer


# --------------------------------------------------------------------------- #
# Schema
# --------------------------------------------------------------------------- #
def test_epoch_meta_normalises_psf_and_rejects_even_kernels():
    psf = np.ones((5, 5))
    e = EpochMeta(mjd=60000.0, band="r", psf=psf)
    assert np.isclose(e.psf.sum(), 1.0)
    with pytest.raises(ValueError):
        EpochMeta(mjd=60000.0, band="r", psf=np.ones((4, 4)))
    with pytest.raises(ValueError):
        EpochMeta(mjd=60000.0, band="Q", psf=psf)


def test_psf_sigma_recovers_gaussian_width():
    for sigma in (1.0, 2.0, 3.0):
        e = EpochMeta(mjd=0.0, band="r", psf=_gaussian_psf(sigma, 41))
        assert abs(e.psf_sigma - sigma) < 0.05 * sigma


def test_sequence_rejects_inconsistent_shapes():
    imgs = np.zeros((3, 8, 8), dtype=np.float32)
    var = np.ones((2, 8, 8), dtype=np.float32)
    eps = [EpochMeta(mjd=i, band="r", psf=_gaussian_psf(1.5, 5)) for i in range(3)]
    with pytest.raises(ValueError):
        Sequence(images=imgs, variances=var, epochs=eps)
    with pytest.raises(ValueError):
        Sequence(images=imgs, variances=np.zeros((3, 8, 8)), epochs=eps)  # var must be > 0


def test_subsample_keeps_truth_in_lockstep():
    seq = make_synthetic_sequence(InjectionConfig(seed=1), n_epochs=12, size=32)
    sub = seq.subsample([0, 3, 5])
    assert sub.n_epochs == 3
    var_src = [s for s in sub.truth.sources if s.is_variable][0]
    orig = [s for s in seq.truth.sources if s.is_variable][0]
    assert len(var_src.variable_flux) == 3
    assert np.allclose(var_src.variable_flux, orig.variable_flux[[0, 3, 5]])


def test_meta_array_is_scene_relative():
    seq = make_synthetic_sequence(InjectionConfig(seed=2), n_epochs=5, size=24)
    m = meta_to_array(seq.epochs)
    assert m.shape == (5, 7)
    assert m[0, 0] == 0.0  # dt is measured from the first epoch, not absolute MJD


# --------------------------------------------------------------------------- #
# Physics: rendering conventions
# --------------------------------------------------------------------------- #
def test_torch_convolution_matches_numpy_reference():
    rng = np.random.default_rng(0)
    img = rng.random((24, 24)).astype(np.float32)
    psf = _gaussian_psf(1.7, 9)
    ref = convolve_psf(img, psf)
    got = psf_convolve(torch.tensor(img)[None, None], torch.tensor(psf)[None, None])[0, 0]
    assert np.abs(ref - got.numpy()).max() < 1e-5


def test_point_source_conserves_flux_and_matches_reference():
    psf = _gaussian_psf(1.6, 15)
    for x, y in [(16.0, 16.0), (15.3, 17.7), (12.9, 14.1)]:
        ref = render_point_source((32, 32), x, y, psf)
        got = render_point_sources(
            torch.tensor([[[x, y]]]), torch.ones(1, 1, 1), torch.tensor(psf)[None, None], (32, 32)
        )[0, 0].numpy()
        assert abs(ref.sum() - 1.0) < 1e-3
        assert abs(got.sum() - 1.0) < 1e-3
        assert np.abs(ref - got).max() < 1e-5


def test_asymmetric_psf_is_convolved_not_correlated():
    """A flipped kernel would shift sources by up to a PSF width.

    Half-pixel astrometric errors are indistinguishable from a real
    transient-host offset, so this convention is load-bearing.
    """
    psf = np.zeros((5, 5), dtype=np.float32)
    psf[2, 3] = 1.0  # impulse offset by +1 in x
    img = np.zeros((11, 11), dtype=np.float32)
    img[5, 5] = 1.0
    out = psf_convolve(torch.tensor(img)[None, None], torch.tensor(psf)[None, None])[0, 0].numpy()
    y, x = np.unravel_index(np.argmax(out), out.shape)
    assert (y, x) == (5, 6)


def test_sersic_profile_is_unit_flux_and_centred():
    p = sersic_profile((41, 41), 20.0, 20.0, 4.0, n=1.0)
    assert abs(p.sum() - 1.0) < 1e-4
    y, x = np.unravel_index(np.argmax(p), p.shape)
    assert (y, x) == (20, 20)


def test_rendering_loss_is_differentiable_in_position():
    psf = torch.tensor(_gaussian_psf(1.5, 9))[None, None].expand(1, 3, 9, 9).contiguous()
    pos = torch.tensor([[[12.4, 11.8]]], requires_grad=True)
    amp = torch.tensor([[[1.0, 2.0, 3.0]]], requires_grad=True)
    static = torch.rand(1, 24, 24, requires_grad=True)
    from deepdisc_time.modeling.rendering import render_scene

    pred = render_scene(static, pos, amp, psf)
    loss = RenderingLoss()(pred, torch.rand(1, 3, 24, 24), torch.full((1, 3, 24, 24), 0.01))
    loss.backward()
    for t in (pos, amp, static):
        assert t.grad is not None and torch.isfinite(t.grad).all()
    assert pos.grad.abs().sum() > 0


def test_rendering_loss_ignores_padded_epochs():
    pred = torch.zeros(1, 3, 8, 8)
    obs = torch.zeros(1, 3, 8, 8)
    obs[:, 2] = 1e6  # a wildly wrong padded epoch
    var = torch.ones(1, 3, 8, 8)
    mask = torch.tensor([[False, False, True]])
    assert RenderingLoss(huber_delta=None)(pred, obs, var, mask).item() == pytest.approx(0.0)


# --------------------------------------------------------------------------- #
# Densities
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("cls", [MDNFluxHead, LogisticMixtureFlowHead])
def test_flux_heads_are_normalised_densities(cls):
    torch.manual_seed(0)
    head = cls(16)
    ctx = torch.randn(1, 16)
    xs = torch.linspace(-40, 40, 40001)
    with torch.no_grad():
        lp = head.log_prob(xs, ctx.expand(40001, 16))
        integral = torch.trapz(lp.exp(), xs)
    assert abs(float(integral) - 1.0) < 1e-3


@pytest.mark.parametrize("cls", [MDNFluxHead, LogisticMixtureFlowHead])
def test_cdf_is_monotone_and_spans_unit_interval(cls):
    torch.manual_seed(1)
    head = cls(16)
    ctx = torch.randn(1, 16)
    xs = torch.linspace(-40, 40, 8001)
    with torch.no_grad():
        c = head.cdf(xs, ctx.expand(8001, 16))
    assert (c.diff() >= -1e-6).all()
    assert float(c[0]) < 1e-3 and float(c[-1]) > 1 - 1e-3


def test_flow_can_fit_a_bimodal_target():
    """The point of a flow over a Gaussian is multimodality and tails."""
    torch.manual_seed(0)
    head = LogisticMixtureFlowHead(4, n_components=8, n_blocks=2)
    opt = torch.optim.Adam(head.parameters(), lr=5e-3)
    ctx = torch.zeros(512, 4)
    for _ in range(600):
        sign = torch.where(torch.rand(512) < 0.5, -1.0, 1.0)
        x = sign * 3.0 + torch.randn(512) * 0.5
        loss = -head.log_prob(x, ctx).mean()
        opt.zero_grad()
        loss.backward()
        opt.step()
    with torch.no_grad():
        peak = head.log_prob(torch.tensor([3.0]), torch.zeros(1, 4))
        trough = head.log_prob(torch.tensor([0.0]), torch.zeros(1, 4))
    assert float(peak) > float(trough) + 1.0


def test_flow_sampling_inverts_the_cdf():
    torch.manual_seed(0)
    head = LogisticMixtureFlowHead(8)
    ctx = torch.randn(1, 8)
    s = head.sample(ctx, n=4000)
    with torch.no_grad():
        u = head.cdf(s.flatten(), ctx.expand(4000, 8))
    # Samples pushed through the CDF must be uniform.
    assert abs(float(u.mean()) - 0.5) < 0.03
    assert abs(float(u.std()) - (1 / np.sqrt(12))) < 0.03


# --------------------------------------------------------------------------- #
# Temporal components
# --------------------------------------------------------------------------- #
def test_temporal_transformer_respects_padding():
    torch.manual_seed(0)
    tt = TemporalTransformer(d_model=32, n_heads=4, n_layers=1, cond_dim=8).eval()
    tok = torch.randn(2, 6, 32)
    t = torch.rand(2, 6) * 50
    cond = torch.randn(2, 6, 8)
    mask = torch.zeros(2, 6, dtype=torch.bool)
    mask[:, 4:] = True

    with torch.no_grad():
        _, pooled_a = tt(tok, t, cond, mask)
        tok2 = tok.clone()
        tok2[:, 4:] = torch.randn(2, 2, 32) * 100  # scribble on the padding
        _, pooled_b = tt(tok2, t, cond, mask)
    assert torch.allclose(pooled_a, pooled_b, atol=1e-4)


@pytest.mark.parametrize("mode", ["mean", "max", "attn", "attn_var"])
def test_feature_pool_shapes(mode):
    pool = TemporalFeaturePool(8, cond_dim=4, mode=mode)
    out = pool(torch.randn(2, 5, 8, 6, 6), torch.randn(2, 5, 4), torch.zeros(2, 5, dtype=torch.bool))
    assert out.shape == (2, 8, 6, 6)


def test_time_encoding_distinguishes_close_and_distant_epochs():
    from deepdisc_time.modeling.temporal import ContinuousTimePositionalEncoding

    enc = ContinuousTimePositionalEncoding(32)
    e = enc(torch.tensor([[0.0, 0.01, 500.0]]))[0]
    near = torch.dot(e[0], e[1]) / (e[0].norm() * e[1].norm())
    far = torch.dot(e[0], e[2]) / (e[0].norm() * e[2].norm())
    assert float(near) > float(far)


# --------------------------------------------------------------------------- #
# Loading and batching
# --------------------------------------------------------------------------- #
def test_batch_pads_ragged_sequences_and_masks_them():
    seqs = [
        make_synthetic_sequence(InjectionConfig(seed=i), n_epochs=4 + 2 * i, size=32)
        for i in range(3)
    ]
    b = sequences_to_batch(seqs)
    assert b["images"].shape[1] == 8
    assert b["pad_mask"][0, 4:].all() and not b["pad_mask"][2].any()
    # Padded PSFs must be unit impulses, never zeros, or convolution NaNs out.
    assert torch.allclose(b["psfs"][0, 5].sum(), torch.tensor(1.0))


@pytest.mark.parametrize("strategy", ["first", "uniform", "random", "contiguous"])
def test_epoch_sampler_strategies(strategy):
    seq = make_synthetic_sequence(InjectionConfig(seed=0), n_epochs=20, size=24)
    out = EpochSampler(max_epochs=6, strategy=strategy)(seq)
    assert out.n_epochs <= 6
    assert np.all(np.diff(out.mjds) >= 0)  # time order preserved


def test_contiguous_sampler_shortens_the_baseline():
    seq = make_synthetic_sequence(InjectionConfig(seed=0), n_epochs=30, size=24)
    uni = EpochSampler(max_epochs=6, strategy="uniform")(seq)
    con = EpochSampler(max_epochs=6, strategy="contiguous", seed=3)(seq)
    span = lambda s: s.mjds[-1] - s.mjds[0]
    assert span(con) < span(uni)


# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #
def test_model_trains_and_predicts_end_to_end():
    torch.manual_seed(0)
    seqs = [make_synthetic_sequence(InjectionConfig(seed=i), n_epochs=6, size=40) for i in range(2)]
    batch = sequences_to_batch(seqs)
    model = TemporalSceneModel(d_model=64, morph_size=15)

    model.train()
    losses = model(batch)
    assert {"temporal_lightcurve_nll", "detection_loss", "rendering_loss"} <= set(losses)
    total = sum(losses.values())
    assert torch.isfinite(total)
    total.backward()

    model.eval()
    sols = model.predict_scene(batch, [s.scene_id for s in seqs])
    assert len(sols) == 2
    assert sols[0].sources[0].lightcurve.shape == (6,)
    assert 0.0 <= sols[0].sources[0].p_variable <= 1.0
    assert sols[0].wallclock_s > 0


def test_model_handles_a_single_epoch():
    """The degenerate T=1 case must not crash; it is the static limit."""
    seq = make_synthetic_sequence(InjectionConfig(seed=0), n_epochs=1, size=32)
    model = TemporalSceneModel(d_model=32, morph_size=11)
    model.train()
    losses = model(sequences_to_batch([seq]))
    assert torch.isfinite(sum(losses.values()))


def test_pooling_mode_changes_detection_features():
    """The Experiment A null and treatment must not be accidentally identical."""
    torch.manual_seed(0)
    batch = sequences_to_batch(
        [make_synthetic_sequence(InjectionConfig(seed=0), n_epochs=8, size=40)]
    )
    outs = []
    for mode in ("mean", "attn_var"):
        torch.manual_seed(0)
        m = TemporalSceneModel(d_model=32, morph_size=11, pool_mode=mode).eval()
        with torch.no_grad():
            f, ef, cond = m.encoder(
                batch["images"], batch["meta"], batch["band_idx"], batch["pad_mask"]
            )
        outs.append(f["p2"])
    assert not torch.allclose(outs[0], outs[1])


# --------------------------------------------------------------------------- #
# Baselines
# --------------------------------------------------------------------------- #
def test_classical_baselines_recover_a_bright_variable_source():
    """Both baselines should track a bright, strongly variable nucleus.

    Compared after mean-subtraction, because DIA measures flux *relative to a
    template* that itself contains the source's mean nuclear flux.  Its absolute
    scale is not comparable to an absolute truth light curve, and asserting on
    raw correlation would penalise it for doing exactly what DIA is meant to do.
    """
    cfg = InjectionConfig(seed=5, nucleus_to_host=1.5, drw_sf_inf=0.5)
    seq = make_synthetic_sequence(cfg, n_epochs=20, size=56)
    truth = [s for s in seq.truth.sources if s.is_variable][0]
    tl = truth.variable_flux - truth.variable_flux.mean()

    for backend in (StaticThenForcedPhotometry(), DIAForcedPhotometry()):
        sol = backend.fit(seq)
        assert sol.sources and sol.wallclock_s > 0
        lc = sol.sources[0].lightcurve
        assert np.isfinite(lc).all()
        assert np.corrcoef(lc - lc.mean(), tl)[0, 1] > 0.3


def test_naive_forced_photometry_shows_seeing_correlated_host_leakage():
    """The systematic the project exists to measure must be visible, not hidden.

    Forced photometry at a fixed position absorbs whatever host light falls
    under the PSF, and that contribution grows with seeing.  If this test ever
    stops failing to find the correlation, the baseline has been accidentally
    made smarter than the production pipeline it stands in for.
    """
    cfg = InjectionConfig(seed=5, nucleus_to_host=0.3, host_half_light_radius=4.0)
    seq = make_synthetic_sequence(cfg, n_epochs=24, size=56)
    seeing = np.array([e.psf_sigma for e in seq.epochs])
    lc = StaticThenForcedPhotometry().fit(seq).sources[0].lightcurve
    assert np.corrcoef(lc, seeing)[0, 1] > 0.2


def test_static_subtraction_uses_psf_matching_not_double_convolution():
    """Guards a bug that made the baseline look far worse than it is.

    The coadd is already seeing-convolved.  Convolving it again with the epoch
    PSF double-blurs the static model and leaves a large seeing-correlated
    residual that mimics a real photometric systematic.  Correct PSF matching
    must leave a smaller residual than the buggy version.
    """
    from deepdisc_time.data.injection import convolve_psf

    cfg = InjectionConfig(seed=2, nucleus_to_host=0.0, host_half_light_radius=3.0)
    seq = make_synthetic_sequence(cfg, n_epochs=12, size=48)
    w = 1.0 / seq.variances
    coadd = (seq.images * w).sum(0) / w.sum(0)

    matched = StaticThenForcedPhotometry(subtract_static=True).fit(seq)
    resid_double = np.mean(
        [np.std(seq.images[t] - convolve_psf(coadd, e.psf)) for t, e in enumerate(seq.epochs)]
    )
    resid_matched = np.mean(
        [
            np.std(seq.images[t] - coadd)
            for t in range(seq.n_epochs)
        ]
    )
    assert resid_matched < resid_double
    assert matched.sources


def test_detect_peaks_finds_an_isolated_source():
    seq = make_synthetic_sequence(InjectionConfig(seed=0, nucleus_to_host=2.0), n_epochs=10, size=48)
    peaks = detect_peaks(seq)
    assert len(peaks) >= 1
    assert np.min(np.linalg.norm(peaks - np.array([23.5, 23.5]), axis=1)) < 3.0


def test_scarlet2_backend_reports_a_useful_error_when_absent():
    pytest.importorskip
    try:
        import scarlet2  # noqa: F401
        pytest.skip("scarlet2 installed; nothing to assert about its absence")
    except ImportError:
        pass
    seq = make_synthetic_sequence(InjectionConfig(seed=0), n_epochs=4, size=24)
    with pytest.raises(ImportError, match="scarlet2"):
        Scarlet2TDBackend().fit(seq)


# --------------------------------------------------------------------------- #
# Metrics
# --------------------------------------------------------------------------- #
def test_match_sources_prefers_high_scoring_detections():
    pred = np.array([[10.0, 10.0], [10.5, 10.0]])
    true = np.array([[10.4, 10.0]])
    m = match_sources(pred, true, radius=2.0, pred_scores=np.array([0.1, 0.9]))
    assert m.pairs == [(1, 0)]  # the high-scoring one wins, not the nearest
    assert m.unmatched_pred == [0]


def test_detection_metrics_are_perfect_on_an_exact_solution():
    from deepdisc_time.core.schema import SceneSolution, SourceSolution

    seqs = [make_synthetic_sequence(InjectionConfig(seed=i), n_epochs=5, size=32) for i in range(2)]
    sols = []
    for s in seqs:
        srcs = [
            SourceSolution(x=t.x, y=t.y, lightcurve=np.zeros(s.n_epochs))
            for t in s.truth.sources
        ]
        sols.append(SceneSolution(scene_id=s.scene_id, sources=srcs, n_epochs=s.n_epochs))
    d = detection_metrics(sols, seqs, radius=1.0)
    # Host and nucleus are co-located in the synthetic scene, so a one-to-one
    # match can only claim one of them: completeness is capped at 0.5 by
    # construction, and purity should still be perfect.
    assert d["purity"] == pytest.approx(1.0)
    assert d["median_offset_px"] < 1e-6


def test_calibration_detects_overconfident_error_bars():
    from deepdisc_time.core.schema import SceneSolution, SourceSolution

    rng = np.random.default_rng(0)
    seqs = [make_synthetic_sequence(InjectionConfig(seed=i), n_epochs=30, size=32) for i in range(4)]
    honest, overconfident = [], []
    for s in seqs:
        t = [x for x in s.truth.sources if x.is_variable][0]
        sigma = 0.05 * t.variable_flux.mean()
        noisy = t.variable_flux + rng.normal(0, sigma, s.n_epochs)
        honest.append(
            SceneSolution(
                scene_id=s.scene_id,
                n_epochs=s.n_epochs,
                sources=[
                    SourceSolution(
                        x=t.x, y=t.y, lightcurve=noisy, lightcurve_err=np.full(s.n_epochs, sigma)
                    )
                ],
            )
        )
        overconfident.append(
            SceneSolution(
                scene_id=s.scene_id,
                n_epochs=s.n_epochs,
                sources=[
                    SourceSolution(
                        x=t.x,
                        y=t.y,
                        lightcurve=noisy,
                        lightcurve_err=np.full(s.n_epochs, sigma / 5),
                    )
                ],
            )
        )
    good = calibration_metrics(honest, seqs, radius=2.0)
    bad = calibration_metrics(overconfident, seqs, radius=2.0)
    assert good["pit_ks"] < bad["pit_ks"]
    assert good["coverage_68"] > bad["coverage_68"]


def test_throughput_metrics_scale_per_source_epoch():
    from deepdisc_time.core.schema import SceneSolution, SourceSolution

    sols = [
        SceneSolution(
            scene_id=str(i),
            sources=[SourceSolution(x=0, y=0, lightcurve=np.zeros(10))],
            wallclock_s=2.0,
            n_epochs=10,
        )
        for i in range(3)
    ]
    t = throughput_metrics(sols)
    assert t["s_per_scene_median"] == pytest.approx(2.0)
    assert t["ms_per_source_epoch"] == pytest.approx(200.0)
    assert t["convergence_rate"] == 1.0


# --------------------------------------------------------------------------- #
# DRW
# --------------------------------------------------------------------------- #
def test_drw_reaches_the_stationary_variance_on_long_baselines():
    rng = np.random.default_rng(0)
    t = np.sort(rng.uniform(0, 200_000, 4000))
    m = simulate_drw(t, DRWParams(tau=300.0, sf_inf=0.3, mean_mag=20.0), rng=rng)
    assert abs(m.std() - 0.3 / np.sqrt(2)) < 0.04
    assert abs(m.mean() - 20.0) < 0.1


def test_drw_sampler_is_order_invariant():
    """Unsorted input times must give the same statistics as sorted ones."""
    rng = np.random.default_rng(1)
    t = rng.uniform(0, 5000, 800)
    m = simulate_drw(t, DRWParams(tau=200.0, sf_inf=0.25, mean_mag=19.0), rng=rng)
    assert m.shape == t.shape
    assert np.isfinite(m).all()


def test_structure_function_rises_and_flattens():
    rng = np.random.default_rng(2)
    t = np.sort(rng.uniform(0, 4000, 900))
    m = simulate_drw(t, DRWParams(tau=200.0, sf_inf=0.4, mean_mag=20.0), rng=rng)
    lags, sf, _ = structure_function(t, m, errors=np.full_like(m, 0.005))
    assert len(sf) > 3
    assert sf[-1] > sf[0]


def test_drw_fit_recovers_sf_inf_on_a_long_baseline():
    rng = np.random.default_rng(3)
    t = np.sort(rng.uniform(0, 20_000, 1500))
    truth = DRWParams(tau=200.0, sf_inf=0.3, mean_mag=20.0)
    m = simulate_drw(t, truth, rng=rng)
    fit = fit_drw_map(t, m, np.full_like(m, 0.01))
    assert abs(np.log10(fit.tau) - np.log10(truth.tau)) < 0.5
    assert abs(fit.sf_inf - truth.sf_inf) < 0.1


# --------------------------------------------------------------------------- #
# Injection
# --------------------------------------------------------------------------- #
def test_injection_adds_flux_and_inflates_variance():
    seq = make_synthetic_sequence(InjectionConfig(seed=0, nucleus_to_host=0.0), n_epochs=6, size=40)
    lc = np.full(6, 5000.0)
    out = inject_variable_source(seq, 20.0, 20.0, lc, add_noise=False)
    assert out.images.sum() > seq.images.sum()
    assert (out.variances >= seq.variances).all()
    assert len([s for s in out.truth.sources if s.is_variable]) >= 1


def test_injection_rejects_a_mismatched_lightcurve():
    seq = make_synthetic_sequence(InjectionConfig(seed=0), n_epochs=6, size=24)
    with pytest.raises(ValueError):
        inject_variable_source(seq, 12.0, 12.0, np.zeros(5))


# --------------------------------------------------------------------------- #
# Per-band static amplitude (v0.2.0) and the colour-gradient systematic.
# --------------------------------------------------------------------------- #


def test_render_scene_accepts_per_epoch_static():
    """(B, H, W) and (B, T, H, W) must agree when the latter is a broadcast."""
    import torch

    from deepdisc_time.modeling.rendering import render_scene

    b, t, h, w, s, k = 2, 5, 32, 32, 3, 9
    psf = torch.zeros(b, t, k, k)
    psf[..., k // 2, k // 2] = 1.0
    static3 = torch.rand(b, h, w)
    pos = torch.rand(b, s, 2) * 20 + 6
    amp = torch.rand(b, s, t)

    out3 = render_scene(static3, pos, amp, psf)
    out4 = render_scene(static3.unsqueeze(1).expand(b, t, h, w).contiguous(), pos, amp, psf)
    assert torch.allclose(out3, out4, atol=1e-7)

    with pytest.raises(ValueError):
        render_scene(torch.rand(b, t + 1, h, w), pos, amp, psf)


def test_build_static_per_epoch_sed_semantics():
    """Unit SED reproduces the band-independent canvas; per-band scaling applies."""
    import torch

    from deepdisc_time.modeling.meta_arch import build_static_per_epoch

    b, s, m, h, w, nb = 2, 3, 9, 32, 32, 6
    morph = torch.rand(b, s, m, m)
    pos = torch.rand(b, s, 2) * 20 + 6
    band = torch.tensor([[0, 1, 2, 1, 0], [3, 3, 4, 5, 2]])
    t = band.shape[1]

    grey = build_static_per_epoch(morph, pos, band, (h, w), sed=None)
    assert grey.shape == (b, h, w)

    unit = build_static_per_epoch(morph, pos, band, (h, w), sed=torch.ones(b, s, nb))
    assert unit.shape == (b, t, h, w)
    assert torch.allclose(unit, grey.unsqueeze(1).expand(b, t, h, w), atol=1e-6)

    sed = torch.ones(b, s, nb)
    sed[:, :, 0] = 2.0  # u only
    scaled = build_static_per_epoch(morph, pos, band, (h, w), sed=sed)
    assert torch.allclose(scaled[0, 0], 2.0 * grey[0], atol=1e-6)  # epoch 0 is u
    assert torch.allclose(scaled[0, 2], grey[0], atol=1e-6)  # epoch 2 is r

    sed_g = torch.ones(b, s, nb, requires_grad=True)
    build_static_per_epoch(morph, pos, band, (h, w), sed=sed_g).sum().backward()
    assert sed_g.grad is not None and float(sed_g.grad.abs().sum()) > 0


def test_sed_head_is_identity_at_init():
    """A freshly built head must reproduce pre-v0.2.0 behaviour exactly."""
    import torch

    from deepdisc_time.modeling.heads import TemporalROIHead

    head = TemporalROIHead(in_channels=8, roi_size=3, d_model=16, cond_dim=8, n_layers=1)
    n, t = 4, 6
    out = head(
        torch.randn(n, t, 8, 3, 3),
        torch.rand(n, t) * 50,
        torch.randn(n, t, 8),
    )
    assert out.static_sed is not None
    assert out.static_sed.shape == (n, len(BANDS))
    # Zero-initialised decoder => exp(0) = 1 in every band.
    assert torch.allclose(out.static_sed, torch.ones_like(out.static_sed), atol=1e-6)

    off = TemporalROIHead(
        in_channels=8, roi_size=3, d_model=16, cond_dim=8, n_layers=1, predict_sed=False
    )
    out_off = off(torch.randn(n, t, 8, 3, 3), torch.rand(n, t) * 50, torch.randn(n, t, 8))
    assert out_off.static_sed is None


def test_sed_regulariser_present_and_signed():
    import torch

    from deepdisc_time.modeling.heads import TemporalHeadOutput, TemporalROIHead

    head = TemporalROIHead(in_channels=8, roi_size=3, d_model=16, cond_dim=8, n_layers=1)
    n, t = 3, 5
    out = TemporalHeadOutput(
        p_variable_logit=torch.zeros(n),
        flux_ctx=torch.zeros(n, t, 2 * 16),
        static_morph=torch.zeros(n, 1, 25, 25),
        static_log_sed=torch.full((n, len(BANDS)), 0.5),
    )
    losses = head.losses(out)
    assert "temporal_sed_reg" in losses
    assert float(losses["temporal_sed_reg"]) > 0

    out.static_log_sed = torch.zeros(n, len(BANDS))
    assert float(head.losses(out)["temporal_sed_reg"]) == pytest.approx(0.0)


def test_colour_gradient_host_conserves_flux_but_not_shape():
    """The generator must change morphology with band while holding flux fixed."""
    from deepdisc_time.data.injection import InjectionConfig, colour_gradient_host

    cfg = InjectionConfig(host_colour_gradient=0.8, host_flux=5000.0, seed=1)
    shape, c = (64, 64), 31.5

    totals = [colour_gradient_host(shape, c, c, b, cfg).sum() for b in BANDS]
    assert np.allclose(totals, 5000.0, rtol=2e-2), "total flux must not vary with band"

    def central_fraction(img):
        yy, xx = np.mgrid[0 : shape[0], 0 : shape[1]]
        r = np.hypot(xx - c, yy - c)
        return float(img[r < 2.0].sum() / img.sum())

    f_u = central_fraction(colour_gradient_host(shape, c, c, "u", cfg))
    f_y = central_fraction(colour_gradient_host(shape, c, c, "y", cfg))
    assert f_y > f_u + 0.05, "redder bands must be more centrally concentrated"

    grey = InjectionConfig(host_colour_gradient=0.0, host_flux=5000.0, seed=1)
    g_u = central_fraction(colour_gradient_host(shape, c, c, "u", grey))
    g_y = central_fraction(colour_gradient_host(shape, c, c, "y", grey))
    assert g_u == pytest.approx(g_y, abs=1e-9), "grey control must be band-independent"


def test_colour_gradient_sequence_nucleus_is_constant():
    from deepdisc_time.data.injection import InjectionConfig, make_colour_gradient_sequence

    seq = make_colour_gradient_sequence(
        InjectionConfig(host_colour_gradient=0.6, seed=2), n_epochs=18, variable=False
    )
    nuc = [s for s in seq.truth.sources if s.source_type == "agn"][0]
    assert float(np.std(nuc.variable_flux)) == 0.0, "Experiment D needs an exactly constant nucleus"
    assert not nuc.is_variable
    assert len({e.band for e in seq.epochs}) >= 5

    var = make_colour_gradient_sequence(
        InjectionConfig(host_colour_gradient=0.6, seed=2), n_epochs=18, variable=True
    )
    assert float(np.std([s for s in var.truth.sources if s.source_type == "agn"][0].variable_flux)) > 0


def test_band_independent_fit_manufactures_variability():
    """The systematic Experiment D measures must actually exist.

    Fit one band-independent host morphology plus a free per-epoch nuclear
    amplitude to a scene whose nucleus is exactly constant.  If the host has a
    colour gradient, the unmodelled shape change is absorbed by the nuclear
    amplitude and a spurious band-correlated light curve appears.  The grey
    control must not show it.  This is a closed-form least-squares fit, not a
    trained model: the artefact is a property of the model *form*, which is the
    claim the experiment rests on.
    """
    from deepdisc_time.data.injection import (
        InjectionConfig,
        colour_gradient_host,
        convolve_psf,
        render_point_source,
        _gaussian_psf,
    )

    size, c, n_ep = 64, 31.5, 18
    psf = _gaussian_psf(2.0)
    bands = list(BANDS) * 3
    bands = bands[:n_ep]

    def recover(gradient: float) -> np.ndarray:
        cfg = InjectionConfig(
            host_colour_gradient=gradient, host_flux=5000.0, nucleus_to_host=0.2, seed=7
        )
        nuc_true = cfg.host_flux * cfg.nucleus_to_host
        # Band-independent template: the mid-band host, which is the best a
        # single shared morphology can do.
        tmpl = convolve_psf(
            0.5 * (colour_gradient_host((size, size), c, c, "r", cfg)
                   + colour_gradient_host((size, size), c, c, "i", cfg)),
            psf,
        ).ravel()
        point = render_point_source((size, size), c, c, psf).ravel()
        basis = np.stack([tmpl, point], axis=1)

        amps = []
        for b in bands:
            host = convolve_psf(colour_gradient_host((size, size), c, c, b, cfg), psf)
            data = (host + point.reshape(size, size) * nuc_true).ravel()
            coef, *_ = np.linalg.lstsq(basis, data, rcond=None)
            amps.append(coef[1])
        return np.array(amps)

    grey = recover(0.0)
    grad = recover(0.9)
    mu_grey, mu_grad = grey.mean(), grad.mean()

    spread_grey = (grey.max() - grey.min()) / abs(mu_grey)
    spread_grad = (grad.max() - grad.min()) / abs(mu_grad)

    assert spread_grey < 1e-6, f"grey host must recover a flat light curve, got {spread_grey:.3e}"
    assert spread_grad > 0.05, (
        "a colour-gradient host must manufacture spurious variability in a "
        f"band-independent fit, got {spread_grad:.3e}"
    )

    # And it must track band, not epoch order.
    idx = np.array([BAND_INDEX[b] for b in bands])
    by_band = np.array([grad[idx == k].mean() for k in np.unique(idx)])
    within = np.mean([grad[idx == k].std() for k in np.unique(idx)])
    assert by_band.std() > 10 * max(within, 1e-12), "artefact must be band-correlated"


def test_spurious_variability_metric_separates_band_artefact_from_noise():
    """The Experiment D metric must distinguish a filter-correlated artefact from scatter.

    Photon noise always produces some spread in a recovered light curve. What
    marks the colour-gradient systematic is that the spread tracks *bandpass*
    rather than time. ``spurious_band_frac`` is the discriminant, and it must
    read ~1 for a pure band artefact and near the 1/n_bands floor for white
    noise, or Experiment D cannot tell the two apart.
    """
    from deepdisc_time.core.schema import SceneSolution, SourceSolution
    from deepdisc_time.data.injection import InjectionConfig, make_colour_gradient_sequence
    from deepdisc_time.eval.metrics import spurious_variability_metrics

    seq = make_colour_gradient_sequence(
        InjectionConfig(host_colour_gradient=0.5, seed=1), n_epochs=18, variable=False
    )
    nuc = [s for s in seq.truth.sources if s.source_type == "agn"][0]
    bands = np.array([e.band_index for e in seq.epochs])

    def measure(lc):
        sol = SceneSolution(
            scene_id=seq.scene_id,
            method="test",
            sources=[SourceSolution(x=nuc.x, y=nuc.y, lightcurve=np.asarray(lc), score=1.0)],
        )
        return spurious_variability_metrics([sol], [seq])

    perfect = measure(np.full(seq.n_epochs, 1000.0))
    assert perfect["n_sources"] == 1
    assert perfect["spurious_rms_frac"] == pytest.approx(0.0, abs=1e-9)
    assert perfect["spurious_band_range_frac"] == pytest.approx(0.0, abs=1e-9)

    step = 1000.0 * (1.0 + 0.30 * (bands - bands.mean()) / max(bands.std(), 1))
    art = measure(step)
    assert art["spurious_band_frac"] == pytest.approx(1.0, abs=1e-6)
    assert art["spurious_rms_frac"] > 0.1

    rng = np.random.default_rng(0)
    noise = measure(1000.0 * (1 + 0.1 * rng.standard_normal(seq.n_epochs)))
    assert noise["spurious_band_frac"] < 0.5, (
        "white noise must not be mistaken for a band-correlated artefact"
    )
    assert noise["spurious_band_frac"] < art["spurious_band_frac"]
